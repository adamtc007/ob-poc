//! Stub pipeline for deterministic scenario testing.
//!
//! Uses `HybridVerbSearcher::minimal()` which returns NoMatch for everything,
//! making it ideal for testing governance, policy gate, and trace accuracy
//! scenarios that don't depend on verb discovery.
//!
//! For scenarios that need specific verb matches, use live mode with a real DB.

use std::sync::Arc;
use uuid::Uuid;

use crate::agent::orchestrator::{OrchestratorContext, UtteranceSource};
use crate::mcp::verb_search::HybridVerbSearcher;
use crate::policy::PolicyGate;
use crate::sem_reg::abac::ActorContext;

use super::{ModeExpectations, SessionSeed};

/// Build an OrchestratorContext for stub mode testing.
///
/// Uses minimal verb searcher (no DB, no embedder) and configurable PolicyGate.
#[cfg(feature = "database")]
pub fn build_stub_context(
    pool: &sqlx::PgPool,
    session_id: Uuid,
    seed: &SessionSeed,
    mode: &ModeExpectations,
) -> OrchestratorContext {
    let actor = ActorContext {
        actor_id: seed.actor.actor_id.clone(),
        roles: seed.actor.roles.clone(),
        department: None,
        clearance: None,
        jurisdictions: vec![],
    };

    let policy = PolicyGate {
        strict_single_pipeline: mode.strict_single_pipeline,
        allow_raw_execute: mode.allow_raw_execute,
        strict_semreg: mode.strict_semreg,
        allow_legacy_generate: false,
    };

    OrchestratorContext {
        actor,
        session_id: Some(session_id),
        case_id: Some(session_id),
        dominant_entity_id: None,
        scope: None,
        pool: pool.clone(),
        verb_searcher: Arc::new(HybridVerbSearcher::minimal()),
        lookup_service: None,
        policy_gate: Arc::new(policy),
        source: UtteranceSource::Chat,
        sem_os_client: None,
        agent_mode: sem_os_core::authoring::agent_mode::AgentMode::default(),
        goals: vec![],
        stage_focus: None,
        sage_engine: None,
        pre_sage_entity_kind: None,
        pre_sage_entity_name: None,
        pre_sage_entity_confidence: None,
        recent_sage_intents: vec![],
        nlci_compiler: Some(crate::semtaxonomy_v2::build_minimal_cbu_compiler()),
        discovery_selected_domain: None,
        discovery_selected_family: None,
        discovery_selected_constellation: None,
        discovery_answers: std::collections::HashMap::new(),
        session_cbu_ids: None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_stub_context_uses_strict_defaults() {
        let mode = ModeExpectations::default();
        assert!(mode.strict_semreg);
        assert!(mode.strict_single_pipeline);
        assert!(!mode.allow_raw_execute);
    }

    #[test]
    fn test_actor_seed_defaults() {
        let seed = SessionSeed::default();
        assert_eq!(seed.actor.actor_id, "test.user");
        assert_eq!(seed.actor.roles, vec!["viewer"]);
    }
}
