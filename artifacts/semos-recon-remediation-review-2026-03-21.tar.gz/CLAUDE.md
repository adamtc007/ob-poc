# CLAUDE.md

> **Last reviewed:** 2026-03-21
> **Frontend:** React/TypeScript (`ob-poc-ui-react/`) - Chat UI with scope panel, Inspector, Semantic OS Tab
> **Backend:** Rust/Axum (`rust/crates/ob-poc-web/`) - Serves React + REST API
> **Crates:** 22 active Rust crates (16 ob-poc + 6 sem_os_*; esper_* deprecated; ob-poc-graph + viewport removed)
> **Verbs:** 1,263 canonical verbs, 15,940 intent patterns (DB-sourced)
> **MCP Tools:** ~102 tools (DSL, verbs, learning, session, batch, research, taxonomy, sem_reg, stewardship, db_introspect, session_verb_surface)
> **Migrations:** 123 schema migrations (001-077 + 072b seed + 078-091 sem_reg + 087-089 agent/runbook + 092-098 sem_os standalone + stewardship + 099-100 authoring + 101-102 standalone remediation + 103 CCIR telemetry + 115-123 schema consolidation + document governance bootstrap)
> **Schema Overview:** `migrations/OB_POC_SCHEMA_ENTITY_OVERVIEW.md` — living doc for the consolidated database; runtime business tables now live under `"ob-poc"`, Semantic OS tables under `sem_reg*`, and the canonical schema dump lives in `migrations/master-schema.sql`
> **Embeddings:** Candle local (384-dim, BGE-small-en-v1.5) - 15,940 patterns vectorized
> **React Migration (077):** ✅ Complete - egui/WASM replaced with React/TypeScript, 3-panel chat layout
> **Verb Phrase Generation:** ✅ Complete - V1 YAML auto-generates phrases on load (no V2 registry)
> **Navigation:** ✅ Unified - All prompts go through intent matching (view.*/session.* verbs)
> **Multi-CBU Viewport:** ✅ Complete - Scope graph endpoint, execution refresh
> **REPL Session/Phased Execution:** ⚠️ Superseded by V2 REPL Architecture
> **REPL Pipeline Redesign (077):** ⚠️ Superseded by V2 REPL Architecture — V1 types retained for reference
> **V2 REPL Architecture (TODO-2):** ✅ Complete - Pack-scoped intent resolution, 7-state machine, ContextStack fold, preconditions engine, 3-pronged intent pipeline (semantic→pack→precondition), VerbSearchIntentMatcher bridge, 320 tests
> **Runbook Compilation Pipeline:** ✅ Complete - `compile_invocation()` wired: classify_verb → compile_verb → OrchestratorResponse, CompiledRunbook stored in RunbookStore, execution gate (no raw DSL — all paths through execute_runbook), StepExecutor bridge (DslStepExecutor/DslExecutorV2StepExecutor), write_set derived from args (UUID extraction), advisory locks via execute_runbook_with_pool (try_advisory_xact_lock, sorted, fail-fast), monotonic version allocator on ReplSessionV2, compile-on-the-fly fallback for legacy entries, 12 behavioral enforcement tests
> **Candle Semantic Pipeline:** ✅ Complete - DB source of truth, populate_embeddings binary
> **Agent Pipeline:** ✅ Hardened + PolicyGate - Unified orchestrator, server-side policy enforcement, SemReg fail-closed (v2: matched-path + DenyAll/Unavailable), ActorResolver (headers/env/session), IntentTrace audit with PolicySnapshot, AST-based macro SemReg governance, RunSheet replay prevention, /select-verb retired (410 Gone), intent_events telemetry, entity-kind constrained verb selection + ClarifyEntity
> **Solar Navigation (038):** ✅ Complete - ViewState, NavigationHistory, orbit navigation
> **Nav UX Messages:** ✅ Complete - NavReason codes, NavSuggestion, standardized error copy
> **Promotion Pipeline (043):** ✅ Complete - Quality-gated pattern promotion with collision detection
> **Teaching Mechanism (044):** ✅ Complete - Direct phrase→verb mapping for trusted sources
> **Verb Search Test Harness:** ✅ Complete - Full pipeline sweep, safety-first policy, learning accelerator workflow
> **Client Group Resolver (048):** ✅ Complete - Two-stage alias→group→anchor resolution for session scope
> **Workflow Task Queue (049):** ✅ Complete - Async task return path, document entity, requirement guards
> **Transactional Execution (050):** ✅ Complete - Atomic execution, advisory locks, expansion audit
> **CustomOp Auto-Registration (051):** ✅ Complete - `#[register_custom_op]` macro, inventory-based registration
> **Staged Runbook REPL (054):** ❌ Removed - V1 staged runbook deleted (superseded by V2 REPL pack-guided runbook)
> **Client Group Research Integration (055):** ✅ Complete - GLEIF import → client_group_entity staging → CBU creation with role mapping
> **REPL Viewport Feedback Loop (056):** ✅ Complete - Scope propagation in execute_runbook triggers UI refresh
> **Verb Disambiguation UI (057):** ✅ Complete - Ambiguous verb selection with gold-standard learning signals
> **Unified Architecture (058):** ✅ Complete - Operator vocabulary, macro lint, constraint cascade, DAG navigation, phonetic matching
> **Playbook System (059):** ✅ Complete - YAML playbooks, marked-yaml source mapping, LSP validation, xtask CLI
> **LSP Alignment (060):** ✅ Complete - UTF-16 encoding, multiline context, tree-sitter binding rule, rename handler
> **LSP Test Harness (063):** ✅ Complete - 150+ parser tests, golden file validation, syntax edge cases
> **Macro Vocabulary (063):** ✅ Complete - party.yaml macros, macro/implementation separation documented
> **CBU Structure Macros (064):** ✅ Complete - M1-M18 jurisdiction macros, document bundles, placeholder entities, role cardinality, wizard UI
> **ESPER Navigation Crates (065):** ⚠️ Deprecated - esper_* crates retained for reference, replaced by React UI
> **Unified Lookup Service (074):** ✅ Complete - Verb-first dual search combining verb discovery + entity linking
> **Lexicon Service (072):** ✅ Complete - In-memory verb/domain/concept lookup with bincode snapshots
> **Entity Linking Service (073):** ✅ Complete - In-memory entity resolution with mention extraction, token overlap matching
> **Clarification UX Wiring (075):** ✅ Complete - Unified DecisionPacket system for verb/scope/group disambiguation with confirm tokens
> **Inspector-First Visualization (076):** ✅ Complete - Deterministic tree/table Inspector UI, projection schema with $ref linking, 82 tests
> **Deal Record & Fee Billing (067):** ✅ Complete - Commercial origination hub, rate card negotiation, closed-loop billing
> **BPMN-Lite Runtime (Phase A):** ✅ Complete - Standalone durable orchestration service, 23-opcode VM, gRPC API (verified over the wire), 123 core tests + gRPC smoke test
> **BPMN-Lite Phase 2 (Race/Boundary):** ✅ Complete - Race semantics (Msg vs Timer arms), boundary timer events, interrupting + non-interrupting fire modes
> **BPMN-Lite Phase 2A (Non-Interrupting + Cycles):** ✅ Complete - Non-interrupting boundary spawns child fiber (main stays in Race), ISO 8601 timer cycles (R<n>/PT<dur>), cycle exhaustion revert
> **BPMN-Lite Phase 3 (Cancel/Ghost):** ✅ Complete - Ghost signal protection, WaitCancelled/SignalIgnored events, job purge on cancel, completion ownership in engine
> **BPMN-Lite Phase 5 (Terminate/Error/Loops):** ✅ Complete - EndTerminate (kill all sibling fibers), error boundary routing (BusinessRejection → catch path), bounded retry loops (IncCounter/BrCounterLt)
> **BPMN-Lite Phase 5A (Inclusive Gateway):** ✅ Complete - OR-gateway ForkInclusive (condition_flag evaluation, dynamic branch count), JoinDynamic (join_expected set at fork time)
> **BPMN-Lite Integration (Phase B):** ✅ Complete - ob-poc ↔ bpmn-lite wiring: WorkflowDispatcher (queue-based resilience), JobWorker, EventBridge, SignalRelay, PendingDispatchWorker, correlation stores, 41 unit tests + 13 integration tests + 15 E2E choreography tests
> **BPMN-Lite Phase 4 (PostgresProcessStore):** ✅ Complete - Feature-gated (`postgres`) PostgreSQL-backed ProcessStore, 12 migrations, 29 async methods, `--database-url` CLI arg with MemoryStore fallback, 15 integration tests
> **BPMN-Lite Authoring (Phases B-D):** ✅ Complete - Verb contracts + lint rules (5 rules), BPMN 2.0 XML export + IR↔DTO round-trip, template registry + atomic publish pipeline, PostgresTemplateStore, 123 core tests + 6 integration tests
> **KYC/UBO Skeleton Build Pipeline:** ✅ Complete - 7-step build (import-run → graph validate → UBO compute → coverage → outreach plan → tollgate → complete), real computation in all ops, 12 integration tests with assertions
> **KYC Skeleton Build Post-Audit (S1):** ✅ Complete - Decimal conversion (F-5), coverage ownership scoping (F-2), transaction boundary (F-1), configurable outreach cap (F-4), shared function extraction (F-3a-e)
> **KYC Skeleton Build Post-Audit (S2):** ✅ Complete - Import run case linkage on idempotent hit (F-7), as_of date for import runs (F-8a-c), case status state machine with KycCaseUpdateStatusOp plugin (F-6a-e), 4 transition tests
> **Semantic OS (Phases 0-9, Migrations 078-098):** ✅ Complete + Standalone Service (v1.1) + Stewardship (Phase 0-1) + Cleanup (pre-Java port) - Immutable snapshot registry, 16 object types, ABAC + security labels, publish gates, context resolution API, agent control plane (~32 MCP tools), 6 standalone crates (sem_os_core/postgres/server/client/harness/obpoc_adapter), port-trait isolation, outbox-driven projections, changeset workflow (Draft→Approved→Published), stewardship layer (23 MCP tools: 17 Phase 0 + 6 Phase 1), 15 guardrail rules (G01-G15), basis records, conflict detection, Show Loop (4 viewports + SSE), REST+JWT API, db_introspect MCP tool, AttributeSource real (schema,table,column) triples, standalone server verified (10 HTTP integration tests), strum-based enum derives (Display/EnumString/AsRefStr), `#[must_use]` on decision types, 321 unit tests + 50 adapter tests
> **SemOS Document Governance Bootstrap (122-123):** ✅ In progress in runtime - `RequirementProfileDef`, `ProofObligationDef`, and `EvidenceStrategyDef` are now first-class governed object types; active published snapshots flow into `sem_reg_pub.active_requirement_profiles`, `sem_reg_pub.active_proof_obligations`, and `sem_reg_pub.active_evidence_strategies`; KYC/entity document flows can now compute governed requirement matrices via `document.compute-requirements`, with immutable audit bindings landing in `"ob-poc".policy_version_bindings`
> **Stewardship Agent (Phase 0-1, Migrations 096-098):** ✅ Complete - Changeset authoring layer, 23 MCP tools, guardrails engine (G01-G15), basis records, conflict detection, idempotency, Show Loop with 4 viewports (Focus/Inspector/Diff/Gates), SSE streaming, REST endpoints, 11 integration tests
> **Governed Registry Authoring (v0.4, Migrations 099-102):** ✅ Complete + Standalone Verified - Research→Governed two-plane model, 7 governance verbs (propose/validate/dry-run/plan/publish/rollback/diff), content-addressed idempotency (SHA-256), AgentMode gating (Research vs Governed), validation pipeline (Stage 1 artifact integrity + Stage 2 dry-run), batch publish with topological sort, governance audit log, retention/cleanup, 9-state ChangeSetStatus (incl. UnderReview/Approved from stewardship), 321 unit tests + 26 integration tests + 10 HTTP integration tests, 8 CLI subcommands, 10 REST routes, standalone sem_os_server deployment verified
> **CCIR — Context-Constrained Intent Resolution (Migration 103):** ✅ Complete + Sem OS envelope cutover (2026-03-18) - `SemOsContextEnvelope` replaces `SemRegVerbPolicy`, structured `PruneReason` (7 variants), deterministic `AllowedVerbSetFingerprint` (SHA-256), TOCTOU recheck, pre-constrained verb search (allowed verbs threaded into `HybridVerbSearcher`), Sem OS enforcement at `dsl_execute`, legacy V1 module cleanup (4 modules deleted: ~2,700 LOC), 16 unit tests
> **SessionVerbSurface:** ✅ Complete - Consolidated governance layer composition (SemReg CCIR + AgentMode + workflow phase + lifecycle + actor gating), 8-step compute pipeline, dual fingerprints (surface `vs1:` + SemReg `v1:`), FailClosed safe-harbor (~30 verbs), MCP tool `session_verb_surface`, REST endpoint `GET /api/session/:id/verb-surface`, ChatResponse enrichment, React VerbBrowser governance badges, 13 unit tests
> **Semantic OS Tab:** ✅ Complete - Agent-driven workflow selection UI (`/semantic-os`), goals→phase_tags verb scoping in SemReg, DecisionPacket workflow prompt (Onboarding/KYC/Data Management/Stewardship), session sidebar + registry context panel, `GET /api/sem-os/context` endpoint
> **SemOS Data Management Structure Contract:** ✅ Complete - noun-only exploration in `semos-data-management` / `semos-data` is structure-first, rewrites to `schema.entity.describe` / `schema.entity.*`, and instance-bound content verbs requiring `*-id` are blocked unless the user explicitly targets an instance
> **Scenario-Based Intent Resolution (Phases 0.5-5):** ✅ Complete — MacroIndex (Tier -2B) + ScenarioIndex (Tier -2A) + CompoundSignals + SequenceValidator; deterministic scoring ledger, 16 YAML scenarios (incl. 3 macro_sequence KYC workflows), ECIR short-circuit gating, provenance labels on macro expansion, progress narration ("Step 4 of 13: Lux UCITS SICAV Setup"), 43 Tier-2 test cases with 5 hard threshold assertions (spec §11)
> **AffinityGraph & Schema-Driven Diagram Generation:** ✅ Complete — Bidirectional verb↔data index (`sem_os_core::affinity`), 5-pass pure-Rust builder from active snapshots, 10 query methods (6 core + 4 governance), DiagramModel + MermaidRenderer (`sem_os_core::diagram`), 3 render modes (erDiagram/verb-flow/domain-map), 9 new verbs (6 registry.* + 3 schema.*), DomainMetadata YAML overlay, 6 CustomOps, 6 integration tests, 21,047 total embeddings
> **Discovery Pipeline (Phase 2):** ✅ Complete — `registry.discover-dsl` implemented end-to-end (utterance→intent matches→verb chain synthesis→disambiguation/governance context); `schema.generate-discovery-map` implemented with Mermaid projection
> **Utterance API Coverage Harness:** ✅ Complete — `rust/tests/utterance_api_coverage.rs` runs standard utterance fixtures through `/api/session/:id/execute` with `registry.discover-dsl`, emits JSON/MD/CSV coverage artifacts for expected↔predicted DSL verbs
> **Unified Session Input Cutover (First Cut):** ✅ Complete — single ingress endpoint `POST /api/session/:id/input` with adapter dispatch (`utterance`, `decision_reply`, `repl_v2`), legacy chat/decision/repl-input endpoints hard-blocked (410 Gone), React chat + REPL clients rewired, server call-stack trace confirms UI traffic enters only through unified input
> **Sage Intent Skeleton (Phase 1):** ✅ Complete — observation-plane + polarity pre-classification, deterministic and LLM-backed Sage engines, shadow wiring, Sage coverage harness, data-management structure-read fast-path prerequisites
> **Coder Rewrite (Phase 2):** ✅ Complete — verb metadata index, structured verb resolution, OutcomeStep arg assembly, Sage+Coder shadow comparison, utterance comparative harness, `SAGE_FAST_PATH=1` read+structure fast path for data-management schema introspection
> **Sage/Coder GATE 5:** ⚠️ Comparative harness run complete — existing pipeline `58/134` (`43.28%`), deterministic Sage+Coder `6/134` (`4.48%`), LLM-backed Sage+Coder `7/134` (`5.22%`); outcome points to vocabulary/routing work before further LLM spend
> **Sage-Primary Chat Narration:** ✅ Implemented — scoped inventory reads now default to safe read/list execution, write intents surface plain-language pending mutations, read pivots cancel pending mutations with an explicit chat notice, confirmation executes only when a mutation is still pending, and a stale `yes` now returns `There is no pending change to confirm. I am still in read-only mode.`
> **SemTaxonomy Rip-and-Replace (Three-Step Pipeline):** ✅ Cut over — the normal SemTaxonomy-enabled chat path now runs only `EntityScope -> EntityState -> SelectedVerb` via `rust/src/semtaxonomy_v2/mod.rs`; the old SemTaxonomy composition path has been removed from normal proposal selection, and Step 1 entity scope is now a hard gate that returns clarification instead of allowing ambiguity to cascade.
> **StateGraph Pipeline (Phase 0-3):** ✅ Substrate implemented + ⚠️ Phase 1 reconciliation parked — graph model, loader, walker, `discovery.graph-walk`, and Step 2 graph-backed narrowing are in place; safe Phase 1 metadata work is complete (`entity-context` signal enrichment, canonical invocation phrase enrichment, repo-derived reconciliation pack), but graph/corpus rewrites are intentionally blocked pending the authoritative external correction table for `struct.*`, `screening.full`, and any external graph-edge remaps.
> **Three-Step Harness State (2026-03-11):** ⚠️ Pipeline boundary is clean but metadata quality remains the limiter — live 176-utterance harness currently reports `14/176` (`7.95%`) exact hits, `125/176` (`71.02%`) grounded/stateful responses, and `84/176` business proposals after Step 3 hardening; this is materially better than the earlier 2-4% floor, but still below the legacy business-verb baseline and now clearly constrained by verb/graph metadata integrity rather than call-stack pollution.
> **NLCI CBU Cutover (2026-03-13):** ✅ Narrow CBU compiler slice is live in `rust/src/semtaxonomy_v2/cbu_compiler.rs` and preferred by orchestrator for `cbu.create`, `cbu.read`, `cbu.list`, narrow property verbs, and narrow lifecycle verbs; major duplicate phrase/discovery/test surfaces for those intents were removed rather than left as compatibility debt.
> **CBU Role Surface Reconciliation (2026-03-13):** ✅ Complete — active resolver/config/test/doc surfaces now use one public role namespace only: `cbu.assign-role`, `cbu.remove-role`, `cbu.parties`, plus specialist `cbu.assign-*` / `cbu.validate-roles`; legacy `cbu-role.*`, `cbu.role.*`, `cbu-role-v2`, and `cbu_role` naming was removed from active code/config/docs.
> **Phase 0 Vocabulary Rationalization (Batches 1-3):** ✅ Complete — domain merges/deletions (`case-screening`, `doc-request`, `product-subscription`, `fund-vehicle`, `fund-compartment`, `lifecycle`), type-parameterized family merges (`entity.*`, `ubo.*`, `sla.*`, `trading-profile.*`, `fund.*`), unified `refdata.*` runtime + tests
> **Schema Consolidation (Migrations 115-121):** ✅ Complete — runtime schemas collapsed to `"ob-poc"` for business data and `sem_reg*` for Semantic OS; retired schemas (`stewardship`, `agent`, `teams`, `feedback`, `events`, `sessions`, `ob_ref`, `ob_kyc`) removed from the live database
> **Domain Metadata Coverage:** ✅ Complete — `rust/config/sem_os_seeds/domain_metadata.yaml` now covers `306/306` live `"ob-poc"` tables, with SemOS footprint remediation applied for `sem-reg`, `stewardship`, and the 2026-03-13 CBU Constellation macro-alignment pack
> **CBU Constellation Remediation Pack (2026-03-13):** ✅ Complete — broken macro verb references were reconciled across the structure/mandate/party/case macro set, orphan SemOS footprints were removed, Tier A macro-referenced footprints were backfilled, client-group replacement footprints were remapped, and final validation closed at `Broken macro refs: 0`, `Orphan footprints: 0`, `Tier A missing: 0`
> **KYC/UBO Constellation Enablement (2026-03-13):** ✅ Complete — 29 macro flows were added across `kyc-workstream`, `ubo`, `evidence`, `doc-request`, `screening-ops`, `red-flag`, and `tollgate`; missing primitive verb contracts and SemOS footprints were backfilled; final validation closed at `Registry verbs: 1068`, `Broken macro refs: 0`, `Orphan footprints: 0`, `Total SemOS footprints: 281`, `Tier A missing: 0`
> **KYC/UBO Blocker Fixes (2026-03-13):** ✅ Complete — evidence macro self-resolution collisions were removed by renaming the primitive evidence verbs, `ubo.discover` now passes through `threshold` and `max-depth`, `OTHER` enum fallbacks were corrected for document requests and risk flags, and the post-fix validation gate stayed at `Broken macro refs: 0`, `Orphan footprints: 0`, `Tier A missing: 0`
> **State Reducer Runtime (2026-03-15):** ✅ Core + runtime surface live — parser/evaluator/validation, seeded reducer YAMLs, override persistence, `state.*` verbs, REST-backed constellation/reducer hydration, and integration coverage for reducer parsing/eval/validation plus constellation map/action/hydration tests
> **Constellation Hydration + Session UI (2026-03-15):** ✅ Live — builtin constellation maps, REST routes (`/api/cbu/:id/constellation`, `/summary`, `/cases`, `/api/constellation/by-name`, `/search-cbus`), session-integrated React constellation panel in chat, case selector bound to live CBU cases, ownership-chain node/edge payloads surfaced in the inspector, and slot-to-agent prompt loop wired through the normal chat session input path
> **Cross-Border CBU Structure Runtime (2026-03-15):** ✅ Live — persisted `"ob-poc".cbu_structure_links`, `cbu.link-structure` + `cbu.list-structure-links`, downward child-`cbu` hydration for `struct.hedge.cross-border` and `struct.pe.cross-border`, selector-backed feeder/parallel/aggregator slots, and cross-border macro steps unparked onto the real verb surface
> **DB Integration Harness + Cross-Border Verification (2026-03-16):** ✅ Complete — runtime verb registry bootstrap is fixed in test context, `db_integration` now self-provisions lagging `cbu_structure_links` schema in local harness runs, reducer evidence overlays are aligned to the live `ubo_registry` / `kyc_ubo_evidence` schema, generic `entity.create` now fills required extension-table name columns such as `company_name`, and both `cargo clippy -p ob-poc -- -D warnings` and `cargo test -p ob-poc --test db_integration` are green
> **Architecture Remediation Pack (2026-03-16):** ✅ Transport/model/runtime remediation landed — critical FK/archive/intent-event fixes, DSL parser empty-string + boolean boundary fix, KYC lifecycle reconciliation onto ontology-backed guards, governed-tier bootstrap for taxonomy/view/membership/KYC verb seeds through the scanner path, reducer-state persistence, governed verb metadata enrichment (`harm_class`, `action_class`, `phase_tags` verification), and soft-delete enforcement for live `cbus` / `entities` across high-traffic runtime reads with DB regression coverage in `soft_delete_db`, `generic_lifecycle_guard_db`, and `reducer_persistence_db`
> **Sem OS Discovery Cutover (2026-03-17):** ✅ Live on the Sage path — Sem OS is now fail-closed for utterance discovery, discovery-stage `resolve_context()` returns a structured bootstrap surface (`matched_domains`, `matched_families`, `matched_constellations`, `missing_inputs`, `entry_questions`, `grounding_readiness`), the chat API/UI renders that bootstrap surface directly, and bootstrap selections flow back into session state and into Sem OS as structured discovery hints instead of widening to legacy global verb search
> **Sem OS Non-Lossy Utterance Contract (2026-03-17):** ✅ Live on the Sem OS path — `ContextResolutionRequest` now carries `raw_utterance` separately from `intent_summary`, so Sage summaries no longer replace the original user wording when Sem OS scores discovery/domain/family/constellation matches
> **Sem OS Discovery Harness (2026-03-17):** ✅ New baseline harness — `rust/tests/semos_discovery_hit_rate.rs` measures utterance → domain/family/constellation/readiness against the Sem OS discovery resolver using real authored universe/family seeds, including a regression case where the raw utterance carries trigger terms absent from `intent_summary`; current seeded corpus baseline is 100% across domain/family/constellation/readiness on the small authored discovery set
> **Sem OS Reconciliation Remediation (2026-03-19 / verified 2026-03-21):** ✅ Complete — reconciliation findings from `docs/todo/semos-reconciliation-findings-2026-03-19.md` are remediated in the live stack and verified at code level: direct `HybridVerbSearcher` paths accept `entity_kind`, canonical kinds include `fund`/`document`/`contract`/`trading-profile`/`deal`/`cbu`, runtime + SemOS `subject_kinds` filtering/prune visibility are wired, low-confidence entity signals widen instead of over-pruning, discovery bootstrap questions are actionable in chat, authored discovery families for trading/billing/deal/contract influence SemOS family selection and are validated against the runtime verb registry, macro post-expansion DSL is re-validated before runbook assembly, fail-closed safe-harbor verbs are audited against `harm_class` at startup, and parked runbook reasons surface through the chat API/UI; direct verification now includes `cargo check`, `cargo fmt --check`, `cargo clippy -- -D warnings`, and the feature-gated regression `cargo test --features vnext-repl --lib test_macro_expansion_revalidates_unknown_runtime_verbs -- --nocapture`
> **Workspace Hygiene Pass (2026-03-19):** ✅ Full Rust workspace clean — `cargo fmt` plus `RUSTC_WRAPPER= SCCACHE_DISABLE=1 cargo clippy --workspace --all-targets -- -D warnings` now pass across workspace crates, tests, bins, xtask, and harness code; stale all-target drift after the SemOS reconciliation work was removed rather than suppressed

This is the root project guide for Claude Code. Domain-specific details are in annexes.

---

## Quick Start

```bash
cd rust/

# Agentic Scenario Harness
cargo x harness list                               # List all suites + scenario counts
cargo x harness run --all                           # Run all 48 scenarios (needs DATABASE_URL)
cargo x harness run --suite scenarios/suites/governance_strict.yaml  # Run one suite
cargo x harness run --scenario direct_dsl_denied_viewer             # Run one scenario by name
cargo x harness dump --scenario direct_dsl_denied_viewer            # Dump artifacts to JSON

# Pre-commit (fast)
cargo x pre-commit          # Format + clippy + unit tests

# Full check
cargo x check --db          # Include database integration tests

# Deploy (Full stack: React frontend + Rust backend)
cargo x deploy              # Build React + server + start
cargo x deploy --skip-frontend  # Skip React rebuild (backend only)

# Run server directly (serves React from ob-poc-ui-react/dist/)
DATABASE_URL="postgresql:///data_designer" cargo run -p ob-poc-web

# React development (hot reload)
cd ob-poc-ui-react && npm run dev  # Runs on port 5173, proxies API to :3000

# BPMN-Lite service (standalone workspace at bpmn-lite/)
cargo x bpmn-lite build            # Build bpmn-lite workspace
cargo x bpmn-lite build --release  # Release build
cargo x bpmn-lite test             # Run all 71 tests (+ 1 ignored gRPC smoke test)
cargo x bpmn-lite clippy           # Lint
cargo x bpmn-lite start            # Build release + start native (port 50051, MemoryStore)
cargo x bpmn-lite start --database-url postgresql:///data_designer  # Start with PostgresProcessStore
cargo x bpmn-lite stop             # Stop native server
cargo x bpmn-lite status           # Show native + Docker status
cargo x bpmn-lite docker-build     # Build Docker image
cargo x bpmn-lite deploy           # Docker build + compose up

# Schema overview (living doc with mermaid ER diagrams)
# Regenerate PDF after schema changes:
npx md-to-pdf migrations/OB_POC_SCHEMA_ENTITY_OVERVIEW.md

# Refresh schema exports from the live source DB
cargo x schema-export
```

Current schema export target:
- canonical dump: `migrations/master-schema.sql`
- convenience copy: `schema_export.sql`
- source DB: local `data_designer` via `pg_dump`

---

## React Frontend (ob-poc-ui-react)

> **UI Migration:** The UI has been migrated from egui/WASM to React/TypeScript. The old `ob-poc-ui` and `esper_egui` crates are deprecated.

### Architecture

```
ob-poc-ui-react/
├── src/
│   ├── api/              # API client (chat.ts, scope.ts, semOs.ts)
│   ├── features/
│   │   ├── chat/         # Agent chat UI with scope panel
│   │   ├── semantic-os/  # Semantic OS workflow UI
│   │   ├── inspector/    # Projection inspector (tree + detail)
│   │   └── settings/     # App settings
│   ├── stores/           # Zustand state management
│   ├── types/            # TypeScript types
│   └── lib/              # Utilities, query client
├── dist/                 # Production build (served by Rust)
└── package.json
```

### Key Endpoints (Backend → React)

| Endpoint | Purpose |
|----------|---------|
| `POST /api/session` | Create agent session (with optional `workflow_focus`) |
| `GET /api/session/:id` | Get session with messages |
| `POST /api/session/:id/input` | Unified session input ingress (`kind=utterance|decision_reply|repl_v2`) |
| `GET /api/session/:id/scope-graph` | Get loaded CBUs (scope) |
| `GET /api/cbu/:id/graph` | Get single CBU's entity graph |
| `GET /api/cbu/:id/constellation` | Get hydrated constellation tree for a CBU/case |
| `GET /api/cbu/:id/constellation/summary` | Get constellation summary metrics |
| `GET /api/cbu/:id/cases` | List available KYC cases for constellation binding |
| `GET /api/constellation/by-name` | Resolve a CBU by name and hydrate its constellation |
| `GET /api/constellation/search-cbus` | Search CBUs for constellation workflows |
| `GET /api/projections/:id` | Get Inspector projection |
| `GET /api/sem-os/context` | Get Semantic OS registry stats + recent changesets |

### Unified Input Cutover (2026-03-05)

- **Single ingress:** All user prompts/utterances from chat UI and REPL UI now post to `POST /api/session/:id/input`.
- **Adapter dispatch:** Request `kind` selects server adapter path:
  - `utterance` → agent chat orchestration
  - `decision_reply` → DecisionPacket reply handling
  - `repl_v2` → REPL V2 orchestrator input handling
- **Legacy hard block (enforced):** `POST /api/session/:id/chat`, `POST /api/session/:id/decision/reply`, and `POST /api/repl/v2/session/:id/input` return `410 Gone`.
- **Tracing requirement:** endpoint adoption is validated via component-level call-stack trace (UI callsite → API client → HTTP endpoint → server route → adapter).

### Development

```bash
cd ob-poc-ui-react

# Install dependencies
npm install

# Development server (hot reload, proxies to :3000)
npm run dev

# Production build
npm run build

# Type check
npm run typecheck

# Lint
npm run lint
```

### Chat Page Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│  [Sessions]  │  [Chat Messages]                    │  [Scope Panel] │
│              │                                     │                │
│  Session 1   │  User: load allianz book            │  Scope (100)   │
│  Session 2   │  Agent: 100 CBUs in scope           │  ├─ Allianz A  │
│  + New       │                                     │  ├─ Allianz B  │
│              │  [Input: Type a message...]         │  └─ ...        │
└─────────────────────────────────────────────────────────────────────┘
```

### Scope Panel

The right-side panel shows loaded CBUs and supports drill-down:
- **CBU List**: Click any CBU to see its entities
- **Entity View**: Shows entities within the CBU (persons, organizations)
- **Auto-refresh**: Updates every 5 seconds to reflect DSL execution

### Constellation Panel

The chat right rail now also includes a session-integrated constellation surface:
- **Shared CBU focus**: Uses the same selected CBU as the scope panel
- **Case binding**: Lists available `"ob-poc".cases` for the selected CBU and defaults to the newest case when present
- **Server-side state**: Renders reducer-derived slot state from `/api/cbu/:id/constellation`
- **Ownership chain**: Shows graph node/edge payloads for `entity_graph` slots in the slot inspector
- **Agent loop closure**: “Ask Agent” and “Ask Why Blocked” buttons submit structured prompts through the same `POST /api/session/:id/input` chat path

### Semantic OS Tab

The `/semantic-os` route provides an agent-driven workflow for Semantic OS operations. Sessions start with a workflow selection prompt that constrains which verbs the pipeline considers via SemReg `phase_tags` filtering.

```
┌─────────────────────────────────────────────────────────────────────┐
│  [Sessions]  │  [Chat Messages]                    │  [Context]     │
│              │                                     │                │
│  Session 1   │  Agent: What would you like to      │  Registry Stats│
│  Session 2   │  work on?                           │  ├─ Attrs: 120 │
│  + New       │  [Onboarding] [KYC]                 │  ├─ Verbs: 340 │
│              │  [Data Mgmt] [Stewardship]          │  └─ ...        │
│              │                                     │  Changesets    │
│              │  [Input: Type a message...]         │  └─ Draft: 3   │
└─────────────────────────────────────────────────────────────────────┘
```

**Workflow Selection Flow:**
1. User clicks "New Session" → `POST /api/session { workflow_focus: "semantic-os" }`
2. Backend returns `DecisionPacket` with 4 workflow choices (Onboarding, KYC, Data Management, Stewardship)
3. User selects workflow → sets `session.context.stage_focus = "semos-{workflow}"`
4. All subsequent utterances flow through SemReg with `goals = ["{workflow}"]`
5. `filter_and_rank_verbs()` filters to verbs whose `phase_tags` overlap with goals

**Goals → Phase Tags Pipeline:**
```
stage_focus "semos-kyc" → goals ["kyc"] → ContextResolutionRequest
    → filter_and_rank_verbs(goals=["kyc"])
    → verb.phase_tags contains "kyc"? include + boost
    → ContextEnvelope { allowed_verbs } → IntentPipeline
```

**Key Files:**

| File | Purpose |
|------|---------|
| `ob-poc-ui-react/src/features/semantic-os/SemOsPage.tsx` | 3-column layout (sidebar, chat, context panel) |
| `ob-poc-ui-react/src/features/semantic-os/components/SemOsSidebar.tsx` | Session list with own localStorage (`ob-poc-semos-sessions`) |
| `ob-poc-ui-react/src/features/semantic-os/components/SemOsContextPanel.tsx` | Registry stats + recent changesets (auto-refresh 10s) |
| `ob-poc-ui-react/src/api/semOs.ts` | API client for `GET /api/sem-os/context` |
| `rust/src/api/agent_routes.rs` | Session creation with `workflow_focus` + DecisionPacket |
| `rust/src/sem_reg/context_resolution.rs` | `filter_and_rank_verbs()` with goals→phase_tags filtering |

---

## Non-Negotiable Implementation Rules

These rules are **mandatory** for all code changes. No exceptions.

### 1. Type Safety First

**Never use untyped JSON (`serde_json::json!`) for structured data.** Always define typed structs.

```rust
// ❌ WRONG - Untyped, no compile-time guarantees
Ok(ExecutionResult::Record(serde_json::json!({
    "groups_created": row.0,
    "memberships_created": row.1,
})))

// ✅ CORRECT - Typed struct with Serialize/Deserialize
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeriveGroupsResult {
    pub groups_created: i32,
    pub memberships_created: i32,
}

let result = DeriveGroupsResult {
    groups_created: row.0,
    memberships_created: row.1,
};
Ok(ExecutionResult::Record(serde_json::to_value(result)?))
```

**Where to define types:**
- Domain result types → `ob-poc-types` crate (e.g., `manco_group.rs`, `trading_matrix.rs`)
- DSL config types → `dsl-core/src/config/types.rs`
- API response types → Near the route handler or in a shared `types.rs`

**Benefits:**
- Compile-time field name checking
- Refactoring safety (rename field → compiler finds all uses)
- IDE autocomplete and documentation
- Consistent serialization (snake_case via serde)

### 2. Consistent Return Types

YAML verb definitions use `ReturnTypeConfig` enum. Map these to typed Rust structs:

| YAML `returns.type` | Rust Pattern |
|---------------------|--------------|
| `uuid` | `ExecutionResult::Uuid(uuid)` |
| `record` | `ExecutionResult::Record(serde_json::to_value(typed_struct)?)` |
| `record_set` | `ExecutionResult::RecordSet(vec_of_typed_structs.iter().map(serde_json::to_value).collect())` |
| `affected` | `ExecutionResult::Affected(count)` |
| `void` | `ExecutionResult::Void` |

### 3. Option<T> for Nullable/Optional Values

Use `Option<T>` consistently:

```rust
// ✅ CORRECT - Explicit optionality
pub struct ControlChainNode {
    pub entity_id: Uuid,                      // Required
    pub controlled_by_entity_id: Option<Uuid>, // Optional (None for root)
    pub voting_pct: Option<Decimal>,          // Optional
}

// ❌ WRONG - Sentinel values or silent nulls
pub voting_pct: Decimal,  // What does 0.0 mean? Missing or zero?
```

### 4. Error Types over Panics

Use `Result<T, E>` and `?` operator. Never `.unwrap()` in production code paths.

```rust
// ❌ WRONG
let value = map.get("key").unwrap();

// ✅ CORRECT
let value = map.get("key").ok_or_else(|| anyhow!("Missing key"))?;
```

### 5. Re-export Types at Module Boundary

When a module uses types from another crate, re-export them for consumers:

```rust
// In domain_ops/manco_ops.rs
pub use ob_poc_types::manco_group::{
    DeriveGroupsResult, BridgeRolesResult, ControlChainNode, // ...
};
```

---

## Agent Chat `/commands` Help

The agent chat includes a built-in help system. Type `/commands` to see available operations with natural language examples.

**Chat Commands:**
| Command | Description |
|---------|-------------|
| `/commands` | Full command reference with natural language examples |
| `/verbs` | List all DSL verbs |
| `/verbs <domain>` | Verbs for specific domain (e.g., `/verbs kyc`, `/verbs session`) |
| `/help` | Quick help |

**Categories in `/commands`:**

| Section | Content |
|---------|---------|
| **DSL Operations** | `dsl_validate`, `dsl_execute`, `dsl_generate` with NL examples |
| **Session & Navigation** | Load/unload CBUs, undo/redo, scope management |
| **CBU & Entity** | Create, search, roles, products |
| **View & Zoom (ESPER)** | "enhance", "drill", "surface", "follow the money" |
| **KYC & UBO** | Case management, ownership discovery, screening |
| **Trading Profile & Custody** | Instruments, markets, SSIs |
| **Research Macros** | GLEIF lookup, UBO research, approval flow |
| **Learning & Feedback** | Pattern learning, corrections, semantic status |
| **Promotion Pipeline** | Quality-gated auto-promotion with thresholds |
| **Teaching** | Direct phrase→verb mapping for trusted sources |
| **Workflow & Templates** | Workflow instances, template expansion |
| **Batch Operations** | Multi-entity template application |

**Example Natural Language → DSL:**

```
User: "create a fund for Acme Corp"
→ dsl_generate
→ (cbu.create :name "Acme Corp" :type FUND)

User: "load the Allianz book"  
→ (session.load-galaxy :apex-name "Allianz")

User: "who owns this company?"
→ (ubo.discover :entity-id @entity)

User: "teach: 'spin up a fund' = cbu.create"
→ (agent.teach :phrase "spin up a fund" :verb "cbu.create")
```

**Key file:** `rust/src/api/agent_routes.rs` - `generate_commands_help()`

---

## Core Architecture: CBU-Centric Model

**CBU (Client Business Unit) is the atomic unit.** Everything resolves to sets of CBUs.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         SESSION = Set<CBU>                                   │
│                                                                              │
│   Universe (all CBUs)                                                        │
│     └── Book (commercial client's CBUs: Allianz, BlackRock)                 │
│          └── CBU (single trading unit)                                       │
│               ├── TRADING view (default) - instruments, counterparties      │
│               └── UBO view (KYC mode) - ownership/control taxonomy          │
│                    └── Entity drill-down (within UBO context only)          │
│                                                                              │
│   Group structure cross-links CBUs via ownership/control edges              │
│   Clusters/galaxies are DERIVED from these edges, not stored                │
└─────────────────────────────────────────────────────────────────────────────┘
```

### ViewMode (Simplified)

`ViewMode` is a unit struct - always TRADING (CBU view). The old multi-mode enum (`KYC_UBO`, `SERVICE_DELIVERY`, `PRODUCTS_ONLY`, `BOARD_CONTROL`) was removed.

```rust
// Current implementation (graph/mod.rs)
pub struct ViewMode;  // Always "TRADING"
```

For KYC/UBO work, use `view.cbu :mode ubo` which switches to ownership taxonomy within the CBU.

### GraphScope (How Sessions Resolve)

```rust
pub enum GraphScope {
    Empty,                                    // Initial state
    SingleCbu { cbu_id, cbu_name },          // Single CBU focus
    Book { apex_entity_id, apex_name },      // All CBUs under apex
    Jurisdiction { code },                    // All CBUs in jurisdiction
    EntityNeighborhood { entity_id, hops },  // N hops from entity (UBO context)
    Custom { description },                   // Custom filter
}
```

### Astro Scale Levels (Zoom/Layout)

These are **UI zoom levels using CBU and group structures**, not session scope changes:

| Level | What You See | Zoom Action |
|-------|--------------|-------------|
| Universe | All CBUs as dots | Zoom out to see everything |
| Cluster/Galaxy | Segment view (by apex/jurisdiction) | Group CBUs by ownership |
| System | Single CBU expanded | Focus on one CBU |
| Planet | Entity within CBU | Drill into CBU's entities |
| Surface/Core | Deep detail | Max zoom on entity attributes |

---

## Domain Annexes

| When working on... | Read this annex | Contains |
|--------------------|-----------------|----------|
| **Semantic pipeline** | `docs/agent-semantic-pipeline.md` | Candle embeddings, tiered search (ECIR + embedding), latency analysis |
| **Agent/MCP pipeline** | `docs/agent-architecture.md` | Intent extraction, MCP tools, learning loop |
| **Session & navigation** | `docs/session-visualization-architecture.md` | Scopes, filters, ESPER verbs, history |
| **Data model (CBU/Entity/UBO)** | `docs/strategy-patterns.md` §1 | Why CBU is a lens, UBO discovery, holdings |
| **Verb authoring** | `docs/verb-definition-spec.md` | YAML structure, valid values, common errors |
| **React frontend** | CLAUDE.md §React Frontend | Chat UI, scope panel, API endpoints |
| **Entity model & schema** | `docs/entity-model-ascii.md` | Full ERD, table relationships |
| **Schema overview (living doc)** | `migrations/OB_POC_SCHEMA_ENTITY_OVERVIEW.md` | ob-poc schema: 14 domain sections, ~150 tables, 10 mermaid ER diagrams, DSL verb domain cross-ref |
| **DSL pipeline** | `docs/dsl-verb-flow.md` | Parser, compiler, executor, plugins |
| **Research workflows** | `docs/research-agent-annex.md` | GLEIF, agent mode, invocation phrases |
| **V2 REPL invariants** | `docs/INVARIANT-VERIFICATION.md` | P-1 through P-5, E-1 through E-8, enforcing code citations |

### AI-Thoughts (Design Decisions)

| Topic | Document | Status |
|-------|----------|--------|
| Group/UBO ownership | `ai-thoughts/019-group-taxonomy-intra-company-ownership.md` | ✅ Done |
| Research workflows | `ai-thoughts/020-research-workflows-external-sources.md` | ✅ Done |
| Source loaders | `ai-thoughts/021-pluggable-research-source-loaders.md` | ✅ Done |
| Event infrastructure | `ai-thoughts/023a-event-infrastructure.md` | ✅ Done |
| Feedback inspector | `ai-thoughts/023b-feedback-inspector.md` | ✅ Done |
| Entity disambiguation | `ai-thoughts/025-entity-disambiguation-ux.md` | ✅ Done |
| Trading matrix pivot | `ai-thoughts/027-trading-matrix-canonical-pivot.md` | ✅ Done |
| Verb governance | `ai-thoughts/028-verb-lexicon-governance.md` | ✅ Done |
| Entity resolution wiring | `ai-thoughts/033-entity-resolution-wiring-plan.md` | ✅ Done |
| REPL state model | `ai-thoughts/034-repl-state-model-dsl-agent-protocol.md` | ✅ Done |
| Session-runsheet-viewport | `ai-thoughts/035-session-runsheet-viewport-integration.md` | ✅ Done |
| Session rip-and-replace | `ai-thoughts/036-session-rip-and-replace.md` | ✅ Done |
| Solar navigation | `ai-thoughts/038-solar-navigation-unified-design.md` | ✅ Done |
| Lexicon service | `ai-thoughts/072-lexicon-service-implementation-plan.md` | ✅ Done |
| Entity linking | `ai-thoughts/073-entity-linking-implementation-plan.md` | ✅ Done |

---

## DSL Pipeline (Single Path)

**ALL DSL generation goes through this pipeline. No bypass paths.**

```
User says: "spin up a fund for Acme"
                    ↓
            verb_search tool
                    ↓
    ┌───────────────┴───────────────────┐
    │     Search Priority (10-tier)      │
    │ -2A. ScenarioIndex (journey-level) │
    │ -2B. MacroIndex (macro search parity)│
    │ -1. ECIR noun taxonomy (deterministic) │
    │  0. Operator macros (business vocab)│
    │  1. User learned (exact)           │
    │  2. Global learned (exact)         │
    │  3. Semantic (pgvector)            │
    │  5. Blocklist check                │
    │  6. Global semantic fallback       │
    │  7. Phonetic fallback              │
    └───────────────┬───────────────────┘
                    ↓
            Top match: cbu.create
                    ↓
            dsl_generate tool
                    ↓
    LLM extracts args as JSON (NOT DSL)
                    ↓
    Deterministic DSL assembly
                    ↓
            (cbu.create :name "Acme")
                    ↓
            dsl_execute tool
```

### PolicyGate (Single Pipeline Enforcement)

> ✅ **IMPLEMENTED (2026-02-14)**: Server-side enforcement of single-pipeline invariants.

**Key Files:**
- `rust/src/policy/gate.rs` — `PolicyGate`, `ActorResolver`, `PolicySnapshot`
- `rust/src/agent/orchestrator.rs` — Accepts `PolicyGate`, SemReg fail-closed, IntentTrace with PolicySnapshot
  - `SemOsContextEnvelope` replaces `SemRegVerbPolicy`: carries allowed verbs, pruned verbs with structured `PruneReason`, fingerprint, evidence gaps, governance signals, and discovery bootstrap surface
  - Pre-constrained verb search: allowed verbs threaded into `IntentPipeline.with_allowed_verbs()` → `HybridVerbSearcher` (Phase 3 CCIR)
  - AST-based macro governance: `parse_program()` + `VerbCall::full_name()` extracts verbs from macro expansions
  - IntentTrace fields: `selection_source` (discovery/user_choice/macro/semreg), `macro_semreg_checked`, `macro_denied_verbs`, `forced_verb`, `allowed_verbs_fingerprint`, `pruned_verbs_count`, `toctou_recheck_performed`, `toctou_result`, `toctou_new_fingerprint`
  - `/select-verb` retired (410 Gone) — verb selection routed through `POST /api/session/:id/input` (`kind=decision_reply`) → orchestrator forced-verb
- `rust/src/agent/sem_os_context_envelope.rs` — `SemOsContextEnvelope`, `PruneReason` (7 variants), `AllowedVerbSetFingerprint`, `TocTouResult`, 16 unit tests
- `rust/src/session/unified.rs` — `RunSheet.runnable_dsl()` returns only Draft/Ready entries (prevents re-executing already-run entries)
- `rust/src/agent/telemetry/` — Append-only intent telemetry (PII-safe)
  - `mod.rs`: `IntentEventRow` model, `outcome_label()`, `candidates_to_json()`
  - `redaction.rs`: `normalize_utterance()`, `utterance_hash()` (SHA-256), `preview_redacted()` (max 80 chars)
  - `store.rs`: `insert_intent_event()` — best-effort write, never fails pipeline
  - Single emission point: only `orchestrator.rs` calls `emit_telemetry()` (static guard test)
  - Migration 087: `agent.intent_events` table + 5 review views (clarify hotspots, SemReg overrides/denies, macro denies, failure modes)
  - Migration 103: CCIR telemetry columns (`allowed_verbs_fingerprint`, `pruned_verbs_count`, `toctou_recheck_performed`, `toctou_result`, `toctou_new_fingerprint`)
- `rust/src/agent/harness/` — Agentic Scenario Test Harness (deterministic pipeline testing)
  - `mod.rs`: YAML schema types (`ScenarioSuite`, `Scenario`, `ScenarioStep`, `StepExpectation`), suite loader
  - `assertions.rs`: Partial assertion engine — checks only specified fields (outcome, verb, SemReg, trace, run_sheet)
  - `runner.rs`: Multi-turn state machine runner — drives orchestrator per step, tracks deltas, dumps artifacts on failure
  - `stub.rs`: Stub `OrchestratorContext` builder using `HybridVerbSearcher::minimal()` + configurable `PolicyGate`
  - `rust/xtask/src/harness.rs`: CLI runner (list/run/dump subcommands)
  - `scenarios/suites/*.yaml`: 10 suites, 48 scenarios (governance, routing, macros, runsheet, clarification, DSL bypass, SemReg, trace, scope, edge cases)
  - **Adding scenarios:** Create YAML in `scenarios/suites/`, follow schema (name, suite_id, mode_expectations, session_seed, scenarios[].steps[].user + expect)
- `docs/architecture/SINGLE_PIPELINE_INVARIANTS.md` — Full invariant table

**Policy Flags (env vars):**

| Variable | Default | Effect |
|---|---|---|
| `OBPOC_STRICT_SINGLE_PIPELINE` | `true` | Enables all single-pipeline gates |
| `OBPOC_ALLOW_RAW_EXECUTE` | `false` | Allows `/execute` with raw DSL |
| `OBPOC_STRICT_SEMREG` | `true` | SemReg deny-all fails closed |
| `OBPOC_ALLOW_LEGACY_GENERATE` | `false` | Allows legacy `/generate` endpoints |

**Actor Resolution (no more hardcoded "operator"):**

| Source | Resolver | Default Role |
|---|---|---|
| HTTP API | `ActorResolver::from_headers()` | `viewer` |
| MCP | `ActorResolver::from_env()` | `viewer` |
| REPL | `ActorResolver::from_session_id()` | `viewer` |

### Why This Matters: LLM Removed from Semantic Loop

**Before Candle:** Verb discovery required LLM call (200-500ms, network, API cost).
**After Candle:** Verb discovery is pure Rust (5-15ms, local, free).

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  VERB DISCOVERY (100% Rust, NO LLM)                                         │
│                                                                              │
│  User: "set up an ISDA"                                                     │
│      ↓                                                                       │
│  Candle embed (local)          5-15ms   ← Pure Rust, no network             │
│      ↓                                                                       │
│  pgvector similarity           <1ms     ← In-memory index                   │
│      ↓                                                                       │
│  Result: isda.create           ────────── Total: 6-16ms                     │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│  ARG EXTRACTION (LLM still needed)                                          │
│                                                                              │
│  LLM extracts JSON args        200-500ms  ← Only LLM call in pipeline       │
│      ↓                                                                       │
│  DSL builder (Rust)            1-5ms                                        │
│      ↓                                                                       │
│  (isda.create :counterparty "Goldman" :governing-law "NY")                  │
└─────────────────────────────────────────────────────────────────────────────┘
```

| Metric | Before (OpenAI) | After (Candle) | Improvement |
|--------|-----------------|----------------|-------------|
| Embedding latency | 100-300ms | 5-15ms | **10-20x faster** |
| Network required | Yes | No | **Offline capable** |
| Cost per embed | $0.00002 | $0 | **100% savings** |
| LLM calls per query | 2 (discover + extract) | 1 (extract only) | **50% reduction** |

> **Full details:** `docs/agent-semantic-pipeline.md`

### Intent Pipeline Fixes (042)

> ✅ **IMPLEMENTED (2026-01-21)**: Full correctness fixes for verb search, entity resolution, and ambiguity detection.

**Issues Fixed:**

| Issue | Problem | Fix |
|-------|---------|-----|
| **C** | Unresolved refs lacked metadata | Parse → enrich → canonical walker with `entity_type`, `search_column`, `ref_id` |
| **K** | List/map commit broke (shared span) | Commit by `ref_id` (includes `:list_index` suffix), `dsl_hash` guard |
| **J/D** | LIMIT 1 prevented ambiguity detection | Top-k semantic search + `normalize_candidates()` + `AMBIGUITY_MARGIN = 0.05` |
| **I** | Two competing global sources | Union `agent.invocation_phrases` + `verb_pattern_embeddings`, dedupe by verb |
| **G** | Embedding computed 4x per search | Compute once at top of `search()`, pass through |
| **H** | Hardcoded 0.5 threshold | Added `fallback_threshold` (0.70), `semantic_threshold` (0.78) |

**Search Priority (Updated):**

```
-2A. ScenarioIndex (journey-level) — compound utterances → macro/sequence/selector (score 0.97)
-2B. MacroIndex (macro search parity) — single-macro utterances → macro match (score 0.96)
-1. ECIR noun taxonomy (deterministic) - score 0.95 single-verb, +0.05 post-boost multi-verb
 0. Operator macros (business vocabulary) - score 1.0 exact, 0.95 fuzzy
 1. User-specific learned (exact) - score 1.0
 2. Global learned (exact) - score 1.0
 3. User-specific learned (semantic, top-k=3)
 4. [REMOVED] - merged into step 6
 5. Blocklist filter
 6. Global semantic - UNION of learned + cold-start patterns (top-k)
    → normalize_candidates(): dedupe by verb, sort desc, truncate
    → Final blocklist filter across all candidates
 7. Phonetic fallback (typo handling) - score 0.80
```

**Ambiguity Detection:**

```rust
const AMBIGUITY_MARGIN: f32 = 0.05;

pub enum VerbSearchOutcome {
    Matched(VerbSearchResult),           // Clear winner
    Ambiguous { top, runner_up, margin }, // Need clarification
    NoMatch,                              // Below threshold
}

// Pipeline returns NeedsClarification early, does NOT call LLM
```

**Entity Resolution (ref_id for Lists/Maps):**

```rust
// Each list item gets unique ref_id: "stmt_idx:start-end:list_index"
// Commit endpoint uses ref_id, not span, to target exact EntityRef

POST /api/dsl/resolve-by-ref-id
{
  "session_id": "...",
  "ref_id": "0:40-80:0",        // First item in list
  "resolved_key": "uuid-...",
  "dsl_hash": "a1b2c3d4..."     // Optimistic concurrency
}
```

**Key Files:**
- `rust/src/mcp/intent_pipeline.rs` - Pipeline with `IntentArgValue`, fail-early
- `rust/src/mcp/verb_search.rs` - `normalize_candidates()`, top-k, single embed
- `rust/crates/dsl-core/src/ast.rs` - `find_unresolved_ref_locations()` uses stored `ref_id`
- `rust/src/api/agent_routes.rs` - `resolve_by_ref_id` endpoint
- `intent-pipeline-fixes-todo.md` - Full spec with 12-point PR review rubric

### Embeddings: Candle Local (BGE Retrieval Model)

| Component | Value |
|-----------|-------|
| Framework | HuggingFace Candle (pure Rust) |
| Model | BAAI/bge-small-en-v1.5 |
| Dimensions | 384 |
| Latency | 5-15ms |
| Storage | pgvector (IVFFlat) |
| API Key | Not required |
| Mode | Asymmetric retrieval (query→target) |

**BGE vs MiniLM:**
- **BGE** is retrieval-optimized: user queries search against stored verb patterns
- Uses CLS token pooling (not mean pooling)
- Queries prefixed with instruction: `"Represent this sentence for searching relevant passages: "`
- Targets (verb patterns) stored without prefix
- Scores cluster higher (0.6-1.0) than MiniLM (0.3-1.0), thresholds recalibrated

**API Distinction:**
```rust
// User input - searching for verbs
embedder.embed_query("load the allianz book")

// Verb patterns - stored in DB
embedder.embed_target("load galaxy by apex name")
```

### Candle Semantic Pipeline - DB as Source of Truth

> ✅ **IMPLEMENTED (2026-01-19)**: Full pipeline operational with DB-sourced patterns.

**Architecture:**

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SOURCE OF TRUTH: dsl_verbs.intent_patterns               │
│                                                                              │
│   YAML invocation_phrases                                                    │
│         │                                                                    │
│         ▼                                                                    │
│   VerbSyncService.sync_all_with_phrases() [server startup]                  │
│         │                                                                    │
│         ▼                                                                    │
│   dsl_verbs.intent_patterns (1263 verbs, 15940 patterns)                    │
│         │                                                                    │
│         ▼                                                                    │
│   populate_embeddings [binary]                                               │
│   - Reads from v_verb_intent_patterns view                                  │
│   - BGE embeds each pattern (384-dim, embed_target mode)                    │
│   - Inserts to verb_pattern_embeddings with phonetic codes                  │
│         │                                                                    │
│         ▼                                                                    │
│   verb_pattern_embeddings (15940 patterns with vectors)                     │
│         │                                                                    │
│         ▼                                                                    │
│   HybridVerbSearcher.search_global_semantic()                               │
│   - pgvector cosine similarity                                               │
│   - Returns ranked verb matches                                              │
│                                                                              │
│   Learning loop:                                                             │
│   PatternLearner → add_learned_pattern() → dsl_verbs.intent_patterns        │
│                         ↑                                                    │
│   (Re-run populate_embeddings to pick up new patterns)                      │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Key Files:**

| File | Purpose |
|------|---------|
| `rust/src/database/verb_service.rs` | `VerbService` - centralized verb DB access |
| `rust/src/mcp/verb_search.rs` | `HybridVerbSearcher` - semantic search (uses VerbService) |
| `rust/src/mcp/noun_index.rs` | `NounIndex` + `VerbContractIndex` - ECIR deterministic Tier -1 noun→verb resolution |
| `rust/config/noun_index.yaml` | 99-noun taxonomy mapping domain nouns to verb candidates |
| `rust/src/mcp/scenario_index.rs` | `ScenarioIndex` - Tier -2A journey-level scenario resolution |
| `rust/src/mcp/compound_intent.rs` | `CompoundSignals` - shared compound signal extraction |
| `rust/src/mcp/sequence_validator.rs` | Macro sequence prereq validation |
| `rust/src/mcp/macro_index.rs` | `MacroIndex` - Tier -2B deterministic macro search |
| `rust/config/scenario_index.yaml` | 16 journey scenario definitions (incl. 3 macro_sequence) |
| `rust/config/macro_search_overrides.yaml` | Curated macro search aliases |
| `rust/src/session/verb_sync.rs` | `VerbSyncService` - syncs YAML to DB |
| `rust/crates/ob-semantic-matcher/src/bin/populate_embeddings.rs` | Populates verb_pattern_embeddings |
| `rust/crates/ob-semantic-matcher/src/feedback/learner.rs` | Learning loop |
| `migrations/037_candle_pipeline_complete.sql` | DB schema |

**Database Tables:**

| Table | Purpose | Records |
|-------|---------|---------|
| `ob-poc.dsl_verbs` | Verb definitions + intent_patterns | 1,263 verbs |
| `ob-poc.verb_pattern_embeddings` | Patterns with Candle embeddings | 15,940 |
| `ob-poc.v_verb_intent_patterns` | View that flattens intent_patterns array | — |
| `agent.user_learned_phrases` | Per-user learned patterns | Runtime |
| `agent.phrase_blocklist` | Blocked verb mappings | Runtime |

**Startup Sync:**

On server startup (`ob-poc-web/src/main.rs`):
1. Load verb YAML config
2. `VerbSyncService.sync_all_with_phrases()` syncs verbs AND invocation_phrases to `dsl_verbs.yaml_intent_patterns`
3. `populate_embeddings` must be run separately to create vectors
4. Background learning task spawns (30s delay, then 6hr interval)

**Populating Embeddings:**

> ⚠️ **CRITICAL:** After adding/modifying verb YAML, you MUST run `populate_embeddings` or the new verbs won't be discoverable via semantic search. Server startup syncs YAML → DB but does NOT create embeddings.

```bash
# Run after YAML changes or first setup
DATABASE_URL="postgresql:///data_designer" \
  cargo run --release --package ob-semantic-matcher --bin populate_embeddings

# Use --force if patterns exist but need re-embedding (e.g., after model change)
DATABASE_URL="postgresql:///data_designer" \
  cargo run --release --package ob-semantic-matcher --bin populate_embeddings -- --force
```

Options:
- `--bootstrap`: Generate patterns for verbs without intent_patterns (use sparingly)
- `--force`: Re-embed all patterns even if already present (use after model change)

**Delta Loading (Fast Incremental):**

`populate_embeddings` uses delta loading by default - only processes patterns WHERE embedding IS NULL. This makes teaching and incremental updates very fast:

```
Full re-embed (7,414 patterns): ~74 seconds
Delta embed (6 new patterns):   ~0.07 seconds
```

After teaching new phrases, just run `populate_embeddings` without `--force` to pick up only the new patterns.

**Search Priority (HybridVerbSearcher):**

All DB access goes through `VerbService` (no direct sqlx calls).

-2A. **ScenarioIndex** → journey-level compound intent → macro/sequence/selector (score 0.97)
-2B. **MacroIndex** → deterministic macro search parity (score 0.96)
-1. **ECIR noun taxonomy** → deterministic noun→verb resolution (score 0.95 single-verb short-circuit, +0.05 post-boost for multi-verb)
0. Operator macros → business vocabulary (score 1.0 exact, 0.95 fuzzy)
1. User learned exact → `agent.user_learned_phrases`
2. Global learned exact → In-memory LearnedData
3. User semantic → pgvector on user_learned_phrases
4. Global semantic → pgvector on `verb_pattern_embeddings`
5. Blocklist check → Filter blocked verbs
6. **Global semantic fallback** ← Lower threshold, wider net
7. Phonetic fallback → typo handling (score 0.80)

**Pattern Sources (v_verb_intent_patterns view):**
- `yaml_intent_patterns` - YAML invocation_phrases, overwritten on startup
- `intent_patterns` - Learned patterns, preserved across restarts

**Learning Loop:**

Automatic learning via background task (or MCP tools):
1. `learning_analyze` identifies high-frequency unmatched phrases
2. `learning_apply` promotes candidates to `dsl_verbs.intent_patterns`
3. `populate_embeddings` creates vectors for new patterns
4. Future queries match the learned phrases

**MCP Tools:**
- `learning_analyze` - Find patterns worth learning (days_back, min_occurrences)
- `learning_apply` - Apply a specific pattern → verb mapping
- `embeddings_status` - Check embedding coverage stats

**Coverage Stats:**

```sql
SELECT * FROM "ob-poc".v_verb_embedding_stats;
-- total_verbs: 1263
-- verbs_with_patterns: 1263
-- verbs_with_yaml_patterns: 1253  -- From YAML invocation_phrases
-- verbs_with_learned_patterns: 45 -- From learning loop
-- total_embeddings: 15940
-- unique_verbs_embedded: 1263
```

---

## Structured Onboarding Pipeline (ob-agentic)

The `ob-agentic` crate provides a **three-layer pipeline** for converting natural language custody onboarding requests into validated DSL. This is distinct from the single-verb MCP pipeline above—it handles complex multi-entity onboarding workflows.

**Crate:** `rust/crates/ob-agentic/` (no database dependency)

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    STRUCTURED ONBOARDING PIPELINE                            │
│                                                                              │
│  User: "Set up a PE fund trading US equities with IRS with Morgan Stanley"  │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  LAYER 1: INTENT EXTRACTION (LLM)                                   │    │
│  │  IntentExtractor.extract() → OnboardingIntent                       │    │
│  │                                                                     │    │
│  │  Output: {                                                          │    │
│  │    client: { name: "PE Fund", type: "fund", jurisdiction: "US" },  │    │
│  │    instruments: [EQUITY, OTC_IRS],                                 │    │
│  │    markets: [{ code: XNYS, currencies: [USD] }],                   │    │
│  │    otc_counterparties: [{ name: "Morgan Stanley", law: "NY" }]     │    │
│  │  }                                                                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                              │                                               │
│                              ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  LAYER 2: REQUIREMENT PLANNING (Deterministic Rust)                 │    │
│  │  RequirementPlanner::plan(intent) → OnboardingPlan                  │    │
│  │                                                                     │    │
│  │  • Classify pattern (SimpleEquity / MultiMarket / WithOtc)         │    │
│  │  • Plan CBU creation                                                │    │
│  │  • Plan entity lookups (counterparties)                            │    │
│  │  • Derive universe (instruments × markets × currencies)            │    │
│  │  • Derive SSIs (settlement routes)                                 │    │
│  │  • Derive booking rules (priority-ordered)                         │    │
│  │  • Plan ISDAs + CSAs (if OTC)                                      │    │
│  │                                                                     │    │
│  │  NO LLM - pure business logic expansion                            │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                              │                                               │
│                              ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  LAYER 3: DSL GENERATION (LLM)                                      │    │
│  │  DslGenerator.generate(plan) → DSL source string                    │    │
│  │                                                                     │    │
│  │  • System prompt: DSL syntax, verb schemas, pattern example        │    │
│  │  • User prompt: structured plan (CBU, entities, universe, rules)   │    │
│  │  • LLM renders plan as s-expression DSL                            │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                              │                                               │
│                              ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  VALIDATION & RETRY (FeedbackLoop)                                  │    │
│  │  FeedbackLoop.generate_valid_dsl(plan)                              │    │
│  │                                                                     │    │
│  │  • AgentValidator checks syntax                                    │    │
│  │  • If invalid: collect errors → ask LLM to fix                     │    │
│  │  • Retry up to max_retries                                         │    │
│  │  • Return ValidatedDsl { source, attempts, validation }            │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                              │                                               │
│                              ▼                                               │
│                    dsl-core parser → execution                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Key Types

| Type | Module | Purpose |
|------|--------|---------|
| `OnboardingIntent` | `ob_agentic::intent` | Structured NL extraction (client, instruments, markets, counterparties) |
| `IntentResult` | `ob_agentic::intent` | Either `Clear(intent)` or `NeedsClarification(request)` |
| `OnboardingPlan` | `ob_agentic::planner` | Complete requirements (CBU, entities, universe, SSIs, rules, ISDAs) |
| `OnboardingPattern` | `ob_agentic::patterns` | Classification: `SimpleEquity`, `MultiMarket`, `WithOtc` |
| `DslGenerator` | `ob_agentic::generator` | LLM-based DSL rendering from plan |
| `FeedbackLoop` | `ob_agentic::feedback` | Retry loop with error correction |
| `ValidatedDsl` | `ob_agentic::feedback` | Final output with attempt count |

### Onboarding Patterns

| Pattern | Criteria | Complexity |
|---------|----------|------------|
| `SimpleEquity` | Single market, single currency, no OTC | CBU + profile + 1 SSI + basic rules |
| `MultiMarket` | Multiple markets or cross-currency | Multiple SSIs + complex routing rules |
| `WithOtc` | Has OTC counterparties | Adds entities + ISDAs + CSAs + collateral SSI |

### OnboardingPlan Structure

```rust
pub struct OnboardingPlan {
    pub pattern: OnboardingPattern,       // Classification
    pub cbu: CbuPlan,                     // CBU creation spec
    pub entities: Vec<EntityPlan>,        // Counterparty lookups
    pub universe: Vec<UniverseEntry>,     // What client trades
    pub ssis: Vec<SsiPlan>,               // Settlement identifiers  
    pub booking_rules: Vec<BookingRulePlan>, // Routing (priority-ordered)
    pub isdas: Vec<IsdaPlan>,             // OTC agreements
}

// Universe entry: instruments × markets × currencies
pub struct UniverseEntry {
    pub instrument_class: String,         // EQUITY, OTC_IRS
    pub market: Option<String>,           // XNYS, None for OTC
    pub currencies: Vec<String>,          // USD, EUR
    pub settlement_types: Vec<String>,    // DVP, FOP
    pub counterparty_var: Option<String>, // @morgan for OTC
}

// Booking rules derived from universe
pub struct BookingRulePlan {
    pub priority: u32,                    // 10, 15, 50, 100
    pub instrument_class: Option<String>,
    pub market: Option<String>,
    pub currency: Option<String>,
    pub counterparty_var: Option<String>,
    pub ssi_variable: String,             // @ssi-xnys-usd
}
```

### Call Stack

```rust
// 1. Extract intent from NL (async, LLM)
let extractor = IntentExtractor::from_env()?;
let result = extractor.extract("Set up PE fund...").await?;

match result {
    IntentResult::NeedsClarification(req) => {
        // Show req.ambiguity.question to user
        // Call extract_with_clarification() with their choice
    }
    IntentResult::Clear(intent) => {
        // 2. Plan requirements (sync, deterministic)
        let plan = RequirementPlanner::plan(&intent);
        
        // 3. Generate validated DSL (async, LLM with retry)
        let feedback = FeedbackLoop::from_env(3)?;
        let validated = feedback.generate_valid_dsl(&plan).await?;
        
        // validated.source contains DSL ready for dsl-core
    }
}
```

### Lexicon Pipeline (Alternative Path)

The `ob_agentic::lexicon` module provides a **formal grammar** approach as an alternative to LLM-based intent extraction:

```
User Input → Tokenizer (lexicon + EntityGateway) → Nom Parser → IntentAst → Plan → DSL
```

| Module | Purpose |
|--------|---------|
| `lexicon::Tokenizer` | Classifies words against YAML lexicon + DB entities |
| `lexicon::parse_tokens` | Nom grammar parser → `IntentAst` |
| `lexicon::intent_to_plan` | AST → `Plan` with `SemanticAction` |
| `lexicon::render_plan` | Plan → DSL source string |

This path is deterministic end-to-end (no LLM) but requires the lexicon to cover the input vocabulary.

### Key Files

| File | Purpose |
|------|---------|
| `rust/crates/ob-agentic/src/intent.rs` | `OnboardingIntent`, `IntentResult`, `ClarificationRequest` |
| `rust/crates/ob-agentic/src/planner.rs` | `RequirementPlanner::plan()`, `OnboardingPlan` |
| `rust/crates/ob-agentic/src/generator.rs` | `DslGenerator`, `IntentExtractor` |
| `rust/crates/ob-agentic/src/feedback.rs` | `FeedbackLoop`, `ValidatedDsl` |
| `rust/crates/ob-agentic/src/patterns.rs` | `OnboardingPattern` enum |
| `rust/crates/ob-agentic/src/validator.rs` | `AgentValidator` for DSL syntax |
| `rust/crates/ob-agentic/src/lexicon/` | Formal grammar tokenizer + parser |
| `rust/crates/ob-agentic/src/schemas/` | Verb schemas + reference data for prompts |

### When to Use Which Pipeline

| Pipeline | Use Case |
|----------|----------|
| **MCP Pipeline** (verb_search → dsl_generate) | Single-verb commands, navigation, CRUD operations |
| **ob-agentic Pipeline** (Intent → Plan → DSL) | Complex custody onboarding with multiple entities, SSIs, booking rules |
| **Lexicon Pipeline** | Deterministic parsing when vocabulary is constrained |

---

## Verb Phrase Generation (Auto-Generated)

> ✅ **IMPLEMENTED (2026-02-05)**: Invocation phrases auto-generated on V1 YAML load. No separate V2 registry needed.

The verb loader automatically generates invocation phrases for all verbs without manual curation. This enables semantic search discovery for new verbs immediately after adding them to YAML.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    V1 VERB LOADING WITH AUTO-GENERATED PHRASES               │
│                                                                              │
│  V1 YAML (config/verbs/*.yaml)                                              │
│         │   - Full verb definitions (behavior, handlers, CRUD, lifecycle)   │
│         │   - Optional manual invocation_phrases (preserved)                │
│         │                                                                    │
│         ▼                                                                    │
│  ConfigLoader.load_verbs()                                                  │
│         │   - Loads verb definitions                                        │
│         │   - Calls enrich_with_generated_phrases()                         │
│         │   - Auto-generates phrases from domain + action synonyms          │
│         │                                                                    │
│         ▼                                                                    │
│  Server startup (ob-poc-web)                                                │
│         │   - VerbSyncService.sync_all_with_phrases()                       │
│         │   - Syncs to dsl_verbs.yaml_intent_patterns                       │
│         │                                                                    │
│         ▼                                                                    │
│  populate_embeddings                                                        │
│         │   - Delta loading (only new patterns)                             │
│         │                                                                    │
│         ▼                                                                    │
│  HybridVerbSearcher (semantic search ready)                                 │
└─────────────────────────────────────────────────────────────────────────────┘
```

### How It Works

When verbs are loaded from YAML, the `ConfigLoader` automatically generates invocation phrases by combining:
1. **Verb action synonyms** (create → add, new, make, register)
2. **Domain nouns** (cbu → client business unit, trading unit)

```rust
// dsl-core/src/config/phrase_gen.rs
generate_phrases("cbu", "create", &[])
// Returns: ["create cbu", "add cbu", "new client business unit", ...]

generate_phrases("deal", "create", &[])
// Returns: ["create deal", "add deal record", "new client deal", ...]
```

### Key Benefits

- **No manual step required** - New verbs are discoverable immediately
- **Single source of truth** - V1 YAML is the only verb format
- **Existing phrases preserved** - Manual phrases merged with generated
- **No build artifacts** - No registry.json to rebuild

### Adding New Verbs

Simply add the verb to V1 YAML and restart the server:

```yaml
# config/verbs/deal.yaml
domains:
  deal:
    verbs:
      create:
        description: "Create a new deal record"
        behavior: plugin
        # invocation_phrases auto-generated: ["create deal", "add deal", ...]
```

Then run embeddings to enable semantic search:

```bash
DATABASE_URL="postgresql:///data_designer" \
  cargo run --release --package ob-semantic-matcher --bin populate_embeddings
```

### Phrase Synonym Dictionaries

| Action | Synonyms |
|--------|----------|
| create | add, new, make, register |
| list | show, get all, display, enumerate |
| get | show, fetch, retrieve, read |
| update | edit, modify, change, set |
| delete | remove, drop, terminate |
| record | log, capture, enter |
| generate | create, produce, build |

| Domain | Nouns |
|--------|-------|
| cbu | client business unit, trading unit |
| entity | company, person |
| deal | deal record, client deal, sales deal |
| billing | billing profile, fee billing, invoice |

### Key Files

| File | Purpose |
|------|---------|
| `rust/crates/dsl-core/src/config/phrase_gen.rs` | Phrase generation with synonym dictionaries |
| `rust/crates/dsl-core/src/config/loader.rs` | `enrich_with_generated_phrases()` on load |
| `rust/src/session/verb_sync.rs` | `sync_all_with_phrases()` to DB |
| `rust/crates/ob-poc-web/src/main.rs` | Server startup verb sync |

---

## Promotion Pipeline (Staged Pattern Learning)

The **PromotionService** provides quality-gated pattern promotion with collision detection. Runs as part of the background learning task (every 6 hours).

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PROMOTION PIPELINE                                        │
│                                                                              │
│  User interaction → outcome recorded                                        │
│      │                                                                       │
│      ▼                                                                       │
│  FeedbackService.record_outcome_with_dsl()                                  │
│      │                                                                       │
│      └── Triggers agent.record_learning_signal() for strong signals         │
│              │                                                               │
│              ▼                                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  QUALITY GATES (SQL function)                                        │    │
│  │  • Word count: 3-15 words                                            │    │
│  │  • Stopword ratio: <70%                                              │    │
│  │  • Not already in verb_pattern_embeddings                           │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│              │                                                               │
│              ▼                                                               │
│  agent.learning_candidates (tracks success_count, total_count)              │
│              │                                                               │
│              │ (background job every 6 hours)                               │
│              ▼                                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  PROMOTION THRESHOLDS                                                │    │
│  │  • occurrence_count >= 5                                             │    │
│  │  • success_rate >= 0.80                                              │    │
│  │  • age >= 24 hours (cool-down)                                       │    │
│  │  • collision_safe = true (semantic check)                            │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│              │                                                               │
│              ▼                                                               │
│  agent.apply_promotion() → dsl_verbs.intent_patterns                        │
│              │                                                               │
│              ▼                                                               │
│  (Run populate_embeddings to enable semantic matching)                      │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Key Files:**

| File | Purpose |
|------|---------|
| `rust/crates/ob-semantic-matcher/src/feedback/promotion.rs` | PromotionService |
| `rust/crates/ob-semantic-matcher/src/feedback/service.rs` | FeedbackService (triggers learning signals) |
| `rust/src/agent/learning/background.rs` | Background job integration |
| `migrations/043_feedback_loop_promotion.sql` | Schema, functions, views |

**Database Tables:**

| Table | Purpose |
|-------|---------|
| `agent.learning_candidates` | Staged candidates with success tracking |
| `agent.stopwords` | Words filtered from patterns |
| `agent.phrase_blocklist` | Rejected patterns |
| `agent.learning_audit` | Audit trail of promotions/rejections |

**Views:**

| View | Purpose |
|------|---------|
| `agent.v_top_pending_candidates` | Top 100 pending by occurrence |
| `agent.v_candidate_pipeline` | Pipeline status summary |
| `agent.v_learning_health_weekly` | Weekly health metrics |

**MCP Tools:**

| Tool | Description |
|------|-------------|
| `promotion_run_cycle` | Run full promotion pipeline manually |
| `promotion_candidates` | List candidates ready for auto-promotion |
| `promotion_review_queue` | List candidates needing manual review |
| `promotion_approve` | Manually approve a candidate |
| `promotion_reject` | Reject and add to blocklist |
| `promotion_health` | Weekly health metrics |
| `promotion_pipeline_status` | Pipeline summary by status |

**Thresholds:**

| Parameter | Value | Rationale |
|-----------|-------|-----------|
| `min_occurrences` | 5 | Enough signal, not one-off |
| `min_success_rate` | 0.80 | 4/5 successful uses |
| `min_age_hours` | 24 | Cool-down for burst patterns |
| `collision_threshold` | 0.92 | Prevent verb confusion |

---

## Teaching Mechanism (Direct Pattern Learning)

The **Teaching Tools** allow trusted sources (admin, Claude) to directly add phrase→verb mappings without going through the candidate promotion pipeline. This bypasses quality gates for immediate effect.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    TEACHING vs PROMOTION                                     │
│                                                                              │
│  TEACHING (trusted, immediate)           PROMOTION (earned, gated)          │
│  ─────────────────────────────           ──────────────────────────         │
│  teach_phrase("spin up", "cbu.create")   User interactions → signals        │
│      │                                       │                               │
│      ▼                                       ▼                               │
│  agent.teach_phrase() SQL function       learning_candidates (staged)       │
│      │                                       │                               │
│      ├── Validates verb exists               ├── Quality gates              │
│      ├── Normalizes phrase                   ├── Success rate >= 80%        │
│      ├── Adds to intent_patterns             ├── Age >= 24 hours            │
│      └── Audits to teaching_audit            └── Collision check            │
│      │                                       │                               │
│      ▼                                       ▼                               │
│  dsl_verbs.intent_patterns              dsl_verbs.intent_patterns           │
│      │                                       │                               │
│      └──────────────┬────────────────────────┘                              │
│                     ▼                                                        │
│           populate_embeddings                                                │
│                     │                                                        │
│                     ▼                                                        │
│           verb_pattern_embeddings (semantic search enabled)                  │
└─────────────────────────────────────────────────────────────────────────────┘
```

**MCP Tools:**

| Tool | Description |
|------|-------------|
| `teach_phrase` | Directly add phrase→verb mapping |
| `unteach_phrase` | Remove a taught mapping (with audit) |
| `teaching_status` | View recently taught patterns and stats |

**Usage Examples:**

```json
// Teach a new phrase
{"tool": "teach_phrase", "phrase": "spin up a fund", "verb": "cbu.create"}

// Teach with custom source
{"tool": "teach_phrase", "phrase": "who owns this", "verb": "ubo.discover", "source": "admin_manual"}

// Remove a taught phrase
{"tool": "unteach_phrase", "phrase": "spin up a fund", "reason": "too_generic"}

// Check teaching status
{"tool": "teaching_status", "limit": 20, "include_stats": true}
```

**Key Files:**

| File | Purpose |
|------|---------|
| `migrations/044_agent_teaching.sql` | Schema, functions, views |
| `rust/src/mcp/handlers/core.rs` | MCP tool handlers |
| `rust/src/mcp/tools.rs` | Tool definitions |

**Database Functions:**

| Function | Purpose |
|----------|---------|
| `agent.teach_phrase(phrase, verb, source)` | Add pattern with validation |
| `agent.teach_phrases_batch(json_array)` | Bulk teaching |
| `agent.unteach_phrase(phrase, verb, reason)` | Remove with audit |
| `agent.get_taught_pending_embeddings()` | Patterns needing embedding |

**Views:**

| View | Purpose |
|------|---------|
| `agent.v_recently_taught` | Recent patterns with source |
| `agent.v_teaching_stats` | Totals, today, this week |

**After Teaching:**

Always run `populate_embeddings` after teaching to enable semantic matching:

```bash
DATABASE_URL="postgresql:///data_designer" \
  cargo run --release --package ob-semantic-matcher --bin populate_embeddings
```

---

## Verb Disambiguation UI (057)

> ✅ **IMPLEMENTED (2026-01-27)**, **cut over (2026-03-05)**: Interactive disambiguation remains active, but client replies now route through unified session input.

When the semantic verb search returns multiple verbs with similar scores (within `AMBIGUITY_MARGIN = 0.05`), the system presents an interactive disambiguation UI instead of guessing.

**Flow:**

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  User: "load the book"                                                      │
│      │                                                                       │
│      ▼                                                                       │
│  HybridVerbSearcher.search() → VerbSearchOutcome::Suggest                   │
│      │   (top: session.load-galaxy @ 0.82, runner_up: session.load-cbu @ 0.79)
│      │                                                                       │
│      ▼                                                                       │
│  ChatResponse.verb_disambiguation = Some(VerbDisambiguationRequest {        │
│      original_input: "load the book",                                       │
│      options: [session.load-galaxy, session.load-cbu, ...]                  │
│  })                                                                          │
│      │                                                                       │
│      ▼                                                                       │
│  UI shows disambiguation card with clickable verb buttons                   │
│      │                                                                       │
│      ├─► User clicks verb → POST /api/session/:id/input                     │
│      │         { kind: "decision_reply", ... }                              │
│      │       → Gold-standard learning signal (confidence=0.95)              │
│      │       → Phrase variants generated for robust learning                │
│      │       → Continue with selected verb                                  │
│      │                                                                       │
│      └─► User cancels/times out (30s) → POST /api/session/:id/input         │
│                { kind: "decision_reply", ... }                              │
│              → Negative signals for all candidates                          │
│              → Clear disambiguation state                                   │
└─────────────────────────────────────────────────────────────────────────────┘
```

**API Endpoints:**

| Endpoint | Purpose |
|----------|---------|
| `POST /api/session/:id/input` | Decision replies (`kind=decision_reply`) for select/reject/cancel |
| `POST /api/session/:id/select-verb` | Legacy endpoint (410 Gone) |
| `POST /api/session/:id/abandon-disambiguation` | Legacy endpoint (410 Gone) |

**Types (`ob-poc-types`):**

```rust
pub struct VerbDisambiguationRequest {
    pub original_input: String,
    pub options: Vec<VerbOption>,
}

pub struct VerbOption {
    pub verb_fqn: String,      // e.g., "session.load-galaxy"
    pub description: String,
    pub score: f32,
    pub example: Option<String>,
}

pub struct VerbSelectionRequest {
    pub selected_verb: String,
    pub original_input: String,
    pub all_candidates: Vec<VerbCandidate>,
}

pub enum AbandonReason {
    Cancelled,      // User clicked cancel
    Timeout,        // 30-second timeout
    NewInput,       // User started typing new input
}
```

**UI State (`VerbDisambiguationState`):**

```rust
pub struct VerbDisambiguationState {
    pub active: bool,
    pub request: Option<VerbDisambiguationRequest>,
    pub original_input: String,
    pub shown_at: Option<f64>,  // Timestamp for timeout
    pub loading: bool,
}
```

**Key Files:**

| File | Purpose |
|------|---------|
| `rust/crates/ob-poc-types/src/lib.rs` | Type definitions |
| `rust/src/api/agent_routes.rs` | Unified `POST /api/session/:id/input` decision-reply adapter |
| `rust/src/api/agent_service.rs` | `handle_verb_selection()`, wires to ChatResponse |
> **Note:** The egui UI for disambiguation (`ob-poc-ui`) has been removed. Disambiguation is now handled by the React frontend and V2 REPL API.

**Learning Signal Generation:**

When user selects a verb:
1. **Gold-standard signal** (confidence=0.95) for selected phrase→verb
2. **Phrase variants** generated via `generate_phrase_variants()`:
   - Original phrase
   - Lowercase normalized
   - Common prefix variations ("please", "can you", "I want to")
3. **Negative signals** for rejected candidates

---

## Intent Tier Disambiguation (065)

> ✅ **IMPLEMENTED (2026-02-01)**: Higher-level intent clarification before verb disambiguation.

**Problem Solved:** Verb disambiguation showed low-level technical verb options (e.g., `session.load-galaxy`, `session.load-cbu`, `cbu.create`) which overwhelmed users. They need to first answer a simpler question: "What are you trying to do?"

**Key Insight:** Intent tier disambiguation happens **BEFORE** verb disambiguation. It's a funnel:

```
User Input → Intent Tier (action type) → Verb Disambiguation (specific verb) → Entity Resolution → Execute
```

### Two-Tier Clarification Model

| Tier | Question | Example Options |
|------|----------|-----------------|
| **Tier 1** | "What are you trying to do?" | Navigate, Create, Modify, Analyze, Workflow |
| **Tier 2** | "What kind of [action]?" | (for Navigate): Single Structure, Client Book, Jurisdiction |

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  INTENT TIER DISAMBIGUATION                                                  │
│                                                                              │
│  User: "load the book"                                                       │
│      │                                                                       │
│      ▼                                                                       │
│  HybridVerbSearcher.search() → Multiple verbs across different tiers        │
│      │   session.load-galaxy (navigate), cbu.create (create), ...           │
│      │                                                                       │
│      ▼                                                                       │
│  IntentTierTaxonomy.analyze_candidates()                                    │
│      │   Detects verbs span multiple action categories                      │
│      │   navigate: 3 verbs, create: 2 verbs, modify: 1 verb                 │
│      │                                                                       │
│      ▼                                                                       │
│  should_use_tiers() = true (multiple tiers with candidates)                 │
│      │                                                                       │
│      ▼                                                                       │
│  ChatResponse.intent_tier = Some(IntentTierRequest {                        │
│      tier_number: 1,                                                        │
│      prompt: "What are you trying to do?",                                  │
│      options: [Navigate, Create, Modify, ...]                               │
│  })                                                                          │
│      │                                                                       │
│      ▼                                                                       │
│  UI shows intent tier card with high-level action buttons                   │
│      │                                                                       │
│      ├─► User selects "Navigate & View"                                     │
│      │       → Filter to navigate verbs only                                │
│      │       → If 1 verb remains: proceed to execute                        │
│      │       → If multiple remain: show Tier 2 or verb disambiguation       │
│      │                                                                       │
│      └─► User cancels → Clear state, no action                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Taxonomy Configuration

Defined in `config/verb_schemas/intent_tiers.yaml`:

```yaml
tiers:
  tier1:
    navigate:
      id: navigate
      label: "Navigate & View"
      description: "Load, view, or explore structures and data"
      hint: "session.load-*, view.*, session.info"
    create:
      id: create
      label: "Create New"
      description: "Create new structures, entities, or relationships"
      hint: "*.create, *.add, *.register"
    modify:
      id: modify
      label: "Modify Existing"
      description: "Update, edit, or change existing data"
      hint: "*.update, *.set, *.assign"
    analyze:
      id: analyze
      label: "Analyze & Report"
      description: "Run analysis, generate reports, or query data"
      hint: "*.analyze, *.report, *.query"
    workflow:
      id: workflow
      label: "Workflow & Process"
      description: "Manage cases, approvals, or multi-step processes"
      hint: "kyc.*, workflow.*, case.*"

  tier2:
    navigate:
      single_structure:
        label: "Single Structure"
        description: "Focus on one CBU/fund"
      client_book:
        label: "Client Book"
        description: "All structures for a client"
      jurisdiction:
        label: "By Jurisdiction"
        description: "Structures in a region"

verb_tier_mapping:
  session.load-galaxy: navigate
  session.load-cbu: navigate
  session.load-jurisdiction: navigate
  cbu.create: create
  entity.create: create
  # ... etc
```

### Types (`ob-poc-types`)

```rust
/// Request for intent tier selection (before verb disambiguation)
pub struct IntentTierRequest {
    pub request_id: String,
    pub tier_number: u32,           // 1 or 2
    pub original_input: String,
    pub options: Vec<IntentTierOption>,
    pub prompt: String,             // "What are you trying to do?"
    pub selected_path: Vec<IntentTierSelection>,  // Previous selections
}

pub struct IntentTierOption {
    pub id: String,         // "navigate", "create", etc.
    pub label: String,      // "Navigate & View"
    pub description: String,
    pub hint: Option<String>,
    pub verb_count: usize,  // How many verbs in this category
}

pub struct IntentTierSelection {
    pub tier: u32,
    pub selected_id: String,
}
```

### Key Files

| File | Purpose |
|------|---------|
| `config/verb_schemas/intent_tiers.yaml` | Tier definitions and verb→tier mapping |
| `rust/src/dsl_v2/intent_tiers.rs` | `IntentTierTaxonomy` loader and analysis |
| `rust/src/api/agent_service.rs` | Integration in `process_chat()`, builds tier requests |
| `rust/crates/ob-poc-types/src/lib.rs` | `IntentTierRequest`, `IntentTierOption` types |

> **Note:** The egui UI for intent tiers (`ob-poc-ui`) has been removed. Intent tier selection is now handled by the React frontend and V2 REPL API.

### Decision Flow in agent_service.rs

```rust
// In process_chat():
// 1. Run verb search
let search_result = verb_searcher.search(&input).await?;

// 2. Check if we need intent tier disambiguation FIRST
if let VerbSearchOutcome::Ambiguous { candidates, .. } = &search_result {
    let tier_analysis = taxonomy.analyze_candidates(candidates);
    
    if taxonomy.should_use_tiers(&tier_analysis) {
        // Multiple action categories detected - ask high-level question first
        let tier_request = taxonomy.build_tier1_request(&input, &tier_analysis);
        return Ok(AgentChatResponse {
            intent_tier: Some(tier_request),
            verb_disambiguation: None,  // Don't show verb options yet
            ..
        });
    }
}

// 3. If single tier or user already selected tier, proceed to verb disambiguation
```

### Why This Matters

| Without Intent Tiers | With Intent Tiers |
|---------------------|-------------------|
| "load the book" → 8 verb buttons | "load the book" → "What are you trying to do?" |
| User sees: `session.load-galaxy`, `session.load-cbu`, `cbu.create`, ... | User sees: Navigate, Create, Modify |
| Cognitive overload, technical jargon | Simple, action-oriented choices |
| User may pick wrong verb | Guided to correct category first |

### Learning from Selections

User tier selections generate **gold-standard training data**:

1. Input phrase + selected tier → train intent classifier
2. If tier leads to single verb → implicit phrase→verb mapping
3. Aggregate tier selection patterns → improve taxonomy weights

---

## Operator Macro Vocabulary (058)

> ✅ **IMPLEMENTED (2026-01-28)**: Business-friendly vocabulary layer over technical DSL.

The Operator Macro system provides business-friendly terms (structure, case, mandate) that map to technical DSL verbs (cbu, kyc-case, trading-profile). This enables the UI verb picker to show operator-friendly labels.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  OPERATOR VOCABULARY LAYER                                                   │
│                                                                              │
│  User types: "set up structure"                                             │
│      │                                                                       │
│      ▼                                                                       │
│  HybridVerbSearcher.search() - Tier 0: Macro Search (HIGHEST PRIORITY)      │
│      │                                                                       │
│      ├─► Exact FQN match (structure.setup) → score 1.0                      │
│      ├─► Exact label match ("Set up Structure") → score 1.0                 │
│      └─► Fuzzy label/desc match → score 0.95                                │
│      │                                                                       │
│      ▼                                                                       │
│  Macro found → Expands to DSL: (session.set-structure :structure-id ...)    │
│                                                                              │
│  Display Noun Translation:                                                   │
│  - cbu → structure                                                          │
│  - kyc-case → case                                                          │
│  - trading-profile → mandate                                                │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Components

| Component | File | Purpose |
|-----------|------|---------|
| Macro Definitions | `rust/src/macros/definition.rs` | Type definitions for operator macros |
| Macro Registry | `rust/src/macros/registry.rs` | Load/index macros from YAML, build taxonomy |
| Display Nouns | `rust/src/api/display_nouns.rs` | Translate internal→operator vocabulary |
| Verb Search Integration | `rust/src/mcp/verb_search.rs` | Tier 0 macro search in `HybridVerbSearcher` |

### Session Context Verbs

New primitive verbs for macro expansion targets:

| Verb | Purpose | Handler |
|------|---------|---------|
| `session.set-structure` | Set current CBU context | `SessionSetStructureOp` |
| `session.set-case` | Set current KYC case context | `SessionSetCaseOp` |
| `session.set-mandate` | Set current trading profile context | `SessionSetMandateOp` |

### API Endpoints

| Endpoint | Purpose |
|----------|---------|
| `GET /api/verbs/taxonomy` | Hierarchical macro taxonomy for UI verb picker |
| `GET /api/verbs/:fqn/schema` | Full macro definition (args, prereqs, expansion) |

### Verb Search Priority (Updated)

```
-2A. ScenarioIndex (journey-level) — compound utterances → macro/sequence/selector (score 0.97)
-2B. MacroIndex (macro search parity) — single-macro utterances → macro match (score 0.96)
-1. ECIR noun taxonomy (deterministic) - score 0.95 single-verb, +0.05 post-boost multi-verb
0. Operator macros (business vocabulary) - score 1.0 exact, 0.95 fuzzy
1. User-specific learned (exact) - score 1.0
2. Global learned (exact) - score 1.0
3. User-specific learned (semantic) - score 0.8-0.99
4. [REMOVED]
5. Blocklist filter
6. Global semantic (cold start) - score 0.55-0.95
7. Phonetic fallback (typo handling)
```

### Display Noun Mapping

| Internal Term | Operator Term |
|---------------|---------------|
| `cbu` | `structure` |
| `cbu_id` | `structure_id` |
| `kyc-case` | `case` |
| `kyc_case_id` | `case_id` |
| `trading-profile` | `mandate` |
| `trading_profile_id` | `mandate_id` |

### Macro Lint Rules

Key lint rules enforced by `cargo x verbs lint-macros`:

| Rule | Severity | Description |
|------|----------|-------------|
| `MACRO011` | Error | UI fields required (label, description, target_label) |
| `MACRO012` | Error | Forbidden tokens in UI (cbu, entity_ref, etc.) |
| `MACRO042` | Error | No raw `entity_ref` - use `structure_ref`, `party_ref` |
| `MACRO043` | Error | `kinds:` only under `internal:` block |
| `MACRO044` | Error | Enums must use `${arg.X.internal}` in expansion |
| `MACRO063` | Error | Variable grammar validation (only `${arg.*}`, `${scope.*}`, `${session.*}`) |
| `MACRO080a-c` | Warning | UX friction (missing autofill, picker, short description) |

### Operator Enum Keys vs Internal Tokens

UI keys are not the same as internal tokens - expansion MUST use `${arg.X.internal}`:

| UI Key | Label (user sees) | Internal Token |
|--------|-------------------|----------------|
| `pe` | "Private Equity" | `private-equity` |
| `sicav` | "SICAV" | `sicav` |
| `gp` | "General Partner" | `general-partner` |
| `manco` | "Management Company" | `manco` |

---

## Legal Contracts & Onboarding Gate (045)

> ✅ **IMPLEMENTED (2026-01-22)**: Legal contracts with product-level rate cards and CBU subscription gate.

**Data Model:**

```
┌─────────────────────────────────────────────────────────────────────┐
│                     legal_contracts                                  │
│  contract_id, client_label, effective_date, status                  │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              │ 1:N
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                contract_products                                     │
│  (contract_id, product_code) = PK                                    │
│  rate_card_id                                                        │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              │ 1:N (FK enforced onboarding gate)
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                cbu_subscriptions                                     │
│  (cbu_id, contract_id, product_code) = PK                           │
│  CBU can only subscribe if contract covers that product             │
└─────────────────────────────────────────────────────────────────────┘
```

**Key Concept:** CBU onboarding requires contract+product subscription. No contract = no onboarding.

**client_label:**
- Added to `entities` and `cbus` tables as searchable client shorthand
- "allianz" → all Allianz entities/CBUs, "blackrock" → all BlackRock entities/CBUs
- Used by `session.load-cluster :client "allianz"` for client-scoped loading

**Contract Verbs:**

| Verb | Purpose |
|------|---------|
| `contract.create` | Create legal contract for client |
| `contract.add-product` | Add product with rate card |
| `contract.subscribe` | Subscribe CBU to contract+product (onboarding gate) |
| `contract.list-subscriptions` | List CBU subscriptions |
| `contract.for-client` | Get active contract by client label |

**DSL Examples:**

```clojure
;; Create contract with products
(contract.create :client "allianz" :reference "MSA-2024-001" :effective-date "2024-01-01" :as @contract)
(contract.add-product :contract-id @contract :product "CUSTODY" :rate-card-id @rate)

;; Subscribe CBU (onboarding)
(contract.subscribe :cbu-id @cbu :contract-id @contract :product "CUSTODY")

;; Load client's CBUs
(session.load-cluster :client "allianz" :jurisdiction "LU")
```

**Key Files:**

| File | Purpose |
|------|---------|
| `migrations/045_legal_contracts.sql` | Schema, views, seed data |
| `rust/config/verbs/contract.yaml` | 14 contract verbs |
| `rust/src/domain_ops/session_ops.rs` | `load-cluster` uses client_label |

---

## Deal Record & Fee Billing (067)

> ✅ **IMPLEMENTED (2026-02-05)**: Deal record as commercial origination hub with rate card negotiation and closed-loop fee billing.

**Problem Solved:** Sales, contracting, onboarding, servicing, and billing were disconnected silos. Deal Record is the hub entity that links them all in a closed commercial loop.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DEAL RECORD - COMMERCIAL HUB                              │
│                                                                              │
│  Deal Record                                                                 │
│       │                                                                       │
│       ├─► Participants (sales owner, relationship manager, legal counsel)   │
│       │                                                                       │
│       ├─► Contracts (links to legal_contracts)                              │
│       │                                                                       │
│       ├─► Rate Cards (with negotiation workflow)                            │
│       │       └─► Rate Card Lines (BPS, FLAT, TIERED, PER_TRANSACTION)     │
│       │                                                                       │
│       ├─► SLAs (service level commitments)                                  │
│       │                                                                       │
│       ├─► Documents (proposals, agreements)                                  │
│       │                                                                       │
│       ├─► UBO Assessments (links to KYC cases)                              │
│       │                                                                       │
│       └─► Onboarding Requests (handoff to CBU creation)                     │
│                   │                                                          │
│                   ▼                                                          │
│           Fee Billing Profile                                                │
│                   │                                                          │
│                   ├─► Account Targets (which CBUs to bill)                  │
│                   │                                                          │
│                   └─► Billing Periods → Period Lines → Invoices             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Deal Status State Machine

```
PROSPECT → QUALIFYING → NEGOTIATING → CONTRACTED → ONBOARDING → ACTIVE → WINDING_DOWN → OFFBOARDED
     ↓           ↓            ↓             ↓            ↓
 CANCELLED   CANCELLED    CANCELLED    CANCELLED    CANCELLED
```

### Rate Card Status State Machine

```
DRAFT → PROPOSED → COUNTER_OFFERED ←→ REVISED → AGREED → SUPERSEDED
   ↓        ↓            ↓               ↓
CANCELLED REJECTED    REJECTED       REJECTED
```

### Pricing Models

| Model | Description | Example |
|-------|-------------|---------|
| `BPS` | Basis points on AUM | 15 bps on $1B = $1.5M |
| `FLAT` | Fixed fee | $50,000/year |
| `TIERED` | Volume-based tiers | 20 bps ≤$100M, 15 bps >$100M |
| `PER_TRANSACTION` | Per-trade fee | $5/trade |

### Database Tables (14 new)

| Table | Purpose |
|-------|---------|
| `deals` | Deal record hub entity |
| `deal_participants` | Sales team members with roles |
| `deal_contracts` | Links deals to legal contracts |
| `deal_rate_cards` | Negotiable fee schedules |
| `deal_rate_card_lines` | Individual fee line items |
| `deal_slas` | Service level agreements |
| `deal_documents` | Attached proposals/agreements |
| `deal_ubo_assessments` | KYC case references |
| `deal_onboarding_requests` | Handoff to CBU onboarding |
| `deal_events` | Audit trail of all deal changes |
| `fee_billing_profiles` | Billing configuration per deal |
| `fee_billing_account_targets` | Which CBUs get billed |
| `fee_billing_periods` | Monthly/quarterly billing cycles |
| `fee_billing_period_lines` | Calculated fee amounts |

### Key Verbs

**Deal Verbs (30):**

| Verb | Purpose |
|------|---------|
| `deal.create` | Create new deal record |
| `deal.update-status` | Advance deal through pipeline |
| `deal.add-participant` | Add sales team member |
| `deal.link-contract` | Attach legal contract |
| `deal.create-rate-card` | Start rate card negotiation |
| `deal.add-rate-card-line` | Add fee line item |
| `deal.propose-rate-card` | Submit for client review |
| `deal.counter-offer` | Client counter-proposal |
| `deal.agree-rate-card` | Finalize negotiation |
| `deal.create-onboarding-request` | Handoff to CBU creation |
| `deal.summary` | Get deal with all related data |

**Billing Verbs (14):**

| Verb | Purpose |
|------|---------|
| `billing.create-profile` | Create billing configuration |
| `billing.add-account-target` | Add CBU to billing scope |
| `billing.open-period` | Start billing cycle |
| `billing.calculate-fees` | Run fee calculation |
| `billing.close-period` | Finalize billing cycle |
| `billing.revenue-summary` | Get revenue analytics |

### DSL Examples

```clojure
;; Create deal and rate card
(deal.create :deal-name "Allianz Custody 2024" 
             :client-group-id <Allianz>
             :sales-owner "john.smith@bny.com"
             :as @deal)

(deal.create-rate-card :deal-id @deal :version "1.0" :as @rate-card)

(deal.add-rate-card-line :rate-card-id @rate-card
                         :fee-type "CUSTODY"
                         :pricing-model "BPS"
                         :rate-value 15.0
                         :currency-code "USD")

(deal.propose-rate-card :rate-card-id @rate-card)

;; After negotiation completes
(deal.agree-rate-card :rate-card-id @rate-card)
(deal.update-status :deal-id @deal :new-status "CONTRACTED")

;; Create billing profile
(billing.create-profile :deal-id @deal
                        :billing-frequency "MONTHLY"
                        :invoice-currency "USD"
                        :as @profile)

(billing.add-account-target :profile-id @profile :cbu-id @cbu)
(billing.open-period :profile-id @profile
                     :period-start "2024-01-01"
                     :period-end "2024-01-31")
```

### Key Files

| File | Purpose |
|------|---------|
| `migrations/067_deal_record_fee_billing.sql` | Schema (14 tables, 2 views) |
| `rust/config/verbs/deal.yaml` | 30 deal verbs |
| `rust/config/verbs/billing.yaml` | 14 billing verbs |
| `rust/src/domain_ops/deal_ops.rs` | Deal custom operations |
| `rust/src/domain_ops/billing_ops.rs` | Billing custom operations |
| `rust/src/api/deal_types.rs` | Deal API types (DealSummary, DealGraphResponse) |
| `rust/src/api/deal_routes.rs` | Deal REST API endpoints |
| `rust/src/database/deal_repository.rs` | Deal database queries |
| `rust/src/graph/deal_graph_builder.rs` | Deal taxonomy graph construction |
| `docs/DEAL_RECORD_IMPLEMENTATION_PLAN.md` | Implementation details |

### Deal Graph API

| Endpoint | Purpose |
|----------|---------|
| `GET /api/deal/:id/graph?view_mode=COMMERCIAL` | Get deal taxonomy graph |
| `GET /api/deal/:id/products` | List deal products |
| `GET /api/deal/:id/rate-cards` | List deal rate cards |
| `GET /api/deal/rate-card/:id/lines` | Get rate card fee lines |
| `GET /api/deal/rate-card/:id/history` | Rate card supersession chain |

### Deal Taxonomy Hierarchy

```
Deal (root)
├── Products (commercial scope)
│   └── Rate Cards
│       └── Rate Card Lines (fee definitions)
├── Participants (sales/relationship team)
├── Contracts (legal agreements)
├── Onboarding Requests
│   └── CBU (if onboarded)
└── Billing Profiles
    └── Account Targets
```

### Test Harness

```bash
# Create complete deal for Aviva Investors (idempotent)
cargo x aviva-deal-harness

# Dry run to see DSL without execution
cargo x aviva-deal-harness --dry-run

# Verbose mode shows all DSL statements
cargo x aviva-deal-harness --verbose
```

The harness creates:
- Deal for Aviva Investors (MSA 2024)
- 2 Contracts (Core Services + Ancillary Services)
- 9 Products with rate cards
- Fee lines with BPS, FLAT, PER_TRANSACTION pricing

---

## BPMN-Lite Integration (Phase B)

> ✅ **IMPLEMENTED (2026-02-09)**: ob-poc ↔ bpmn-lite gRPC wiring with WorkflowDispatcher (queue-based resilience), JobWorker, EventBridge, SignalRelay, PendingDispatchWorker, correlation stores, 15 E2E choreography tests.

**Problem Solved:** Verbs that represent long-running processes (days/weeks — document solicitation, KYC reviews, approvals) were fire-and-forget. Phase B wires ob-poc to the standalone bpmn-lite gRPC service so orchestrated verbs park the REPL runbook and resume on external signals. When the BPMN service is temporarily unavailable, dispatch requests are queued locally and retried automatically.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  BPMN-LITE INTEGRATION PIPELINE                                             │
│                                                                              │
│  REPL V2 Orchestrator                                                        │
│       │                                                                       │
│       ▼                                                                       │
│  WorkflowDispatcher (implements DslExecutorV2)                              │
│       │                                                                       │
│       ├─► Direct verb → inner executor → DslExecutionOutcome::Completed     │
│       │                                                                       │
│       └─► Orchestrated verb:                                                │
│               1. canonical_json_with_hash(payload)                          │
│               2. Generate correlation_id + correlation_key (stable)         │
│               3. Try gRPC StartProcess → process_instance_id               │
│                  ├─ OK → process_instance_id = real PID                     │
│                  └─ ERR → queue to bpmn_pending_dispatches                  │
│                           process_instance_id = dispatch_id (placeholder)   │
│               4. CorrelationStore.insert() (session ↔ process link)         │
│               5. ParkedTokenStore.insert() (waiting entry)                  │
│               6. → DslExecutionOutcome::Parked (always, even if queued)    │
│                                                                              │
│  PendingDispatchWorker (background retry, 10s poll loop)                    │
│       │   1. claim_pending(5, backoff) — FOR UPDATE SKIP LOCKED             │
│       │   2. Retry StartProcess with same correlation_id (idempotent)      │
│       │   3. On success: patch correlation.process_instance_id              │
│       │   4. On failure: record_failure (max 50 → failed_permanent)        │
│       │                                                                      │
│  JobWorker (background task, long-poll loop)                                │
│       │   1. ActivateJobs via gRPC (30s timeout)                            │
│       │   2. Dedupe via JobFrameStore                                       │
│       │   3. Execute ob-poc verb for each job                               │
│       │   4. CompleteJob / FailJob via gRPC                                 │
│       │                                                                      │
│  EventBridge (per-process subscription)                                     │
│       │   1. SubscribeEvents via gRPC (tailing stream)                      │
│       │   2. Translate lifecycle events → OutcomeEvent                      │
│       │   3. Update CorrelationStore / ParkedTokenStore                     │
│       │   4. Forward OutcomeEvent to SignalRelay via channel                │
│                                                                              │
│  SignalRelay (decoupled orchestrator bridge)                                │
│       │   1. Consume OutcomeEvent from EventBridge channel                  │
│       │   2. Look up CorrelationRecord → correlation_key                    │
│       │   3. Call orchestrator.signal_completion()                          │
│       │   4. Runbook entry transitions Parked → Completed/Failed           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Module Structure

```
rust/src/bpmn_integration/
├── mod.rs                      # Module root, re-exports
├── types.rs                    # CorrelationRecord, JobFrame, ParkedToken, PendingDispatch,
│                               # OutcomeEvent, WorkflowBinding, TaskBinding, ExecutionRoute
├── canonical.rs                # canonical_json_with_hash(), sha256_bytes()
├── client.rs                   # BpmnLiteConnection — typed gRPC client wrapper
├── config.rs                   # WorkflowConfigIndex — verb→route mapping from YAML
├── correlation.rs              # CorrelationStore — session ↔ process instance links
├── job_frames.rs               # JobFrameStore — dedupe for at-least-once delivery
├── parked_tokens.rs            # ParkedTokenStore — waiting REPL entries
├── pending_dispatches.rs       # PendingDispatchStore — durable queue for BPMN resilience
├── pending_dispatch_worker.rs  # PendingDispatchWorker — background retry (10s poll)
├── dispatcher.rs               # WorkflowDispatcher — DslExecutorV2 impl, routes Direct/Orchestrated
├── worker.rs                   # JobWorker — long-poll job activation + verb execution
├── event_bridge.rs             # EventBridge — lifecycle event subscription + translation
└── signal_relay.rs             # SignalRelay — bounces OutcomeEvents to orchestrator
```

### Key Types

| Type | Purpose |
|------|---------|
| `ExecutionRoute` | `Direct` (standard executor) or `Orchestrated` (BPMN-Lite) |
| `WorkflowBinding` | Maps verb FQN → route + process_key + task_bindings |
| `TaskBinding` | Maps BPMN task_type → ob-poc verb FQN + timeout + retries |
| `CorrelationRecord` | Links process_instance_id ↔ session/runbook/entry with payload hash |
| `JobFrame` | Tracks job activation for dedupe (job_key, status, attempts) |
| `ParkedToken` | Waiting REPL entry with correlation_key for O(1) signal routing |
| `PendingDispatch` | Queued BPMN dispatch request with correlation_id, payload_hash, retry state |
| `PendingDispatchStatus` | `Pending` → `Dispatched` or `FailedPermanent` (after max retries) |
| `OutcomeEvent` | Translated BPMN events: StepCompleted, StepFailed, ProcessCompleted, ProcessCancelled, IncidentCreated |
| `BpmnLiteConnection` | Typed gRPC client (connect_lazy, 8 RPC methods) |
| `WorkflowConfigIndex` | In-memory verb→route index loaded from `config/workflows.yaml` |
| `SignalRelay` | Consumes EventBridge outcomes, relays to orchestrator for runbook resume |
| `PendingDispatchWorker` | Background retry worker — 10s poll, claims pending dispatches, retries gRPC |

### Control Verbs

| Verb | Purpose |
|------|---------|
| `bpmn.compile` | Compile BPMN XML → bytecode via gRPC |
| `bpmn.start` | Start a process instance |
| `bpmn.signal` | Send signal to waiting process |
| `bpmn.cancel` | Cancel running process |
| `bpmn.inspect` | Inspect process state (fiber positions, waits) |

### Server Wiring

BPMN integration is **conditionally enabled** on the `BPMN_LITE_GRPC_URL` environment variable in `ob-poc-web/src/main.rs`. The BPMN init block runs **before** the REPL V2 router so the `WorkflowDispatcher` can be wired as the V2 executor.

```bash
# Enable BPMN-Lite integration (WorkflowDispatcher routes orchestrated verbs)
BPMN_LITE_GRPC_URL=http://localhost:50052 cargo run -p ob-poc-web

# Without env var — RealDslExecutor used directly, no parking, no BPMN
cargo run -p ob-poc-web
```

**Startup sequence (when BPMN enabled):**
1. Create `BpmnLiteConnection` (lazy — no network call until first RPC)
2. Load `WorkflowConfigIndex` from `config/workflows.yaml`
3. Auto-register `behavior: durable` verbs into WorkflowConfigIndex
4. Create `WorkflowDispatcher` wrapping `RealDslExecutor` + all stores
5. Spawn `JobWorker` (long-poll job activation)
6. Spawn `PendingDispatchWorker` (retry queued dispatches)
7. Wire `WorkflowDispatcher` as REPL V2 `executor_v2`
8. Log "REPL V2 executor: WorkflowDispatcher (BPMN-routed)"

**Startup sequence (without BPMN):**
1. Wire `RealDslExecutor` as REPL V2 `executor_v2`
2. Log "REPL V2 executor: RealDslExecutor (direct, no BPMN)"

### Database Tables (migrations 073, 076)

| Table | Migration | Purpose |
|-------|-----------|---------|
| `bpmn_correlations` | 073 | PK `correlation_id`, UNIQUE on `process_instance_id` |
| `bpmn_job_frames` | 073 | PK `job_key`, indexed on `status WHERE active` |
| `bpmn_parked_tokens` | 073 | PK `token_id`, UNIQUE on `correlation_key` |
| `bpmn_pending_dispatches` | 076 | PK `dispatch_id`, UNIQUE on `payload_hash WHERE pending` (idempotency), indexed on `(status, last_attempted_at) WHERE pending` |

### Key Files

| File | Purpose |
|------|---------|
| `rust/src/bpmn_integration/dispatcher.rs` | `WorkflowDispatcher` — routes verbs, queues on gRPC failure |
| `rust/src/bpmn_integration/pending_dispatches.rs` | `PendingDispatchStore` — durable queue (insert, claim, mark, fail) |
| `rust/src/bpmn_integration/pending_dispatch_worker.rs` | `PendingDispatchWorker` — background retry (10s poll, max 50 attempts) |
| `rust/src/bpmn_integration/worker.rs` | `JobWorker` — background job activation loop |
| `rust/src/bpmn_integration/event_bridge.rs` | `EventBridge` — lifecycle event translation |
| `rust/src/bpmn_integration/signal_relay.rs` | `SignalRelay` — orchestrator bridge |
| `rust/src/bpmn_integration/client.rs` | `BpmnLiteConnection` — typed gRPC wrapper |
| `rust/src/bpmn_integration/config.rs` | `WorkflowConfigIndex` — verb routing config |
| `rust/src/domain_ops/bpmn_lite_ops.rs` | 5 control verb CustomOps |
| `rust/config/workflows.yaml` | Verb → route mappings |
| `rust/config/verbs/bpmn-lite.yaml` | Control verb definitions |
| `rust/proto/bpmn_lite/v1/bpmn_lite.proto` | gRPC service definition (8 RPCs) |
| `rust/crates/ob-poc-web/src/main.rs` | BPMN init before REPL V2, wires WorkflowDispatcher + workers |
| `migrations/073_bpmn_integration.sql` | 3 tables: correlations, job_frames, parked_tokens |
| `migrations/076_bpmn_pending_dispatches.sql` | Pending dispatch queue table with idempotency index |
| `rust/tests/bpmn_integration_test.rs` | 13 integration tests (all `#[ignore]`) |
| `rust/tests/bpmn_e2e_harness_test.rs` | 15 E2E choreography tests (all `#[ignore]`) |
| `rust/tests/models/kyc-open-case.bpmn` | Test BPMN model (7-node KYC workflow) |

### Environment Variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `BPMN_LITE_GRPC_URL` | (none — disabled) | gRPC endpoint for bpmn-lite service |

### Queue-Based Resilience (Pending Dispatch)

When the bpmn-lite gRPC service is temporarily unavailable, the `WorkflowDispatcher` queues the dispatch request locally in `bpmn_pending_dispatches` and still returns `Parked` to the REPL. The `PendingDispatchWorker` retries queued dispatches every 10 seconds until the service recovers.

**Idempotency chain:**

```
Verb dispatch → canonical_json_with_hash(payload) → (json, hash)
  ├─ gRPC OK → correlation(correlation_id, real_pid) + parked_token → Parked
  └─ gRPC ERR → pending_dispatch(dispatch_id, correlation_id, hash)
               + correlation(correlation_id, placeholder_pid) + parked_token → Parked
                    ↓
               PendingDispatchWorker retries with same correlation_id
                    ↓
               start_process(correlation_id) — bpmn-lite is idempotent on correlation_id
                    ↓
               On success: update correlation.process_instance_id, mark dispatched
```

**Key guarantees:**
- `correlation_id` generated once at dispatch time, stable across retries
- `payload_hash` UNIQUE index prevents duplicate pending entries
- `FOR UPDATE SKIP LOCKED` prevents concurrent workers claiming the same row
- Max 50 attempts (~8 minutes at 10s intervals) before `failed_permanent`
- Only fails immediately if BOTH gRPC AND queue insert fail (true infra failure)

**PendingDispatchStore methods:**

| Method | Purpose |
|--------|---------|
| `insert()` | Queue dispatch (ON CONFLICT DO NOTHING for idempotency) |
| `claim_pending()` | Pop pending rows with backoff (FOR UPDATE SKIP LOCKED) |
| `mark_dispatched()` | Transition to dispatched state with timestamp |
| `record_failure()` | Increment attempts, promote to failed_permanent after max |

---

## Client Group Resolver (048)

> ✅ **IMPLEMENTED (2026-01-23)**: Two-stage alias→group→anchor resolution for session scope selection.

The Client Group Resolver enables natural language scope selection (e.g., "allianz" → load all Allianz CBUs) through a two-stage resolution process:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    TWO-STAGE RESOLUTION                                      │
│                                                                              │
│  User: "allianz"                                                            │
│      │                                                                       │
│      ▼                                                                       │
│  Stage 1: Alias → ClientGroupId                                             │
│      │   "allianz" → exact/semantic match → Allianz Global Investors        │
│      │   (group_id: 11111111-1111-1111-1111-111111111111)                   │
│      │                                                                       │
│      ▼                                                                       │
│  Stage 2: ClientGroupId → AnchorEntityId                                    │
│      │   group_id + role (governance_controller) + jurisdiction (optional) │
│      │   → Allianz Global Investors Holdings GmbH (entity_id)              │
│      │                                                                       │
│      ▼                                                                       │
│  session.load-cluster uses anchor_entity_id to find all CBUs               │
│  under the client's ownership hierarchy                                     │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Data Model:**

| Table | Purpose |
|-------|---------|
| `client_group` | Virtual client groups (Allianz, Aviva, BlackRock) |
| `client_group_alias` | Searchable aliases with embeddings |
| `client_group_alias_embedding` | Versioned embeddings per alias |
| `client_group_anchor` | Role-based anchors per jurisdiction |

**Anchor Roles:**

| Role | Use Case | Default For |
|------|----------|-------------|
| `ultimate_parent` | UBO discovery, ownership tracing | `ubo.*` verbs |
| `governance_controller` | Session scope, CBU loading | `session.*`, `cbu.*` verbs |
| `book_controller` | Regional operations | - |
| `operating_controller` | Day-to-day operations | `contract.*` verbs |
| `regulatory_anchor` | Compliance, KYC | `kyc.*` verbs |

**DSL Usage:**

```clojure
;; Load by client name (two-stage resolution)
(session.load-cluster :client <Allianz>)

;; With jurisdiction filter
(session.load-cluster :client <Allianz> :jurisdiction "LU")

;; Direct entity (bypasses client group resolution)
(session.load-cluster :apex-entity-id "uuid-...")
```

**Key Files:**

| File | Purpose |
|------|---------|
| `migrations/048_client_group_seed.sql` | Schema + bootstrap data |
| `rust/crates/ob-semantic-matcher/src/client_group_resolver.rs` | Resolution logic |
| `rust/src/domain_ops/session_ops.rs` | `SessionLoadClusterOp` handler |
| `rust/config/verbs/session.yaml` | `:client` arg with lookup config |
| `rust/tests/client_group_integration.rs` | Full integration tests |

**Bootstrap Data:**

| Group | Canonical Name | Anchors |
|-------|----------------|---------|
| Allianz | Allianz Global Investors | Allianz SE (UP), AGI Holdings GmbH (GC) |
| Aviva | Aviva Investors | Aviva plc (UP), Aviva Investors Global (GC) |
| BlackRock | BlackRock | BlackRock Inc (UP), BLK Fund Advisors (GC) |
| Aberdeen | Aberdeen Standard Investments | abrdn plc (UP, GC) |

**Populate Embeddings:**

After adding client groups or aliases:

```bash
DATABASE_URL="postgresql:///data_designer" \
  cargo run --release --package ob-semantic-matcher --bin populate_embeddings -- --client-groups
```

---

## Workflow Task Queue & Document Entity (049)

> ✅ **IMPLEMENTED (2026-01-24)**: Queue-based async task return path with document as first-class entity.

**Problem Solved:** Workflows can emit tasks (e.g., "solicit passport") but had no mechanism to receive results and resume. The task queue provides the return path.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  OUTBOUND: Workflow emits task                                              │
│  Blocker detected → resolution DSL → workflow_pending_tasks                 │
│  → External system (Camunda, portal, email) receives task_id + callback URL │
└─────────────────────────────────────────────────────────────────────────────┘
                              │
                    External system works...
                              │
┌─────────────────────────────────────────────────────────────────────────────┐
│  INBOUND: Task completion webhook                                           │
│  POST /api/workflow/task-complete → task_result_queue                       │
│  TaskQueueListener → try_advance(workflow_instance)                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Three-Layer Document Model

| Layer | Table | Purpose |
|-------|-------|---------|
| A: Requirement | `document_requirements` | What we NEED from entity (exists before upload) |
| B: Document | `documents` | Logical identity (stable reference) |
| C: Version | `document_versions` | Each submission (immutable, verification status) |

### Requirement State Machine

```
missing → requested → received → in_qa → verified
                                    ↓
                               rejected → (retry with new version)
                                    
waived (manual override)    expired (validity lapsed)
```

### Rejection Reason Codes

Standardized codes for document QA rejection with client messaging:

| Category | Codes | Next Action |
|----------|-------|-------------|
| Quality | `UNREADABLE`, `CUTOFF`, `GLARE`, `LOW_RESOLUTION` | Re-upload |
| Mismatch | `WRONG_DOC_TYPE`, `WRONG_PERSON`, `SAMPLE_DOC` | Upload correct doc |
| Validity | `EXPIRED`, `NOT_YET_VALID`, `UNDATED` | Upload valid doc |
| Data | `DOB_MISMATCH`, `NAME_MISMATCH`, `ADDRESS_MISMATCH` | Verify details |
| Authenticity | `SUSPECTED_ALTERATION`, `INCONSISTENT_FONTS` | Escalate |

### CargoRef URI Scheme

Typed reference URIs for document/entity tracking:

```
document://ob-poc/{uuid}     # Document identity
version://ob-poc/{uuid}      # Specific version (preferred for callbacks)
entity://ob-poc/{uuid}       # Entity reference
screening://ob-poc/{uuid}    # Screening result
external://{system}/{id}     # Vendor passthrough
```

### Bundle Payload Format

External systems return bundles (even for single documents):

```json
{
  "task_id": "uuid",
  "status": "completed",
  "idempotency_key": "vendor-event-12345",
  "items": [
    { "cargo_ref": "version://ob-poc/...", "doc_type": "passport", "status": "completed" }
  ]
}
```

Listener uses atomic CTE-based queue pop (`FOR UPDATE SKIP LOCKED`) with deduplication by `(task_id, idempotency_key)`.

### Key Tables

| Table | Purpose |
|-------|---------|
| `rejection_reason_codes` | Reference data for QA rejection reasons |
| `document_requirements` | What documents are needed per entity/workflow |
| `documents` | Logical document identity |
| `document_versions` | Immutable submissions with verification status |
| `workflow_pending_tasks` | Outbound task tracking |
| `task_result_queue` | Inbound results (ephemeral, deleted after processing) |
| `task_result_dlq` | Dead letter queue for failed processing |
| `workflow_task_events` | Permanent audit trail |

### API Endpoints

| Endpoint | Purpose |
|----------|---------|
| `POST /api/workflow/task-complete` | External callback webhook (bundle payload) |
| `POST /api/documents` | Create document |
| `POST /api/documents/:id/versions` | Upload version, returns `cargo_ref` |
| `GET /api/documents/:id` | Get document with status |
| `POST /api/documents/:doc_id/versions/:version_id/verify` | QA approve |
| `POST /api/documents/:doc_id/versions/:version_id/reject` | QA reject with code |
| `GET /api/requirements` | List requirements (with filters) |

### DSL Verbs

| Verb | Purpose |
|------|---------|
| `document.solicit` | Request document from entity |
| `document.solicit-set` | Request multiple documents |
| `document.verify` | QA approves version |
| `document.reject` | QA rejects with reason code |
| `requirement.create` | Initialize requirement |
| `requirement.waive` | Manual override (skip requirement) |

### Workflow Guard Integration

Guards check **requirement status**, not raw document existence:

```yaml
states:
  awaiting_identity:
    requirements:
      - type: requirement_satisfied
        doc_type: passport
        min_state: verified       # Must be QA-approved
        subject: $entity_id
        max_age_days: 90          # Recency check on satisfied_at
```

### Key Files

| File | Purpose |
|------|---------|
| `migrations/049_workflow_task_queue_documents.sql` | Schema (all tables) |
| `rust/crates/ob-workflow/src/listener.rs` | Queue listener with retry/DLQ |
| `rust/crates/ob-workflow/src/cargo_ref.rs` | CargoRef URI scheme |
| `rust/crates/ob-workflow/src/document.rs` | Document types, RequirementState |
| `rust/src/api/workflow_routes.rs` | HTTP endpoints |
| `rust/config/verbs/document.yaml` | 7 document verbs |
| `rust/config/verbs/requirement.yaml` | 5 requirement verbs |

---

## Transactional Execution & Advisory Locking (050)

> ✅ **IMPLEMENTED (2026-01-24)**: Atomic execution with PostgreSQL advisory locks, deterministic template expansion, and audit trail.

**Problem Solved:** Multi-statement DSL batches need transactional guarantees. Without locking, concurrent sessions can corrupt shared entities. The expansion stage derives locks deterministically from DSL structure.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  DSL EXECUTION PIPELINE WITH EXPANSION                                       │
│                                                                              │
│  Source DSL: (cbu.create ...) (entity.create ...) (trading-profile.create)  │
│      │                                                                       │
│      ▼                                                                       │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  EXPANSION STAGE (deterministic)                                     │    │
│  │  • Expand template verbs (behavior: template)                        │    │
│  │  • Derive lock set from entity references                            │    │
│  │  • Determine batch_policy: atomic vs best_effort                     │    │
│  │  • Generate ExpansionReport for audit                                │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│      │                                                                       │
│      ├─── batch_policy = atomic ──────────────────────────┐                 │
│      │                                                     ▼                 │
│      │    ┌───────────────────────────────────────────────────────────┐     │
│      │    │  ATOMIC EXECUTOR                                          │     │
│      │    │  • Acquire advisory locks (sorted, no deadlock)           │     │
│      │    │  • Single transaction wraps all statements                │     │
│      │    │  • Any failure → full rollback                            │     │
│      │    │  • Result: Committed | RolledBack | LockContention        │     │
│      │    └───────────────────────────────────────────────────────────┘     │
│      │                                                                       │
│      └─── batch_policy = best_effort ─────────────────────┐                 │
│                                                            ▼                 │
│           ┌───────────────────────────────────────────────────────────┐     │
│           │  BEST-EFFORT EXECUTOR                                     │     │
│           │  • No locking required                                    │     │
│           │  • Execute statements independently                       │     │
│           │  • Continue on failure, aggregate errors                  │     │
│           │  • Result: { succeeded: [...], failed: [...] }            │     │
│           └───────────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Batch Policy

| Policy | Lock Acquisition | Failure Behavior | Use Case |
|--------|------------------|------------------|----------|
| `atomic` | Advisory locks (sorted by entity_id) | Full rollback | Multi-entity operations needing consistency |
| `best_effort` | None | Continue, aggregate errors | Independent operations, bulk imports |

**Policy Determination:**
- `atomic`: Template verbs with `batch_policy: atomic`, or DSL touching multiple related entities
- `best_effort`: Independent statements, bulk operations, read-only queries

### Advisory Locks

PostgreSQL `pg_advisory_xact_lock` provides session-scoped locking:

```rust
pub struct DerivedLock {
    pub entity_type: String,  // "cbu", "entity", "trading_profile"
    pub entity_id: Uuid,      // Target entity
    pub access: LockAccess,   // Read or Write
}

// Lock key derivation: deterministic i64 from (entity_type, entity_id) using DefaultHasher
// Locks acquired in sorted order (entity_id) to prevent deadlocks
// Released automatically when transaction commits/rolls back
```

### Error Aggregation

Errors grouped by root cause for clear diagnostics:

| ErrorCause | Description |
|------------|-------------|
| `EntityDeleted` | Entity was deleted mid-execution |
| `EntityNotFound` | Referenced entity doesn't exist |
| `VersionConflict` | Optimistic lock failure |
| `ConstraintViolation` | FK/unique constraint failed |

`FailureTiming` distinguishes `PreExisting` (bad input) vs `MidExecution` (race condition).

### Expansion Safety Rules

- **Expansion output is UNTRUSTED** - validate expanded macros like hostile input
- **Max expansion steps: 100** - prevents runaway recursive macros
- **No macro recursion** - primitives only in expansion output

### Execution Results

```rust
pub enum AtomicExecutionResult {
    Committed {
        results: Vec<ExecutionResult>,
        lock_stats: LockStats,
    },
    RolledBack {
        cause: RollbackCause,
        partial_results: Vec<ExecutionResult>,
    },
    LockContention {
        contested_locks: Vec<DerivedLock>,
        retry_after_ms: Option<u64>,
    },
}

pub struct BestEffortExecutionResult {
    pub succeeded: Vec<(usize, ExecutionResult)>,  // (statement_index, result)
    pub failed: Vec<(usize, ExecutionError)>,       // (statement_index, error)
    pub skipped: Vec<usize>,                        // Skipped due to dependency
}
```

### Expansion Report (Audit Trail)

Every DSL execution produces an `ExpansionReport` persisted to `ob-poc.expansion_reports`:

| Field | Description |
|-------|-------------|
| `expansion_id` | Unique ID for this expansion |
| `session_id` | Session that triggered execution |
| `source_digest` | SHA-256 of canonical source DSL |
| `expanded_dsl_digest` | SHA-256 of expanded DSL |
| `batch_policy` | `atomic` or `best_effort` |
| `derived_lock_set` | JSON array of locks derived |
| `template_digests` | Templates used (name, version, hash) |
| `invocations` | Template invocation details |
| `diagnostics` | Warnings/errors during expansion |

### Key Files

| File | Purpose |
|------|---------|
| `migrations/050_expansion_audit.sql` | Schema for expansion_reports |
| `rust/src/dsl_v2/expansion/engine.rs` | Template expansion, lock derivation |
| `rust/src/dsl_v2/expansion/policy.rs` | Batch policy determination |
| `rust/src/dsl_v2/executor.rs` | `execute_plan_atomic_with_locks`, `execute_plan_best_effort` |
| `rust/src/dsl_v2/locking.rs` | Advisory lock acquisition/release |
| `rust/src/database/expansion_audit.rs` | ExpansionAuditRepository |
| `rust/src/api/agent_routes.rs` | Session execution with expansion |
| `rust/src/mcp/handlers/core.rs` | MCP dsl_execute with expansion |

### Database Table

```sql
CREATE TABLE "ob-poc".expansion_reports (
    expansion_id UUID PRIMARY KEY,
    session_id UUID NOT NULL,
    source_digest VARCHAR(64) NOT NULL,
    expanded_dsl_digest VARCHAR(64) NOT NULL,
    expanded_statement_count INTEGER NOT NULL,
    batch_policy VARCHAR(20) NOT NULL CHECK (batch_policy IN ('atomic', 'best_effort')),
    derived_lock_set JSONB NOT NULL DEFAULT '[]',
    template_digests JSONB NOT NULL DEFAULT '[]',
    invocations JSONB NOT NULL DEFAULT '[]',
    diagnostics JSONB NOT NULL DEFAULT '[]',
    expanded_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---


---

## Playbook System (059)

> ✅ **IMPLEMENTED (2026-01-28)**: YAML-based playbook specs with LSP validation, source mapping, and CLI tooling.

**Purpose:** Define reusable multi-step workflows as YAML playbooks that lower to DSL statements with slot substitution.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PLAYBOOK PIPELINE                                         │
│                                                                              │
│  .playbook.yaml file                                                        │
│         │                                                                    │
│         ▼                                                                    │
│  playbook-core::parse_playbook()                                            │
│         │   - Pass 1: serde_yaml → PlaybookSpec (typed)                     │
│         │   - Pass 2: marked-yaml → SourceMap (line:col positions)          │
│         │                                                                    │
│         ▼                                                                    │
│  playbook-lower::lower_playbook()                                           │
│         │   - Substitutes ${slot} references                                │
│         │   - Reports missing required slots                                │
│         │   - Generates DSL statements                                      │
│         │                                                                    │
│         ▼                                                                    │
│  DSL statements ready for execution                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Playbook Spec Format

```yaml
id: setup-pe-fund
version: 1
name: "Set Up PE Fund Structure"
slots:
  fund_name:
    type: string
    required: true
  fund_type:
    type: string
    required: false
    default: "private-equity"
steps:
  - id: create-fund
    verb: cbu.create
    args:
      name: "${fund_name}"
      kind: "${fund_type}"
  - id: assign-gp
    verb: cbu-role.assign
    after: [create-fund]
    args:
      cbu_id: "${create-fund.result}"
      role: general-partner
```

### Crates

| Crate | Purpose |
|-------|---------|
| `playbook-core` | Spec types, parser with marked-yaml source mapping |
| `playbook-lower` | Slot state management, DSL lowering |

### Parser (Two-Pass with marked-yaml)

```rust
// Pass 1: Typed deserialization
let spec: PlaybookSpec = serde_yaml::from_str(source)?;

// Pass 2: AST walk with source positions
let node = marked_yaml::parse_yaml(0, source)?;
let marker = verb_node.span().start()?;  // Marker{line, col}
```

No string scanning or regex - pure AST traversal with exact source positions.

### LSP Support

- **File detection:** `.playbook.yaml`, `.playbook.yml`
- **Diagnostics:** Parse errors, missing slots reported with exact positions
- **Debouncing:** 100ms delay before analysis (avoids thrashing)
- **Completion:** Verb completions from macro registry

### CLI Tool

```bash
# Check playbook(s)
cargo run -p xtask -- playbook-check <files> [-v|--verbose]

# Example
cargo run -p xtask -- playbook-check data/playbooks/*.playbook.yaml -v
```

### Zed Extension

Extension updated to recognize `.playbook.yaml` files:
- Syntax highlighting via tree-sitter-yaml
- Language server integration for diagnostics
- Verb completion in `verb:` context

### Key Files

| File | Purpose |
|------|---------|
| `rust/crates/playbook-core/src/spec.rs` | PlaybookSpec, SlotSpec, StepSpec |
| `rust/crates/playbook-core/src/parser.rs` | Two-pass parser with marked-yaml |
| `rust/crates/playbook-core/src/source_map.rs` | SourceSpan, StepSpan |
| `rust/crates/playbook-lower/src/lower.rs` | lower_playbook(), MissingSlot |
| `rust/crates/playbook-lower/src/slots.rs` | SlotState, SlotValue |
| `rust/crates/dsl-lsp/src/handlers/playbook.rs` | LSP playbook analysis |
| `rust/crates/dsl-lsp/zed-extension/languages/playbook/` | Zed language config |
| `rust/xtask/src/main.rs` | PlaybookCheck command |

---

## Zed Extension: DSL Tree-sitter Grammar (Dev Install)

> **Critical for local development** - Installing the custom DSL grammar in Zed.
> This was painful to get working. Follow these steps EXACTLY.

### Directory Structure

```
rust/crates/dsl-lsp/
├── zed-extension/           # Extension root (select THIS for dev install)
│   ├── extension.toml       # Must be at root of selected directory
│   ├── Cargo.toml           # Rust extension for LSP launch
│   ├── src/lib.rs           # LSP command provider
│   ├── languages/
│   │   ├── dsl/
│   │   │   ├── config.toml      # grammar = "dsl" (must match [grammars.dsl])
│   │   │   ├── highlights.scm
│   │   │   ├── brackets.scm
│   │   │   ├── indents.scm
│   │   │   ├── outline.scm
│   │   │   ├── textobjects.scm
│   │   │   ├── overrides.scm
│   │   │   └── runnables.scm
│   │   └── playbook/
│   │       └── config.toml      # grammar = "yaml"
│   └── snippets/
│       └── dsl.json
└── tree-sitter-dsl/         # Grammar source
    ├── grammar.js
    ├── package.json         # tree-sitter-cli devDependency
    ├── src/parser.c         # Generated - run `npx tree-sitter generate`
    └── tree-sitter-dsl.wasm # Generated - run `npx tree-sitter build --wasm`
```

### Installation Steps

1. **Upgrade tree-sitter CLI** (0.22+ required for Docker-free WASM build):
   ```bash
   cd rust/crates/dsl-lsp/tree-sitter-dsl
   npm install tree-sitter-cli@latest --save-dev
   ```

2. **Generate grammar artifacts:**
   ```bash
   npx tree-sitter generate
   npx tree-sitter build --wasm   # Downloads wasi-sdk automatically, no Docker
   ```

3. **Verify config alignment:**
   - `languages/dsl/config.toml`: `grammar = "dsl"` (NOT "clojure")
   - `extension.toml`: `[grammars.dsl]` section exists with proper config

4. **Clean any stale grammar cache** (if reinstalling):
   ```bash
   rm -rf rust/crates/dsl-lsp/zed-extension/grammars/
   ```

5. **Install in Zed:**
   - Open Extensions panel (Cmd+Shift+X or `zed: extensions`)
   - Click **"Install Dev Extension"**
   - Select: `rust/crates/dsl-lsp/zed-extension/` (the directory with `extension.toml`)

6. **Verify:**
   - Open any `.dsl` file
   - Status bar should show "DSL" (not Clojure/Plain Text)
   - Syntax highlighting should work (verb names, keywords, symbols)

### extension.toml Grammar Config (EXACT FORMAT)

```toml
# For local development - file:// URL to REPO ROOT + path to grammar
# BOTH repository AND rev are REQUIRED (even for file://)
[grammars.dsl]
repository = "file:///Users/adamtc007/Developer/ob-poc"
rev = "c50cd396ac861ee21c8db56de664ed55b3a9b1f0"  # Must be actual commit SHA
path = "rust/crates/dsl-lsp/tree-sitter-dsl"

# For publishing - use https:// with commit SHA + path
[grammars.dsl]
repository = "https://github.com/your-org/ob-poc"
rev = "abc123def456"  # Must be commit SHA, NOT "main" or "HEAD"
path = "rust/crates/dsl-lsp/tree-sitter-dsl"
```

**To get current commit SHA:**
```bash
git rev-parse HEAD
```

### Common Failure Modes (Battle-Tested)

| Problem | Cause | Fix |
|---------|-------|-----|
| `.dsl` shows as Clojure | `grammar = "clojure"` in config.toml | Change to `grammar = "dsl"` |
| No highlighting | Grammar name mismatch | `config.toml` grammar must match `[grammars.X]` key |
| "missing field `rev`" | `rev` not specified | Add `rev = "<commit-sha>"` (required even for file://) |
| "pathspec 'HEAD' did not match" | `rev = "HEAD"` doesn't work | Use actual commit SHA from `git rev-parse HEAD` |
| "grammar directory already exists" | Stale cache | Delete `zed-extension/grammars/` and reinstall |
| "Failed to fetch grammar" | Wrong file:// path | Point to repo root, use `path` for subdirectory |
| "parser.c missing" | Grammar not generated | Run `npx tree-sitter generate` |
| WASM build needs Docker | Old tree-sitter CLI (<0.22) | `npm install tree-sitter-cli@latest` |
| Extension not found | Wrong folder selected | Must select folder containing `extension.toml` |
| TOML parse error with curly quotes | Copy-paste from docs | Replace `""` with `"`, `''` with `'` |
| "expected newline" in TOML | Malformed string escaping | Check `autoclose_before` and bracket strings |

### config.toml Gotchas

**NEVER use curly/smart quotes** - they break TOML parsing:
```toml
# WRONG - curly quotes from copy-paste
autoclose_before = "]"'"
brackets = [{ start = """, end = """ }]

# CORRECT - straight quotes
autoclose_before = "]'\""
brackets = [{ start = "\"", end = "\"" }]
```

### Debug

1. Open Zed log: `zed: open log` command
2. Search for "grammar", "extension", "TOML", or "dsl"
3. Look for specific error messages

Common log patterns:
- `compiled grammar dsl` = SUCCESS
- `TOML parse error at line X` = config.toml syntax error
- `missing field 'rev'` = extension.toml needs rev
- `failed to checkout revision` = wrong rev or stale cache

### Key Files

| File | Purpose |
|------|---------|
| `zed-extension/extension.toml` | Extension manifest + grammar registration |
| `zed-extension/languages/dsl/config.toml` | Language config (grammar binding) |
| `zed-extension/languages/playbook/config.toml` | Playbook YAML config |
| `zed-extension/languages/dsl/highlights.scm` | Syntax highlighting queries |
| `tree-sitter-dsl/grammar.js` | Grammar definition |
| `tree-sitter-dsl/package.json` | tree-sitter-cli version (keep at 0.22+) |
| `tree-sitter-dsl/src/parser.c` | Generated parser (commit this) |
| `tree-sitter-dsl/tree-sitter-dsl.wasm` | Compiled WASM (Zed compiles this itself) |

### After Making Changes

If you modify the grammar or extension config:
1. Re-run `npx tree-sitter generate` (if grammar.js changed)
2. Delete `zed-extension/grammars/` to clear cache
3. Re-run "Install Dev Extension" in Zed
4. Check `zed: open log` for errors

---

## DSL Language Server (dsl-lsp)

> ✅ **IMPLEMENTED (060-063)**: Full LSP with completions, hover, rename, diagnostics, code actions, and EntityGateway integration.

**Crate:** `rust/crates/dsl-lsp/` — Language Server Protocol implementation for the Onboarding DSL.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DSL LANGUAGE SERVER                                       │
│                                                                              │
│  Editor (Zed/VS Code)         LSP Server (tower-lsp)        External        │
│  ───────────────────          ──────────────────────        ────────        │
│                                                                              │
│  .dsl file opened    ───►    did_open()                                     │
│                               │                                              │
│                               ├─► parse_with_v2() (dsl-core)                │
│                               ├─► Extract symbols (@bindings)               │
│                               ├─► LspValidator.validate()                   │
│                               ├─► analyse_and_plan() (DAG)    ◄─── ob-poc  │
│                               └─► publish_diagnostics()                     │
│                                                                              │
│  User types          ───►    did_change() [debounced 100ms]                 │
│                               └─► Re-analyze + re-publish                   │
│                                                                              │
│  Ctrl+Space          ───►    completion()                                   │
│                               ├─► detect_completion_context()               │
│                               ├─► complete_verbs / keywords / symbols       │
│                               └─► EntityGateway lookup  ◄─── gRPC          │
│                                                                              │
│  Hover               ───►    hover()                                        │
│                               └─► Verb docs, symbol info, error suggestions │
│                                                                              │
│  F2 Rename           ───►    rename()                                       │
│                               └─► Find all symbol refs, apply edits         │
│                                                                              │
│  Cmd+.               ───►    code_action()                                  │
│                               ├─► Implicit creates (PlanningOutput)         │
│                               ├─► Reorder suggestions                       │
│                               └─► Entity "did you mean?" fixes              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### LSP Capabilities

| Capability | Handler | Features |
|------------|---------|----------|
| **Diagnostics** | `diagnostics.rs` | Syntax errors, semantic validation, DAG warnings |
| **Completion** | `completion.rs` | Verbs, `:keywords`, `@symbols`, entity lookups, next-step suggestions |
| **Hover** | `hover.rs` | Verb documentation, symbol info, error suggestions |
| **Go to Definition** | `goto_definition.rs` | Jump to `@symbol` definitions |
| **Find References** | `goto_definition.rs` | Find all uses of `@symbol` |
| **Rename** | `rename.rs` | Rename symbols across document |
| **Signature Help** | `signature.rs` | Verb argument hints while typing |
| **Document Symbols** | `symbols.rs` | Outline view of verbs and bindings |
| **Code Actions** | `code_actions.rs` | Quick fixes, implicit creates, reordering |

### Completion Contexts

The LSP detects context and routes to appropriate completer:

| Context | Trigger | Completions |
|---------|---------|-------------|
| `VerbName` | After `(` | All verbs from registry |
| `Keyword` | After verb name | Valid `:args` for that verb |
| `KeywordValue` | After `:keyword` | Enum values, entity lookups |
| `SymbolRef` | After `@` | Defined `@bindings` in document |
| `None` | Empty line | DAG-based next-step suggestions |

### Entity Gateway Integration

For entity completion (e.g., `:counterparty <...>`), the LSP connects to EntityGateway via gRPC:

```bash
# Environment variables
ENTITY_GATEWAY_URL=http://localhost:50051   # Default: [::1]:50051
DSL_CONFIG_DIR=/path/to/config/verbs/       # Verb YAML directory
```

If EntityGateway is unavailable, LSP falls back to syntax-only mode.

### Code Actions

Three sources of code actions from `PlanningOutput`:

| Source | Example Action |
|--------|----------------|
| `synthetic_steps` | "Create @cbu with cbu.create" (implicit binding) |
| `was_reordered` | "Reorder statements for dependencies" |
| `SemanticDiagnostic.suggestions` | "Did you mean 'John Smith'?" |

### Document Analysis Pipeline

```
DSL Source
    │
    ▼
parse_with_v2() ──► DocumentState { text, expressions, symbol_defs, symbol_refs }
    │
    ▼
LspValidator.validate() ──► SemanticDiagnostics (entity resolution errors)
    │
    ▼
analyse_and_plan() ──► PlanningOutput { phases, synthetic_steps, was_reordered }
    │
    ▼
publish_diagnostics() ──► Editor shows errors/warnings
```

### Shared Validation with Server

The LSP uses the **same validation code** as the server:

```rust
// Both LSP and server use:
ob_poc::parse_program()           // Parser
ob_poc::LspValidator              // Semantic validation
ob_poc::planning_facade           // DAG analysis
ob_poc::RuntimeVerbRegistry       // Verb metadata
```

This ensures LSP diagnostics match server behavior 100%.

### Playbook Support

Files matching `*.playbook.yaml` / `*.playbook.yml` get specialized handling:

- Parse with `playbook-core`
- Lower with `playbook-lower`
- Report missing required slots as warnings
- Validate verb references

### Running the LSP

```bash
# Direct execution
cargo run --release -p dsl-lsp

# Zed auto-launches via extension config
# VS Code: configure in settings.json
```

### Logging

LSP logs to file (stdout reserved for protocol):

```bash
tail -f /tmp/dsl-lsp.log

# Control verbosity
DSL_LSP=trace cargo run -p dsl-lsp   # Max verbosity
DSL_LSP=warn cargo run -p dsl-lsp    # Errors only
```

### Key Files

| File | Purpose |
|------|---------|
| `src/main.rs` | Entry point, stdio setup |
| `src/server.rs` | Core LSP state machine, lifecycle |
| `src/analysis/document.rs` | `DocumentState` - parsed document representation |
| `src/analysis/context.rs` | `detect_completion_context()` |
| `src/handlers/completion.rs` | Completion logic with sub-completers |
| `src/handlers/diagnostics.rs` | Validation pipeline |
| `src/handlers/code_actions.rs` | Code action generation |
| `src/handlers/hover.rs` | Hover information |
| `src/handlers/rename.rs` | Symbol rename |
| `src/encoding.rs` | UTF-16/UTF-8 position conversion |
| `src/entity_client.rs` | gRPC client for EntityGateway |

### Performance

| Optimization | Implementation |
|--------------|----------------|
| Debouncing | 100ms delay on `did_change` |
| Incremental sync | Clients send deltas, not full text |
| Lazy EntityGateway | Only connects when completion needs entities |
| Lazy planning | Only runs if no parse errors |
| Caching | Verb registry and macro registry cached in `OnceLock` |

---

## Staged Runbook REPL (054)

> ❌ **REMOVED (2026-02-13)**: V1 staged runbook deleted. Superseded by V2 REPL pack-guided runbook architecture.
> All source files, MCP tools, verb YAML, and CustomOp handlers removed. DB tables in migration 054 retained for reference.

---

## Client Group Research Integration (055)

> ✅ **IMPLEMENTED (2026-01-26)**: GLEIF import populates client_group_entity staging tables, then CBU creation with GLEIF role mapping.

**Problem Solved:** Research (GLEIF import) and onboarding (CBU creation) were coupled. Now they are separate concerns:
1. **Research phase**: GLEIF import → entities + `client_group_entity` staging
2. **Onboarding phase**: `cbu.create-from-client-group` → CBUs with role mapping

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  PHASE 1: RESEARCH (GLEIF Import)                                           │
│                                                                              │
│  (gleif.import-tree :entity-id <Allianz SE> :depth 3)                       │
│      │                                                                       │
│      ├─► entities table (all LEI entities)                                  │
│      ├─► entity_funds (with gleif_category: FUND, GENERAL)                  │
│      ├─► entity_parent_relationships (corporate hierarchy)                  │
│      └─► client_group_entity + client_group_entity_roles                    │
│              │                                                               │
│              └─► Roles: SUBSIDIARY, ULTIMATE_PARENT (corporate hierarchy)   │
└─────────────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  PHASE 2: ONBOARDING (CBU Creation)                                         │
│                                                                              │
│  (cbu.create-from-client-group :group-id <Allianz> :gleif-category "FUND")  │
│      │                                                                       │
│      ├─► Query client_group_entity WHERE gleif_category = 'FUND'            │
│      │                                                                       │
│      ├─► Create CBU per entity                                               │
│      │                                                                       │
│      └─► Assign CBU entity roles via GLEIF→CBU role mapping:                │
│              • GLEIF category FUND → ASSET_OWNER                            │
│              • Group role ULTIMATE_PARENT → HOLDING_COMPANY                 │
│              • Group role SUBSIDIARY → SUBSIDIARY                           │
│              • Optional: MANAGEMENT_COMPANY, INVESTMENT_MANAGER             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### GLEIF Role → CBU Role Mapping

| GLEIF Source | CBU Entity Role | Rationale |
|--------------|-----------------|-----------|
| `gleif_category = 'FUND'` | `ASSET_OWNER` | Fund entity owns its trading unit |
| `group_role = 'ULTIMATE_PARENT'` | `HOLDING_COMPANY` | Top of corporate hierarchy |
| `group_role = 'SUBSIDIARY'` | `SUBSIDIARY` | Corporate subsidiary |
| (default) | `ASSET_OWNER` | Safe default for fund onboarding |

### Key Verbs

| Verb | Description |
|------|-------------|
| `gleif.import-tree` | Import corporate hierarchy from GLEIF into entities + client_group_entity |
| `cbu.create-from-client-group` | Create CBUs from staged entities with role mapping |

### DSL Usage

```clojure
;; Phase 1: Research - import corporate hierarchy
(gleif.import-tree :entity-id <Allianz SE> :depth 3 :as @import)

;; Phase 2: Onboard - create CBUs for Luxembourg FUNDs
(cbu.create-from-client-group 
  :group-id <Allianz>
  :gleif-category "FUND"
  :jurisdiction-filter "LU"
  :manco-entity-id <AGI Holdings GmbH>)

;; Dry-run to preview
(cbu.create-from-client-group 
  :group-id <Allianz>
  :gleif-category "FUND"
  :dry-run true
  :limit 10)
```

### Key Tables

| Table | Purpose |
|-------|---------|
| `client_group_entity` | Staging: entities discovered via research |
| `client_group_entity_roles` | Staging: GLEIF roles (SUBSIDIARY, ULTIMATE_PARENT) |
| `entity_funds.gleif_category` | GLEIF entity classification (FUND, GENERAL) |
| `cbu_entity_roles` | Production: CBU membership roles |

### Key Files

| File | Purpose |
|------|---------|
| `migrations/055_client_group_research.sql` | Schema for client_group_entity_roles |
| `rust/src/gleif/enrichment.rs` | GLEIF tree import with relationship tracking |
| `rust/src/domain_ops/gleif_ops.rs` | `GleifImportTreeOp` - links to client_group_entity |
| `rust/src/domain_ops/cbu_ops.rs` | `CbuCreateFromClientGroupOp` - CBU creation with role mapping |
| `rust/config/verbs/cbu.yaml` | `create-from-client-group` verb definition |

---

## Verb Search Test Harness & Learning Accelerator

Comprehensive test harness for verifying semantic matching after teaching new phrases or tuning thresholds. Includes a **learning accelerator workflow** that uses LLM-generated phrases to rapidly improve verb discovery accuracy.

### Quick Start

```bash
# Run all verb search tests
cargo x test-verbs

# Specific test categories
cargo x test-verbs --taught       # Only taught phrase tests
cargo x test-verbs --hard-negatives  # Dangerous confusion detection
cargo x test-verbs --sweep        # Threshold calibration sweep

# Explore a specific query
cargo x test-verbs --explore "load the allianz book"

# API coverage harness (live server execute path)
# 1) Start server:
# DATABASE_URL="postgresql:///data_designer" OBPOC_ALLOW_RAW_EXECUTE=true OBPOC_STRICT_SEMREG=false cargo run -p ob-poc-web
# 2) Run harness:
RUSTC_WRAPPER= cargo test --test utterance_api_coverage -- --ignored --nocapture
```

The API harness validates `registry.discover-dsl` end-to-end via `/api/session/:id/execute`, then writes:
- `target/utterance-api-coverage/utterance_coverage_results.json`
- `target/utterance-api-coverage/utterance_coverage_report.md`
- `target/utterance-api-coverage/utterance_verb_xref.csv`

### Test Categories

| Category | Purpose |
|----------|---------|
| `taught` | Verify taught phrases match expected verbs |
| `session` | Session management verbs (load, unload, undo) |
| `cbu` | CBU lifecycle verbs |
| `hard_negative` | Dangerous confusions (delete vs archive) |
| `safety_first` | Verbs where ambiguity is acceptable |
| `edge` | Edge cases (garbage input, ambiguous queries) |

### Learning Accelerator Workflow

The test harness enables a closed-loop learning accelerator:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  LEARNING ACCELERATOR WORKFLOW                                               │
│                                                                              │
│  1. Run test harness → Identify failing phrases                             │
│         │                                                                    │
│         ▼                                                                    │
│  2. Harness outputs SQL for phrases that need teaching                      │
│         │                                                                    │
│         ▼                                                                    │
│  3. Execute SQL via agent.teach_phrases_batch()                             │
│         │                                                                    │
│         ▼                                                                    │
│  4. Run populate_embeddings (delta loading - fast)                          │
│         │                                                                    │
│         ▼                                                                    │
│  5. Re-run test harness → Validate improvement                              │
│         │                                                                    │
│         └──► Repeat until target accuracy achieved                          │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Commands:**

```bash
# Step 1: Run extended CBU scenarios to find gaps
DATABASE_URL="postgresql:///data_designer" \
  cargo test --features database --test verb_search_integration test_cbu_extended -- --ignored --nocapture

# Step 2: Harness outputs SQL like:
# SELECT * FROM agent.teach_phrases_batch('[{"phrase": "create a fund", "verb": "cbu.create"}, ...]'::jsonb, 'accelerated_learning');

# Step 3: Execute the SQL (or use scripts/teach_cbu_phrases.sql)
psql -d data_designer -f scripts/teach_cbu_phrases.sql

# Step 4: Populate embeddings (delta loading - only new patterns)
DATABASE_URL="postgresql:///data_designer" \
  cargo run --release --package ob-semantic-matcher --bin populate_embeddings

# Step 5: Re-run to validate
DATABASE_URL="postgresql:///data_designer" \
  cargo test --features database --test verb_search_integration test_cbu_extended -- --ignored --nocapture
```

**Example Results (CBU domain):**

| Round | Pass Rate | Top-1 Correct | Top-3 Contains | Ambiguity Rate |
|-------|-----------|---------------|----------------|----------------|
| Baseline | 15.2% | 13.2% | 32.5% | 66.9% |
| Round 1 | 61.6% | 58.9% | 88.7% | 40.4% |
| Round 2 | **78.1%** | **75.5%** | **95.4%** | **23.8%** |

Remaining failures are typically **legitimate disambiguation cases** where the system correctly asks for clarification.

### Extended Test Scenarios

The `cbu_phrase_scenarios.rs` module provides ~150 test scenarios across CBU verbs:

```rust
// rust/tests/cbu_phrase_scenarios.rs
pub fn all_cbu_scenarios() -> Vec<TestScenario> {
    let mut all = Vec::new();
    all.extend(cbu_create_scenarios());      // 34 scenarios
    all.extend(cbu_list_scenarios());        // 21 scenarios
    all.extend(cbu_assign_role_scenarios()); // 34 scenarios
    all.extend(cbu_parties_scenarios());     // 13 scenarios
    // ... etc
    all
}
```

**Adding scenarios for other domains:**
1. Create `<domain>_phrase_scenarios.rs` in `rust/tests/`
2. Define `TestScenario::matched()` for expected phrase→verb mappings
3. Use `TestScenario::safety_first()` for destructive operations
4. Add module to `verb_search_integration.rs`

### Threshold Sweep (Full Pipeline)

The sweep tests both retrieval AND decision thresholds:

```bash
# Quick sweep (3 combinations)
cargo x test-verbs --sweep

# Full sweep (180 combinations) - comprehensive exploration
DATABASE_URL="postgresql:///data_designer" \
  cargo test --features database --test verb_search_integration test_threshold_sweep_full -- --ignored --nocapture
```

**Output:**
```
sem_thr  fall_thr margin top1_hit%   ambig%    wrong no_match
   0.85     0.78   0.05      85.0       5.0        0        2
   0.88     0.78   0.05      80.0       8.0        0        4
   ...
✓ BEST (0 wrong): semantic=0.85 fallback=0.78 margin=0.05 → 85.0% top-1
```

### Safety-First Policy

For dangerous verb pairs (delete/archive, approve/submit), the harness uses `ExpectedOutcome::MatchedOrAmbiguous`:

- **Matched(correct)** → Pass (correct verb selected)
- **Ambiguous** → Pass (disambiguation UI triggered - safe)
- **Matched(wrong)** → FAIL (dangerous confusion)

This prevents optimizing for overconfident behavior on safety-critical verbs.

### Key Files

| File | Purpose |
|------|---------|
| `rust/tests/verb_search_integration.rs` | Main test harness with `VerbSearchTestHarness` |
| `rust/tests/cbu_phrase_scenarios.rs` | Extended CBU test scenarios (~150 phrases) |
| `rust/xtask/src/main.rs` | `cargo x test-verbs` command |
| `scripts/teach_cbu_phrases.sql` | Batch teaching script for CBU verbs |
| `migrations/044_agent_teaching.sql` | `agent.teach_phrases_batch()` function |

---

## Session Verbs

Session manages which CBUs are loaded. Focus/camera is client-side.

| Verb | Purpose |
|------|---------|
| `session.load-cbu` | Add single CBU to session |
| `session.load-jurisdiction` | Load all CBUs in jurisdiction |
| `session.load-galaxy` | Load all CBUs under apex entity |
| `session.unload-cbu` | Remove CBU from session |
| `session.clear` | Clear all CBUs |
| `session.undo` / `session.redo` | History navigation |
| `session.info` / `session.list` | Query session state |

### View Verbs (ESPER Navigation)

| Verb | Description |
|------|-------------|
| `view.universe` | All CBUs with optional filters |
| `view.book` | CBUs for commercial client |
| `view.cbu` | Focus single CBU (mode: trading/ubo) |
| `view.drill` | Drill into entity (within UBO taxonomy) |
| `view.surface` | Surface up from drill |
| `view.trace` | Follow threads (money/control/risk) |
| `view.xray` | Show hidden layers |
| `view.refine` | Add/remove filters |

---

## Navigation (Unified Intent Pipeline)

All user input—including navigation commands—goes through the unified `IntentPipeline`. Navigation phrases match to `view.*` and `session.*` verbs via semantic search. There is no separate ESPER path.

### Architecture

```
User: "zoom in" / "load the allianz book" / "show ownership"
    │
    ▼
IntentPipeline.process()
    │
    ├─ HybridVerbSearcher.search()
    │       │
    │       ├─ Exact match (learned phrases)
    │       └─ Semantic search (BGE embeddings)
    │
    ├─ Top match: view.drill / session.load-galaxy / control.build-graph
    │
    └─ LLM extracts args → DSL generated → Execute
```

### Key Files

| File | Purpose |
|------|---------|
| `rust/src/mcp/intent_pipeline.rs` | Unified intent processing |
| `rust/src/mcp/verb_search.rs` | `HybridVerbSearcher` - semantic + exact match |
| `rust/src/mcp/noun_index.rs` | `NounIndex` + `VerbContractIndex` - ECIR Tier -1 noun→verb |
| `rust/config/noun_index.yaml` | 99-noun taxonomy for deterministic verb resolution |
| `rust/src/mcp/scenario_index.rs` | `ScenarioIndex` - Tier -2A journey-level scenario resolution |
| `rust/src/mcp/compound_intent.rs` | `CompoundSignals` - shared compound signal extraction |
| `rust/src/mcp/sequence_validator.rs` | Macro sequence prereq validation |
| `rust/src/mcp/macro_index.rs` | `MacroIndex` - Tier -2B deterministic macro search |
| `rust/config/scenario_index.yaml` | 16 journey scenario definitions (incl. 3 macro_sequence) |
| `rust/config/macro_search_overrides.yaml` | Curated macro search aliases |
| `rust/src/api/agent_service.rs` | `AgentService.process_chat()` entry point |
| `rust/config/verbs/view.yaml` | Navigation verbs (view.drill, view.surface, etc.) |
| `rust/config/verbs/session.yaml` | Session verbs (session.load-galaxy, etc.) |

### Navigation Verbs

| Verb | Purpose | Example Phrases |
|------|---------|-----------------|
| `view.universe` | Show all CBUs | "show universe", "zoom out to all" |
| `view.cbu` | Focus single CBU | "focus on this cbu", "show cbu details" |
| `view.drill` | Drill into entity | "drill down", "go deeper" |
| `view.surface` | Surface back up | "go back", "zoom out" |
| `session.load-galaxy` | Load CBUs under apex | "load the allianz book" |
| `session.load-cbu` | Load single CBU | "load cbu acme fund" |
| `session.clear` | Clear session | "clear", "start fresh" |
| `session.undo` / `session.redo` | History navigation | "undo", "redo" |

### Verb Search Thresholds (BGE Asymmetric Mode)

BGE uses **asymmetric retrieval**: queries get an instruction prefix (`"Represent this sentence for searching relevant passages: "`), targets don't. This produces **lower** similarity scores than symmetric (target-to-target) comparison:

- **Symmetric (target→target):** scores 0.6-1.0 (same-embedding comparison, like DB tests)
- **Asymmetric (query→target):** scores 0.5-0.8 (instruction-prefixed query vs raw target)

| Threshold | Value | Purpose |
|-----------|-------|---------|
| `fallback_threshold` | 0.55 | Retrieval cutoff for DB queries (must be low enough to retrieve candidates) |
| `semantic_threshold` | 0.65 | Decision gate for accepting match |
| `blocklist_threshold` | 0.80 | Collision detection |

> **Warning:** If you see "No matching verbs found" for queries that should match, check that asymmetric thresholds are being used. The old symmetric thresholds (0.70/0.78) will reject valid asymmetric matches.

### Adding Navigation Phrases

Add to the verb's `invocation_phrases` in YAML, then run `populate_embeddings`:

```yaml
# rust/config/verbs/view.yaml
drill:
  description: "Drill into entity detail"
  invocation_phrases:
    - "drill down"
    - "go deeper"
    - "zoom into"
    - "enhance"      # Add new phrase here
```

```bash
DATABASE_URL="postgresql:///data_designer" \
  cargo run --release --package ob-semantic-matcher --bin populate_embeddings
```

---

## Scenario-Based Intent Resolution (Phases 0.5-5)

> ✅ **IMPLEMENTED (2026-03-02)**: Two new intent tiers giving macros search parity and enabling compound intent recognition, while maintaining determinism and zero regression on single-verb hit rates.

**Problem Solved:** Macros (54 total, 18 multi-verb) only got exact label/FQN matching in Tier 0, while DSL verbs (1,263) benefited from 10 tiers of search. This asymmetry caused the pipeline to miss composite intents like "Onboard a Luxembourg SICAV" — falling through to a single verb (`fund.create-umbrella` at 0.80) instead of the correct macro (`struct.lux.ucits.sicav` — 13 verbs producing a full runbook).

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  COMPOUND INTENT RESOLUTION PIPELINE                                         │
│                                                                              │
│  User: "Onboard a Luxembourg SICAV with three sub-funds"                    │
│         │                                                                    │
│         ▼                                                                    │
│  1. Extract CompoundSignals ONCE                                            │
│     compound_action: "onboard", jurisdiction: "LU",                         │
│     structure_nouns: ["sicav"], has_quantifier: true                         │
│         │                                                                    │
│         ▼                                                                    │
│  2. ECIR Tier -1 probe (existing)                                           │
│     IF 1 candidate AND no compound signals → short-circuit (existing)       │
│     IF compound signals present → suppress short-circuit, continue          │
│         │                                                                    │
│         ▼                                                                    │
│  3. Tier -2A: ScenarioIndex.resolve() — score 0.97                         │
│     Scoring ledger: action(+4) + jurisdiction(+4) + noun(+3) = 11 ≥ 8     │
│     → Match: lux-sicav-setup → struct.lux.ucits.sicav                      │
│         │                                                                    │
│         ▼                                                                    │
│  4. Tier -2B: MacroIndex.resolve() — score 0.96 (fallback if no scenario)  │
│     Deterministic index: FQN(+10), label(+8), alias(+6), jurisdiction(+3)  │
│         │                                                                    │
│         ▼                                                                    │
│  5. Tiers -1 through 7 (existing verb pipeline, unchanged)                  │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Phase Summary

| Phase | What | Key Deliverable |
|-------|------|-----------------|
| **0.5** | MacroIndex (Tier -2B) | Deterministic searchable index over ~54 macros, 7 lookup maps, scoring with gates |
| **1** | ScenarioIndex (Tier -2A) | Journey-level compound utterance resolution, scoring ledger, 3 hard gates (G1-G3) |
| **1B** | SequenceValidator | Three-valued prereq validation for `macro_sequence` routes (Pass/Fail/Deferred) |
| **2** | Guided Runbook Building | Provenance labels (`origin_scenario_id`, `origin_macro_fqn`) on expanded entries, progress narration |
| **3** | Macro Sequence Orchestration | `macro_sequence` + `macro_selector` route types, DecisionPacket for disambiguation |
| **4** | Macro Gap Filling | 7 new macros (screening.full, kyc.collect-documents, kyc.full-review, etc.), 4 new scenarios |
| **5** | Measurement + Tuning | 43 Tier-2 test cases, 5 hard threshold assertions matching spec §11 success criteria |

### ScenarioIndex Scoring Ledger

| Signal Bucket | Score |
|---------------|-------|
| Compound outcome verb (onboard, set up, establish) | +4 |
| Jurisdiction found (LU, IE, UK, US) | +4 |
| Structure noun (sicav, icav, LP) | +3 |
| Phase noun (KYC, screening, mandate) | +2 |
| Quantifier ("three sub-funds") | +2 |
| Macro metadata match | +3 |
| Negative: single-verb cue | −6 |

**Hard gates:** G1 (compound signal required), G2 (mode compatibility), G3 (min score ≥ 8)

### MacroIndex Scoring

| Signal | Score |
|--------|-------|
| Exact FQN match | +10 |
| Exact label match | +8 |
| Alias/phrase match | +6 |
| Jurisdiction match | +3 |
| Mode match | +2 |
| Noun overlap | +2 |
| Target kind match | +2 |
| Mismatch penalty | −999 (hard exclude) |

**Hard gates:** M1 (mode compatibility), M2 (min score ≥ 6), M3 (disambiguation band Δ ≤ 2 → DecisionPacket)

### Scenario Route Types

| Route Kind | Description | Example |
|------------|-------------|---------|
| `macro` | Single macro FQN | `struct.lux.ucits.sicav` |
| `macro_sequence` | Ordered list of macros | `[case.open, screening.full, kyc.collect-documents]` |
| `macro_selector` | Jurisdiction-dependent selection | LU→sicav, IE→icav, UK→oeic |

### Provenance Labels

When macro expansion creates RunbookEntries, provenance labels are threaded through:

```rust
entry.labels.insert("origin_kind".into(), "macro".into());
entry.labels.insert("origin_macro_fqn".into(), macro_fqn.into());
entry.labels.insert("origin_scenario_id".into(), scenario_id.into());
```

Progress narration uses these labels: "Step 4 of 13: Luxembourg UCITS SICAV Setup"

### Success Criteria (spec §11)

| Metric | Target | Assertion |
|--------|--------|-----------|
| Compound intent → correct scenario | ≥80% | `assert!(scenario_verb_rate >= 80.0)` |
| Scenario → correct macro/sequence | ≥90% | `assert!(scenario_route_rate >= 90.0)` |
| MacroIndex → correct macro | ≥75% | `assert!(macro_rate >= 75.0)` |
| Single-verb NOT intercepted by Tier -2 | ≥95% (<5% FP) | `assert!(fp_rate < 5.0)` |
| No regression in single-verb hit rate | ≥35% baseline | `assert!(sv_rate >= 35.0)` |

### 16 Journey Scenarios

| ID | Route Kind | Target |
|----|-----------|--------|
| `lux-sicav-setup` | macro | `struct.lux.ucits.sicav` |
| `lux-raif-setup` | macro | `struct.lux.aif.raif` |
| `lux-pe-setup` | macro | `struct.lux.pe.scsp` |
| `ie-icav-setup` | macro | `struct.ie.ucits.icav` |
| `uk-oeic-setup` | macro | `struct.uk.authorised.oeic` |
| `us-40act-setup` | macro | `struct.us.40act.open-end` |
| `generic-fund-onboarding` | macro_selector | By jurisdiction |
| `full-screening` | macro | `screening.full` |
| `full-kyc-review` | macro | `kyc.full-review` |
| `kyc-doc-collection` | macro | `kyc.collect-documents` |
| `full-kyc-onboarding` | macro_sequence | case.open → screening.full → kyc.collect-documents |
| `kyc-case-screening` | macro_sequence | case.open → screening.full |
| `kyc-case-documents` | macro_sequence | case.open → kyc.collect-documents |
| `hedge-cross-border-setup` | macro | `struct.hedge.cross-border` |
| `pe-cross-border-setup` | macro | `struct.pe.cross-border` |

### Key Files

| File | Purpose |
|------|---------|
| `rust/src/mcp/scenario_index.rs` | ScenarioIndex: YAML loader, scoring ledger, hard gates, resolver |
| `rust/src/mcp/compound_intent.rs` | CompoundSignals extraction, jurisdiction detection, action classification |
| `rust/src/mcp/sequence_validator.rs` | Three-valued macro sequence prereq validation |
| `rust/src/mcp/macro_index.rs` | MacroIndex: 7 lookup maps, scoring, hard gates, resolver |
| `rust/config/scenario_index.yaml` | 16 journey scenario definitions |
| `rust/config/macro_search_overrides.yaml` | Curated macro search aliases (optional) |
| `rust/src/mcp/verb_search.rs` | Tier -2A/B integration in `HybridVerbSearcher.search()` |
| `rust/src/mcp/verb_search_factory.rs` | Factory wiring for ScenarioIndex + MacroIndex |
| `rust/src/dsl_v2/macros/expander.rs` | Provenance label threading in `expand_macro()` |
| `rust/src/repl/runbook.rs` | Progress narration using `origin_scenario_id` label |
| `rust/tests/intent_hit_rate.rs` | Tier-2 test harness with 5 hard threshold assertions |
| `rust/tests/fixtures/intent_test_utterances.toml` | 43 Tier-2 test cases (17 scenario + 14 macro_match + 5 blocker + 7 sequence) |
| `docs/todo/Scenario-Based Intent Resolution.md` | Source spec (v0.3) |

---

## AffinityGraph & Schema-Driven Diagram Generation

> ✅ **IMPLEMENTED (2026-03-03)**: Bidirectional verb↔data index built entirely from active registry snapshots. Diagram generation as a projection of the graph rather than standalone schema introspection.

**Problem Solved:** The Semantic Registry already implicitly knew which verbs produce/consume which entities, which attributes map to which table columns, and how verbs relate through shared data. The AffinityGraph makes this implicit knowledge queryable — enabling "what verbs touch the `cbus` table?", "what data does `cbu.create` read/write?", and "generate an ERD with verb surface annotations" — without additional DB tables or migrations.

### Architecture

```
Registry Snapshots (active SnapshotRows)
    │
    ├─ VerbContracts ──── Pass 1 ──► Forward edges (verb→data)
    ├─ EntityTypeDefs ─── Pass 2 ──► Entity↔table bimaps
    ├─ AttributeDefs ──── Pass 3 ──► Reverse edges (data→verb)
    ├─ DerivationSpecs ── Pass 4 ──► Lineage edges
    └─ RelationshipTypeDefs Pass 5 ► Entity↔entity edges
                                          │
                                          ▼
                                   AffinityGraph
                                   (in-memory, Arc<RwLock<>> cached)
                                          │
                          ┌───────────────┼───────────────┐
                          ▼               ▼               ▼
                   Query Surface    Diagram Projection  Governance
                   (10 methods)     (ERD/VerbFlow)     (orphans, gaps)
```

### Module Placement

```
sem_os_core/src/
├── affinity/           # NEW — pure value types + builder + queries
│   ├── mod.rs          # AffinityGraph struct + build() + re-exports
│   ├── types.rs        # AffinityEdge, DataRef, TableRef, ColumnRef, AffinityKind, etc.
│   ├── builder.rs      # 5-pass builder from SnapshotRows
│   └── query.rs        # 10 query methods
│
├── diagram/            # NEW — model types + enrichment + Mermaid rendering
│   ├── mod.rs          # Re-exports + GovernanceLevel
│   ├── model.rs        # DiagramModel, DiagramEntity, DiagramAttribute, RenderOptions
│   ├── enrichment.rs   # build_diagram_model(tables, graph, options) → DiagramModel
│   └── mermaid.rs      # MermaidRenderer (erDiagram + graph LR + graph TD)
│
rust/src/domain_ops/
└── affinity_ops.rs     # NEW — 6 CustomOp handlers for registry.* verbs

rust/crates/sem_os_obpoc_adapter/src/
└── metadata.rs         # NEW — DomainMetadata YAML overlay types + loader
```

### 5-Pass Builder

`AffinityGraph::build(snapshots: &[SnapshotRow]) -> Result<Self>` — takes a flat slice of active `SnapshotRow` (all object types), deserializes relevant body types, and runs 5 passes:

| Pass | Source | Output |
|------|--------|--------|
| 1 | `VerbContractBody` | Forward edges: `Produces`, `Consumes`, `CrudRead/Insert/Update/Delete`, `ArgLookup{arg_name}` — also consumes `reads_from`/`writes_to` supplemental fields |
| 2 | `EntityTypeDefBody` | `entity_to_table` + `table_to_entity` bimaps (from `db_table` field) |
| 3 | `AttributeDefBody` | Reverse edges: `ProducesAttribute`, `ConsumesAttribute{arg_name}` + `attribute_to_column` map |
| 4 | `DerivationSpecBody` | `DerivationEdge { from_attribute, to_attribute, spec_fqn }` lineage edges |
| 5 | `RelationshipTypeDefBody` | `EntityRelationship { source_fqn, target_fqn, cardinality, edge_class }` |

After all passes: `verb_to_data` and `data_to_verb` forward/reverse indexes built from `edges` vec.

### 10 Query Methods

**6 Core Queries:**

| Method | Returns | Description |
|--------|---------|-------------|
| `verbs_for_table(schema, table)` | `Vec<VerbAffinity>` | All verbs reading/writing/referencing a table |
| `verbs_for_attribute(attr_fqn)` | `Vec<VerbAffinity>` | Verbs producing or consuming an attribute |
| `verbs_for_entity_type(entity_fqn)` | `Vec<VerbAffinity>` | Verbs operating on entity type (via entity→table→verbs) |
| `data_for_verb(verb_fqn)` | `Vec<DataAffinity>` | All data assets a verb touches |
| `data_footprint(verb_fqn, depth)` | `DataFootprint` | Transitive reach (follows arg lookups + derivations up to N hops) |
| `adjacent_verbs(verb_fqn)` | `Vec<(String, Vec<DataRef>)>` | Verbs sharing data dependencies with given verb |

**4 Governance Queries:**

| Method | Returns | Description |
|--------|---------|-------------|
| `orphan_tables(known_tables)` | `Vec<TableRef>` | Tables with no verb affinity (ungoverned data) |
| `orphan_verbs()` | `Vec<String>` | Verbs with no data affinity (disconnected operations) |
| `write_only_attributes()` | `Vec<String>` | Attributes with source but no consuming sinks |
| `read_before_write_attributes()` | `Vec<String>` | Attributes with sinks but no producing source |

### DiagramModel + MermaidRenderer

```rust
// Enrichment pipeline
pub fn build_diagram_model(
    tables: &[TableInput],       // Caller-provided physical schema (name, columns, FKs)
    graph: &AffinityGraph,       // From active registry snapshots
    options: &RenderOptions,     // schema_filter, domain_filter, max_tables, include_columns
) -> DiagramModel

// Three render modes
MermaidRenderer::render_erd(&model, &options)         // erDiagram syntax
MermaidRenderer::render_verb_flow(&model, verb_fqn)   // graph LR with verb→data edges
MermaidRenderer::render_domain_map(&model, &options)  // graph TD with domain subgraphs
```

**GovernanceLevel** annotation on each `DiagramEntity`:
- `Full` — entity type matched in registry + verbs present
- `Partial` — some verbs matched but no canonical entity type
- `None` — table not registered in registry at all

**Key details:** All Mermaid node IDs are sanitized (hyphens → underscores, non-alphanumeric stripped). Output is deterministic (entities and relationships sorted before rendering). `RenderOptions.max_tables` limits diagram size; `domain_filter` / `schema_filter` scope to specific domains.

### 9 New Verbs

**6 Affinity Navigation Verbs (appended to `rust/config/verbs/sem-reg/registry.yaml`):**

| Verb FQN | Description |
|----------|-------------|
| `registry.verbs-for-table` | Find all verbs that read, write, or reference a database table |
| `registry.verbs-for-attribute` | Find all verbs that produce or consume an attribute |
| `registry.data-for-verb` | Find all data assets a verb touches (with optional transitive `depth`) |
| `registry.adjacent-verbs` | Find verbs sharing data dependencies |
| `registry.governance-gaps` | Identify orphan tables, orphan verbs, write-only/read-before-write attributes |
| `registry.discover-dsl` | Utterance→intent→DSL discovery with ranked `intent_matches`, `suggested_sequence`, `disambiguation_needed`, and `governance_context` |

**3 Diagram Generation Verbs (appended to `rust/config/verbs/sem-reg/schema.yaml`):**

| Verb FQN | Description |
|----------|-------------|
| `schema.generate-erd` | Generate entity-relationship diagram with verb surface annotations |
| `schema.generate-verb-flow` | Generate verb-centric data flow diagram |
| `schema.generate-discovery-map` | Generates Mermaid utterance→intent→verb→data discovery map projection |

Each verb has 8+ invocation phrases for semantic discovery. After adding, always run `populate_embeddings`.

### CoreService Integration

```rust
// New method on CoreService trait
async fn get_affinity_graph(&self) -> Result<Arc<AffinityGraph>>;

// Cache in CoreServiceImpl
affinity_graph: Arc<RwLock<Option<AffinityGraph>>>
```

- On first call: builds from `stores.snapshots.load_active_snapshots()` if cache empty
- After `bootstrap_seed_bundle()`: triggers cache rebuild automatically
- Thread-safe via `Arc<RwLock<>>`
- Graceful degradation: returns empty `AffinityGraph` if no snapshots exist (never fails the request)

**CustomOps access pattern:** Each op calls `load_affinity_graph(pool)` which invokes `CoreService::get_affinity_graph()`. Follow existing patterns in `sem_reg_schema_ops.rs` for how `ExecutionContext` provides service access.

### DomainMetadata YAML Overlay

`rust/config/sem_os_seeds/domain_metadata.yaml` supplements the registry with verb→table forward mappings that the registry alone may not capture (e.g., verbs that lack `crud_mapping` or explicit `produces` fields):

```yaml
domains:
  cbu:
    description: "Client Business Unit domain"
    tables:
      - name: cbus
        description: "Core CBU records"
        governance_tier: governed
        pii: false
    verb_data_footprint:
      cbu.create:
        writes_to: [cbus]
      cbu.list:
        reads_from: [cbus]
```

**Types:** `DomainMetadataFile` → `BTreeMap<String, DomainEntry>` with `TableMetadata` and per-verb `VerbFootprint`. Loaded by `sem_os_obpoc_adapter::metadata::load_domain_metadata(path)`. The enriched `reads_from`/`writes_to` fields on `VerbContractBody` and `read_by_verbs`/`written_by_verbs` on `EntityTypeDefBody` are supplemental edge sources consumed by Pass 1 and Pass 2.

### Commands

```bash
# Adapter tests (seed bundle enrichment)
cargo test -p sem_os_obpoc_adapter

# Core unit tests (AffinityGraph types, builder, queries, diagram)
cargo test -p sem_os_core -- affinity
cargo test -p sem_os_core -- diagram

# Pre-commit (format + clippy + unit tests)
cargo x pre-commit

# Integration tests (requires database)
DATABASE_URL="postgresql:///data_designer" \
  cargo test --features database --test affinity_integration -- --ignored --nocapture

# Discovery ops runtime wiring smoke tests (requires database)
DATABASE_URL="postgresql:///data_designer" \
  cargo test --features database --test discovery_ops_integration -- --ignored --nocapture

# API utterance coverage harness (requires running ob-poc-web on :3002 by default)
RUSTC_WRAPPER= \
  cargo test --test utterance_api_coverage -- --ignored --nocapture

# Optional coverage gate + filter
UTTERANCE_FILTER=hard \
UTTERANCE_MIN_ACCURACY=0.25 \
RUSTC_WRAPPER= \
  cargo test --test utterance_api_coverage -- --ignored --nocapture

# Populate embeddings (after adding new verb YAML with 9 new verbs)
DATABASE_URL="postgresql:///data_designer" \
  cargo run --release --package ob-semantic-matcher --bin populate_embeddings
```

### Key Files

| File | Purpose |
|------|---------|
| `rust/crates/sem_os_core/src/affinity/types.rs` | `AffinityGraph`, `AffinityEdge`, `AffinityKind` (9 variants), `AffinityProvenance`, `DataRef`, `TableRef`, `ColumnRef`, `VerbAffinity`, `DataAffinity`, `DataFootprint` |
| `rust/crates/sem_os_core/src/affinity/builder.rs` | 5-pass builder, `AffinityGraph::build(snapshots)` |
| `rust/crates/sem_os_core/src/affinity/query.rs` | 10 query methods (6 core + 4 governance) |
| `rust/crates/sem_os_core/src/affinity/discovery.rs` | Discovery pipeline types + logic: `match_intent`, `synthesize_chain`, `generate_disambiguation`, `discover_dsl`, discovery-map edge projection |
| `rust/crates/sem_os_core/src/affinity/mod.rs` | Module re-exports |
| `rust/crates/sem_os_core/src/diagram/model.rs` | `DiagramModel`, `DiagramEntity`, `DiagramAttribute`, `DiagramRelationship`, `GovernanceLevel`, `TableInput`, `ColumnInput`, `RenderOptions` |
| `rust/crates/sem_os_core/src/diagram/enrichment.rs` | `build_diagram_model()` — annotates physical schema with registry intelligence |
| `rust/crates/sem_os_core/src/diagram/mermaid.rs` | `MermaidRenderer` — `render_erd`, `render_verb_flow`, `render_domain_map` |
| `rust/crates/sem_os_core/src/diagram/mod.rs` | Module re-exports |
| `rust/crates/sem_os_core/src/lib.rs` | `pub mod affinity; pub mod diagram;` declarations |
| `rust/crates/sem_os_core/src/service.rs` | `get_affinity_graph()` method + `affinity_graph` cache field |
| `rust/crates/sem_os_obpoc_adapter/src/metadata.rs` | `DomainMetadataFile`, `DomainEntry`, `TableMetadata`, `VerbFootprint`, `load_domain_metadata()` |
| `rust/crates/sem_os_obpoc_adapter/src/lib.rs` | `pub mod metadata;` + `build_seed_bundle_with_metadata()` |
| `rust/src/domain_ops/affinity_ops.rs` | 6 `#[register_custom_op]` handlers with typed result structs |
| `rust/src/domain_ops/sem_reg_schema_ops.rs` | 3 diagram CustomOps added (`SchemaGenerateErdOp`, `SchemaGenerateVerbFlowOp`, `SchemaGenerateDiscoveryMapOp`) |
| `rust/src/domain_ops/mod.rs` | `pub mod affinity_ops;` declaration |
| `rust/config/verbs/sem-reg/registry.yaml` | 6 affinity navigation verb definitions (8+ invocation phrases each) |
| `rust/config/verbs/sem-reg/schema.yaml` | 3 diagram verb definitions appended |
| `rust/config/sem_os_seeds/domain_metadata.yaml` | DomainMetadata YAML overlay (verb→table forward mappings) |
| `rust/tests/affinity_integration.rs` | 6 integration tests: live registry, verbs_for_table, data_for_verb, adjacent_verbs, governance_gaps, ERD generation |
| `rust/tests/discovery_ops_integration.rs` | Runtime wiring smoke tests for `registry.discover-dsl` and `schema.generate-discovery-map` |
| `rust/tests/utterance_api_coverage.rs` | API execute-path utterance coverage harness with expected↔predicted verb scoring and report artifacts |

---

## Adding Verbs

> ⚠️ **Before writing verb YAML, read `docs/verb-definition-spec.md`**
> Serde structs are strict. Invalid YAML silently fails to load.

### Verb Behaviors

| Behavior | Execution | Use Case |
|----------|-----------|----------|
| `crud` | Generic executor, single DB operation | Simple CRUD |
| `plugin` | Custom Rust handler | Complex logic |
| `template` | Expands to multi-statement DSL | Workflows, macros |

### Plugin Verb Implementation (CustomOperation)

Plugin verbs require a Rust `CustomOperation` implementation. Use the `#[register_custom_op]` macro for automatic registration via the inventory crate.

```rust
use ob_poc_macros::register_custom_op;

#[register_custom_op]
pub struct MyDomainCreateOp;

#[async_trait]
impl CustomOperation for MyDomainCreateOp {
    fn domain(&self) -> &'static str { "my-domain" }
    fn verb(&self) -> &'static str { "create" }
    fn rationale(&self) -> &'static str { "Complex validation logic" }

    #[cfg(feature = "database")]
    async fn execute(
        &self,
        verb_call: &VerbCall,
        ctx: &mut ExecutionContext,
        pool: &PgPool,
    ) -> Result<ExecutionResult> {
        // Implementation
    }
}
```

**Key points:**
- Macro generates `inventory::submit!` for automatic registration at startup
- Domain/verb must match YAML definition with `behavior: plugin`
- `rationale()` documents why plugin (not CRUD) is needed
- Test coverage: `test_plugin_verb_coverage` verifies all YAML plugin verbs have ops

**Verify coverage:**
```bash
cargo test --lib -- test_plugin_verb_coverage
```

### Quick Example (CRUD)

```yaml
# rust/config/verbs/my_domain.yaml
domains:
  my_domain:
    verbs:
      create:
        description: "Create a record"
        behavior: crud
        crud:
          operation: insert
          table: my_table
          schema: ob-poc
        metadata:
          tier: intent
          source_of_truth: operational
        invocation_phrases:        # Required for LLM discovery
          - "create my thing"
          - "add new record"
        args:
          - name: name
            type: string
            required: true
            maps_to: name
```

### Template Verbs (Macros)

Templates are **first-class verbs** that expand to multi-statement DSL. They enable the LLM to generate complex workflows without training on DSL syntax.

**Key insight:** LLM does INTENT CLASSIFICATION (picks the right template), not DSL generation. Templates emit DSL source that flows through the normal pipeline.

```
User: "Research Aviva group and onboard their Lux funds"
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│  LLM: Intent Classification                                 │
│  verb: "onboarding.research-group"                         │
│  lookups: { root-entity: "Aviva" }                         │
│  params: { jurisdiction: "LU" }                            │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│  Entity Resolution (same as singleton verbs)               │
│  "Aviva" → UUID via EntityGateway                          │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│  Template Expansion → DSL Source                           │
│                                                             │
│  (gleif.import-tree :entity-id "uuid-..." :as @import)     │
│  (bulk.create-cbu :filter "type=FUND AND jur=LU")          │
│  (bulk.add-products :cbu-set @created :products [...])     │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│  Normal DSL Pipeline (unchanged)                           │
│  Parse → Compile → Session → Execute                       │
└─────────────────────────────────────────────────────────────┘
```

**Template Verb Example:**

```yaml
domains:
  onboarding:
    description: "High-level onboarding workflows"
    
    invocation_hints:
      - "onboard"
      - "bulk"
      - "research group"
    
    verbs:
      research-group:
        description: "Import group from GLEIF and bulk onboard funds"
        behavior: template
        
        invocation_phrases:
          - "research a group"
          - "import corporate hierarchy"
          - "bulk onboard funds from GLEIF"
        
        metadata:
          tier: composite
          source_of_truth: external
          scope: global
          noun: group_onboarding
        
        args:
          - name: root-entity
            type: uuid
            required: true
            description: "Group apex entity"
            lookup:
              table: entities
              entity_type: entity
              schema: ob-poc
              search_key: name
              primary_key: entity_id
          
          - name: jurisdiction
            type: string
            required: false
            default: "LU"
            valid_values: [LU, IE, DE, UK, US]
          
          - name: products
            type: list
            required: false
            default: [EQUITY, FIXED_INCOME]
        
        # Template body - expands to DSL source
        template:
          body: |
            (gleif.import-tree :entity-id $root-entity :direction BOTH :as @import)
            (bulk.create-cbu 
              :filter "source=gleif_import AND type=FUND AND jurisdiction=$jurisdiction"
              :as @created_cbus)
            (bulk.add-products 
              :cbu-set @created_cbus 
              :products $products)
```

**Template vs Singleton:**

| Aspect | Singleton Verb | Template Verb |
|--------|---------------|---------------|
| Invocation | `(cbu.assign-role ...)` | `(onboarding.research-group ...)` |
| YAML location | Same (`config/verbs/`) | Same (`config/verbs/`) |
| Intent matching | `invocation_phrases` | `invocation_phrases` (identical) |
| Entity resolution | `lookup:` on args | `lookup:` on args (identical) |
| Execution | Single operation | Expands → multiple statements |

**Why templates are verbs:**
- Single vocabulary for LLM tool (verbs + templates together)
- Same entity resolution via `lookup:` config
- Same linting and governance rules apply
- User can invoke directly: `(onboarding.research-group :root <Aviva>)`

### Verify

```bash
cargo x verbs check   # YAML matches DB
cargo x verbs lint    # Tiering rules
```

### Entity Resolution in DSL

Entity references in DSL use the `<entity_name>` syntax and are resolved via EntityGateway before execution.

**3-Stage Compiler Model:**
```
DSL Source → Parse (Syntax) → Compile (Semantics) → Execute
                                    │
                                    ▼
                         Detect unresolved <entity> refs
                                    │
                                    ▼
                         Resolution Modal (if ambiguous)
                                    │
                                    ▼
                         Substitute UUIDs → Execute
```

**Resolution config comes from verb YAML:**
```yaml
args:
  - name: entity-id
    type: uuid
    lookup:
      table: entities
      entity_type: entity
      schema: ob-poc
      search_key: name                    # Simple key
      # OR composite s-expression:
      # search_key: "(search_name (nationality :selectivity 0.7) (date_of_birth :selectivity 0.95))"
      primary_key: entity_id
```

**Resolution flow (simplified 2-hop):**
1. Agent generates DSL with `<BlackRock>` entity ref
2. Parser produces AST with `EntityRef { value: "BlackRock", resolved_key: None }`
3. `ChatResponse.unresolved_refs` carries refs directly to UI (no sub-session API call)
4. UI opens resolution modal via `pending_unresolved_refs` in `AsyncState`
5. User selects → `resolved_key` populated with UUID
6. Execute with fully resolved AST

> **Note:** Legacy `needs_resolution_check` flag and `start_resolution()` API removed. Resolution state is inline in session, not a sub-session.

### Two Session Models (Intentionally Separate)

| Model | API | Purpose | Scope Storage |
|-------|-----|---------|---------------|
| `AgentSession` | `/api/session/*` | Full agent workflow (chat, DSL, execution) | `context.cbu_ids` |
| `CbuSession` | `/api/cbu-session/*` | Standalone scope navigation (load/undo/redo) | `state.cbu_ids` (HashSet) |

**Primary workflow:** Use DSL verbs (`session.load-galaxy`, etc.) which update `AgentSession.context.cbu_ids` after execution. This is the integrated path that feeds the viewport.

**Standalone REST:** The `/api/cbu-session/*` endpoints are independent and don't sync to `AgentSession`. Use them for direct REST integration without the agent/DSL layer.

> **Warning:** Don't mix the two models. Pick one per client integration.

### Session = Run Sheet = Viewport Scope

The session is the **single source of truth** that ties the REPL, DSL execution, and viewport together.

> **Full design:** `ai-thoughts/035-session-runsheet-viewport-integration.md`, `ai-thoughts/036-session-rip-and-replace.md`

**Unified Session Types (`rust/src/api/session.rs`):**
- `AgentSession` - Single source of truth for agent conversations
- `ServerRunSheet` - DSL statement ledger with per-statement status (replaces legacy `assembled_dsl`, `pending`, `executed_results`)
- `ServerRunSheetEntry` - Individual DSL statement with status, AST, bindings, affected entities

**RunSheet Status (`DslStatus`):**
- `Draft` - Just added, not yet validated
- `Ready` - Validated, ready to execute
- `Executing` - Currently running
- `Executed` - Successfully completed
- `Failed` - Execution error
- `Cancelled` - User cancelled (undo/clear)

**Unified Session Types (`rust/src/session/unified.rs`):**
- `UnifiedSession` - High-level session combining scope + view state
- `TargetUniverse` - Book/Galaxy/Jurisdiction scope
- `EntityScope` - Active CBU set being worked on  
- `StateStack` - Navigation history (back/forward/go-to-start/go-to-last)
- `ViewState` - Viewport rendering state
- `ResolutionState` - Inline resolution (not a sub-session)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         SESSION = UNIVERSE OF WORK                          │
│                                                                             │
│  Session ID: abc-123                                                        │
│  Entity Scope: [CBU-1, CBU-2, CBU-3, ...]  ← Drives viewport               │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Run Sheet (accumulated DSL statements)                              │   │
│  │                                                                       │   │
│  │  ✓ (gleif.import-tree :entity-id "aviva" :as @import)                │   │
│  │  ✓ (bulk.create-cbu :filter "..." :as @cbus) → [CBU-1..50]          │   │
│  │  ⏳ (bulk.add-products :cbu-set @cbus :products [...])               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                              │
│                              ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Viewport shows session.entity_scope                                 │   │
│  │  Updates real-time as DSL executes                                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

**The closed feedback loop:**
- **REPL Panel** shows run sheet with per-statement status
- **Session** tracks entity IDs created/modified by each statement
- **Viewport** subscribes to `session.entity_scope` and shows those CBUs/entities
- **User sees** graph update as DSL executes

**Key fields:**
- `session.entity_scope.cbu_ids` - CBUs being worked on (viewport universe)
- `session.run_sheet.entries[]` - DSL statements with status + affected entities
- `entry.status` - Draft/Ready/Executing/Executed/Failed/Cancelled
- `entry.bindings` - Symbols produced (@cbu, @created_cbus)
- `entry.affected_entities` - Entity UUIDs modified by this statement

**Multi-CBU Viewport Refresh (Scope Graph):**

Session scope is set via `session.load-*` verbs, then DSL execution modifies those CBUs, and the viewport refreshes:

```
1. User sets scope: "Load Allianz Lux book"
    │
    ▼
(session.load-galaxy :apex-entity-id "allianz-se")
    │
    └─► CbuSession.load_many([cbu-1..cbu-50])
            │
            └─► Synced to context.cbu_ids after execution
    │
    ▼
2. User modifies CBUs: "Add custody accounts to all"
    │
    ▼
(bulk.add-custody-account :cbu-set @cbus ...)
    │
    └─► entry.affected_entities = [entity-1..entity-200]
    │
    ▼
3. UI fetches combined graph:
    │
    ▼
GET /api/session/:id/scope-graph
    │
    ▼
MultiCbuGraphResponse {
    graph: CbuGraph,              // Combined graph for all 50 CBUs
    cbu_ids: Vec<Uuid>,           // CBUs in scope
    affected_entity_ids: Vec<Uuid> // 200 entities modified
}
    │
    ▼
Viewport updates with combined graph
```

**Key files:**
- `rust/src/api/graph_routes.rs` - `get_session_scope_graph()` endpoint
- `rust/src/api/agent_routes.rs` - `exec_ctx.take_pending_cbu_session()` sync to `context.cbu_ids`

---

## REPL Session & Phased Execution

> **V1 LEGACY (Superseded):** This section describes the V1 REPL phased execution model.
> The active implementation is the **V2 REPL Architecture** (see below), which replaces
> the state machine, session model, and execution pipeline described here.
> V1 types are retained for reference but are not used in the V2 code path.

> **Full design:** `ai-thoughts/034-repl-session-phased-execution.md`

The agent REPL session is a **state machine** that handles multi-CBU bulk operations:

```
EMPTY → SCOPED → TEMPLATED → GENERATED → PARSED → READY → EXECUTED
         │                                  │        │
         │ scope_dsl                        │        │ user confirms "Run?"
         │ + derived CBU set                │        │
         └──────────────────────────────────┘        │
                                             resolve loop (picker)
```

**Key concepts:**

| Concept | Description |
|---------|-------------|
| **Scope derivation** | "Allianz Lux book" → queries GROUP structure → derives CBU set |
| **Template × CBU set** | Single verb template expanded for each CBU in scope |
| **DAG phases** | Statements grouped by dependency depth (0 = creators, 1 = needs phase 0, etc.) |
| **Two tollgates** | Pre-compile (reorder) and pre-run (phase extraction) using same DAG |
| **Phased execution** | Execute phase 0, collect PKs, substitute into phase 1, repeat |

**Entity type hierarchy** (verb target determines attachment point):

```
Universe → Book → CBU → TradingProfile → Product
                     → Entity (roles)
                     → ISDA → Counterparty
                     → KycCase
```

**Session record stores:**
- `scope_dsl` - DSL that derived the scope
- `template_dsl` - Unpopulated verb template  
- `sheet.statements[]` - Populated DSL with `dag_depth` per statement
- `returned_pk` - PKs collected after each phase executes

**Failure handling:**
- Single transaction wrapping all phases
- Failure → rollback → no partial state
- Downstream statements marked SKIPPED (blocked by failed dependency)
- POC recovery: trash session, start fresh (idempotent verbs are safe)

**`@session_cbus` iteration:**
Template batch operations can use `@session_cbus` as source to iterate over all CBUs in session scope:
```clojure
(template.batch :id "add-custody" :source @session_cbus :bind-as "cbu_id" ...)
```

---

## REPL Pipeline Redesign (077)

> **V1 LEGACY (Superseded):** The original 077 redesign introduced an explicit state machine
> and command ledger. This has been **superseded by the V2 REPL Architecture** which implements
> a 7-state machine with pack-scoped intent resolution, ContextStack fold, and preconditions engine.

**V1 to V2 Migration:**

| V1 Concept | V2 Replacement |
|------------|----------------|
| `ReplState` (5 states) | `ReplStateV2` in `orchestrator_v2.rs` (7 states) |
| `LedgerEntry` | Runbook entries in `session_v2.rs` |
| `UserInput` enum | `UserInputV2` in `types_v2.rs` |
| `ClarifyingState` | Integrated into orchestrator state machine |
| `ReplSession` with ledger | `ReplSessionV2` with runbook fold |
| `ReplOrchestrator` | `ReplOrchestratorV2` with pack-scoped scoring |
| `/api/repl/session/:id/input` | `/api/session/:id/input` (`kind=repl_v2`, unified ingress) |
| `HybridIntentMatcher` | `IntentService` + `search_with_context()` |

See **V2 REPL Architecture** section below for the active implementation.

---

## V2 REPL Architecture — Pack-Scoped Intent Resolution

> **Status:** ✅ Complete (2026-02-13) — Feature flag `vnext-repl` (enabled in web server)
> **Intent Wiring:** ✅ Complete — `VerbSearchIntentMatcher` bridges `HybridVerbSearcher` (10-tier) to V2 `IntentMatcher` trait
> **Tests:** 320 unit tests + 5 golden corpus tests
> **Invariants:** P-1 through P-5, E-1 through E-8 — see `docs/INVARIANT-VERIFICATION.md`

**Problem Solved:** V1 REPL had no concept of "what the user is trying to accomplish" — every turn was an independent verb search. V2 introduces **packs** (journey templates) that scope intent resolution, a **ContextStack** (pure fold from runbook), and a **preconditions engine** that filters verbs by eligibility.

**Critical wiring (2026-02-13):** The V2 REPL's `IntentMatcher` trait was disconnected from the production `HybridVerbSearcher` — all free-text utterances fell through to a stub matcher. `VerbSearchIntentMatcher` now bridges the 10-tier `HybridVerbSearcher` to the V2 `IntentMatcher` trait, and `IntentService` + `VerbConfigIndex` are fully wired in `main.rs`.

### 7-State Machine

```
┌────────────┐
│  ScopeGate │ ◄── No client group in scope
└─────┬──────┘
      │ scope established
      ▼
┌────────────────┐
│ JourneySelect  │ ◄── Multiple packs match
└─────┬──────────┘
      │ pack selected (or auto-selected)
      ▼
┌────────────┐     ┌────────────┐
│   InPack   │ ──► │ Clarifying │ ──► (back to InPack after resolution)
└─────┬──────┘     └────────────┘
      │ all steps proposed
      ▼
┌────────────┐     ┌────────────┐
│  Proposing │ ──► │RunbookEdit │ ──► (user edits steps)
└─────┬──────┘     └────────────┘
      │ user confirms
      ▼
┌────────────┐
│ Executing  │ ──► Completed / Parked (human gate)
└────────────┘
```

**States:** `ScopeGate`, `JourneySelection`, `InPack`, `Clarifying`, `SentencePlayback`, `RunbookEditing`, `Executing`

### ContextStack (7-Layer Fold from Runbook)

The ContextStack is a **pure fold** over executed runbook entries — never mutated directly. Only constructor: `ContextStack::from_runbook()`.

| Layer | Type | Purpose |
|-------|------|---------|
| `derived_scope` | `DerivedScope` | Session scope from executed entries (CBU IDs, client group) |
| `pack_context` | `PackContext` | Active pack (staged preferred over executed) |
| `template_hint` | `TemplateStepHint` | Next expected verb from pack template |
| `focus` | `FocusContext` | Pronoun resolution ("it", "that entity") |
| `recent` | `RecentContext` | Recent entity mentions for carry-forward |
| `exclusion_set` | `ExclusionSet` | Rejected candidates with 3-turn decay |
| `outcome_registry` | `OutcomeRegistry` | Execution results for `@N` outcome references |

Additional derived fields: `executed_verbs`, `staged_verbs`, `accumulated_answers` (Q&A from pack questions).

**Key Invariant (P-3):** Session state is a runbook fold. No mutable `client_context` or `journey_context` — these are deprecated write-only persistence bridges.

### Pack System

Packs are YAML journey templates that scope intent resolution to a workflow:

| Pack | File | Purpose |
|------|------|---------|
| `session-bootstrap` | `config/packs/session-bootstrap.yaml` | Initial scope setup |
| `book-setup` | `config/packs/book-setup.yaml` | Client book creation |
| `onboarding-request` | `config/packs/onboarding-request.yaml` | Full client onboarding |
| `kyc-case` | `config/packs/kyc-case.yaml` | KYC case management |

**PackManifest** defines: `id`, `name`, `description`, `entry_conditions`, `questions` (with `options_source`), `template` (ordered steps), `risk_policy`, `handoff_target`.

**PackRouter** selects pack: force-select > substring match > semantic match. Conversation-first design — question `options_source` values are suggestions, not gate constraints.

### 3-Pronged Utterance → Intent Pipeline

Every user utterance flows through **three sequential stages** that progressively narrow the candidate set. Each stage votes on candidates via scoring; the final result is a single `VerbDecision`.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  User utterance: "assign depositary to the fund"                            │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  PRONG 1: RAW SEMANTIC SEARCH (VerbSearchIntentMatcher)             │    │
│  │                                                                     │    │
│  │  HybridVerbSearcher.search() — tiered priority:                    │    │
│  │    T-2A: ScenarioIndex (journey-level compound)     0.97      │    │
│  │    T-2B: MacroIndex (macro search parity)            0.96      │    │
│  │    T-1: ECIR noun taxonomy (deterministic noun→verb)     0.95      │    │
│  │         1 candidate → short-circuit, 2+ → post-boost (+0.05)      │    │
│  │    T0: Operator macros (exact/fuzzy label match)         score 1.0  │    │
│  │    T1: User learned exact                                score 1.0  │    │
│  │    T2: Global learned exact                              score 1.0  │    │
│  │    T3: User semantic (pgvector, BGE asymmetric)          0.5-0.95  │    │
│  │    T5: Blocklist filter                                            │    │
│  │    T6: Global semantic (cold-start + learned patterns)   0.5-0.95  │    │
│  │    T7: Phonetic fallback (typo handling)                 0.80      │    │
│  │                                                                     │    │
│  │  Output: Vec<VerbCandidate> with raw scores                        │    │
│  │  Example: [cbu-role.assign@0.82, party.assign@0.78, cbu.create@0.61] │  │
│  └─────────────────────────────────────────────────────────────────────┘    │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  PRONG 2: PACK SCORING (apply_pack_scoring)                         │    │
│  │                                                                     │    │
│  │  Context-aware score adjustments based on active pack + focus:      │    │
│  │    • In-pack verb boost:     +0.10  (verb listed in pack template) │    │
│  │    • Out-of-pack penalty:    -0.05  (verb not in pack)             │    │
│  │    • Template step boost:    +0.15  (matches NEXT expected step)   │    │
│  │    • Domain affinity boost:  +0.03  (domain matches FocusMode)    │    │
│  │    • Absolute floor:          0.55  (below = discard)             │    │
│  │                                                                     │    │
│  │  Re-sorted by adjusted score, floor-filtered                       │    │
│  │  Example: [cbu-role.assign@0.92, party.assign@0.73]                │    │
│  │           (cbu.create dropped below floor after penalty)           │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  PRONG 3: PRECONDITION FILTERING (filter_by_preconditions)          │    │
│  │                                                                     │    │
│  │  DAG-aware eligibility check against ContextStack:                  │    │
│  │    • requires_scope:cbu     — CBU must be in scope                 │    │
│  │    • requires_prior:X       — verb X must have been executed       │    │
│  │    • forbids_prior:X        — verb X must NOT have been executed   │    │
│  │                                                                     │    │
│  │  Ineligible verbs removed; "why not" suggestions generated:         │    │
│  │    "party.assign requires entity.create first — try that first"    │    │
│  │                                                                     │    │
│  │  Re-evaluate ambiguity on surviving candidates                     │    │
│  │  Example: [cbu-role.assign@0.92]  ← clear winner                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  AMBIGUITY POLICY (apply_ambiguity_policy)                          │    │
│  │                                                                     │    │
│  │  Four outcomes based on top candidate(s):                           │    │
│  │    Confident:   score ≥ 0.70  AND  margin ≥ 0.05  → execute       │    │
│  │    Proposed:    score ≥ 0.55  AND  margin ≥ 0.05  → confirm first │    │
│  │    Ambiguous:   margin < 0.05 between top two     → ask user      │    │
│  │    NoMatch:     score < 0.55 or no candidates     → re-prompt     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│         │                                                                    │
│         ▼                                                                    │
│  VerbDecision: Clear | Ambiguous | NeedsContext | NoMatch                   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### VerbSearchIntentMatcher (Bridge Layer)

The V2 REPL defines an `IntentMatcher` trait for pluggable verb matching. `VerbSearchIntentMatcher` bridges the production `HybridVerbSearcher` (V1's 10-tier search) to this trait.

```rust
// rust/src/mcp/verb_search_intent_matcher.rs
pub struct VerbSearchIntentMatcher {
    searcher: Arc<HybridVerbSearcher>,
}

impl IntentMatcher for VerbSearchIntentMatcher {
    async fn match_intent(&self, utterance: &str, context: &MatchContext)
        -> Result<IntentMatchResult>
    {
        // 1. Call HybridVerbSearcher.search() with user_id + domain_hint from context
        // 2. Map VerbSearchResult → VerbCandidate (score, verb_fqn, description)
        // 3. Derive MatchOutcome from candidate scores:
        //    - No candidates → NoMatch
        //    - Top score ≥ 0.55 with margin ≥ 0.05 → ClearWinner
        //    - Multiple close scores → Ambiguous { top, runner_up, margin }
        //    - Top score < 0.55 → NoMatch
    }
}
```

**Outcome derivation constants:**

| Constant | Value | Purpose |
|----------|-------|---------|
| `THRESHOLD` | 0.55 | Minimum score to consider a candidate viable |
| `MARGIN` | 0.05 | Minimum gap between top two for clear winner |
| `STRONG_THRESHOLD` | 0.70 | Score above which match is auto-confident |

### Server Wiring (main.rs)

The intent pipeline is assembled in `ob-poc-web/src/main.rs` during V2 REPL initialization:

```
VerbsConfig (YAML)
    │
    ├─► VerbConfigIndex (in-memory verb metadata)
    │
    ├─► CandleEmbedder (BGE-small-en-v1.5, 384-dim)
    │       │
    │       └─► HybridVerbSearcher (10-tier priority search)
    │               │
    │               └─► VerbSearchIntentMatcher (IntentMatcher trait impl)
    │                       │
    │                       └─► IntentService (5-phase pipeline)
    │
    └─► ReplOrchestratorV2
            .with_verb_config_index(verb_config_index)
            .with_intent_matcher(intent_matcher)
            .with_intent_service(intent_service)
```

If the `CandleEmbedder` fails to initialize (missing model files), the system logs a warning and falls back to stub matching. All components degrade gracefully.

### Scoring Constants

| Constant | Value | Purpose |
|----------|-------|---------|
| `PACK_VERB_BOOST` | 0.10 | Verbs listed in active pack template |
| `PACK_VERB_PENALTY` | 0.05 | Verbs outside active pack |
| `TEMPLATE_STEP_BOOST` | 0.15 | Matching next expected template step |
| `DOMAIN_AFFINITY_BOOST` | 0.03 | Domain matching from FocusMode |
| `ABSOLUTE_FLOOR` | 0.55 | Minimum score cutoff |
| `AMBIGUITY_MARGIN` | 0.05 | Gap required between top candidates |
| `STRONG_THRESHOLD` | 0.70 | Score above which match is auto-confident |

### Preconditions Engine

Parsed from YAML verb `lifecycle` field. Formats: `requires_scope:cbu`, `requires_prior:cbu.create`, `forbids_prior:cbu.delete`.

**EligibilityMode:**
- `Executable` — verb can execute now (strict: all preconditions met)
- `Plan` — verb can be planned for future execution (relaxed: scope only)

`filter_by_preconditions()` removes ineligible verbs from candidates and generates **"why not" suggestions** explaining what's missing (e.g., "cbu.assign-role requires a CBU in scope — try cbu.create first").

### FocusMode

5 variants derived from active pack + recent verbs:

| Variant | Trigger | Domain Affinity |
|---------|---------|-----------------|
| `KycCase` | kyc-case pack active | kyc.*, screening.* |
| `Proofs` | Document collection phase | document.*, requirement.* |
| `Trading` | Trading profile setup | trading-profile.*, custody.* |
| `CbuManagement` | Book setup pack | cbu.*, session.* |
| `General` | No pack or mixed activity | No boost |

Provides a soft domain affinity boost (`DOMAIN_AFFINITY_BOOST = 0.03`), not a hard filter.

### DecisionLog (Per-Turn Audit)

Every turn produces a `DecisionLog` entry with:
- Raw verb candidates (pre-scoring) with scores
- Reranked candidates (post-scoring) with pack adjustments
- `VerbDecision` (Clear/Ambiguous/NeedsContext/NoMatch)
- Entity resolutions with method (deterministic vs LLM)
- Arg extraction method
- Context summary (pack, scope, focus mode)
- Final DSL proposed
- Privacy: `raw_input` redacted in operational mode (only `input_hash` kept)

### Replay Tuner

CLI tool for iterating on scoring constants against the golden corpus:

```bash
# Run corpus against current constants
cargo x replay-tuner run

# Sweep parameter space
cargo x replay-tuner sweep

# Compare two parameter sets
cargo x replay-tuner compare --baseline defaults --candidate experimental

# Generate report
cargo x replay-tuner report
```

**Key file:** `rust/xtask/src/replay_tuner.rs`

### Golden Corpus

102 test entries across 8 YAML files in `rust/tests/golden_corpus/`:

| File | Entries | Coverage |
|------|---------|----------|
| `seed.yaml` | 26 | Core verb matching |
| `kyc.yaml` | 16 | KYC workflow |
| `preconditions.yaml` | 15 | Precondition gates |
| `edge_cases.yaml` | 13 | Edge cases |
| `book_setup.yaml` | 11 | Book setup pack |
| `bootstrap.yaml` | 7 | Bootstrap pack |
| `pack_switching.yaml` | 7 | Pack transitions |
| `error_recovery.yaml` | 7 | Error handling |

CI gate: `test_corpus_total_at_least_50` ensures corpus doesn't regress.

### Invariant Verification

13 invariants documented in `docs/INVARIANT-VERIFICATION.md`:

**Pipeline (P-1 through P-5):**
- P-1: ContextStack is a pure fold (no mutation)
- P-2: Pack scoring is additive (never replaces base score)
- P-3: Session state is runbook fold (no mutable context)
- P-4: Preconditions never add candidates
- P-5: ExclusionSet decays after 3 turns

**Engine (E-1 through E-8):**
- E-1: dual_decode handles cross-pack disambiguation
- E-2: recover_from_rejection filters and re-scores
- E-3: check_pack_handoff detects completion
- E-4 through E-8: Template expansion, entity resolution, sentence generation, etc.

### API Endpoints

| Endpoint | Purpose |
|----------|---------|
| `POST /api/repl/v2/session` | Create V2 REPL session |
| `GET /api/repl/v2/session/:id` | Get full session state |
| `POST /api/session/:id/input` | Unified input ingress; use `kind=repl_v2` for all `UserInputV2` payloads |
| `DELETE /api/repl/v2/session/:id` | Delete session |
| `POST /api/repl/v2/signal` | External system completion signals |

**UserInputV2 types:** `Message`, `Confirm`, `Reject`, `Edit`, `Command`, `SelectPack`, `SelectVerb`, `SelectEntity`

**ReplResponseKindV2 types:** `ScopeRequired`, `JourneyOptions`, `Question`, `SentencePlayback`, `RunbookSummary`, `Clarification`, `Executed`, `Parked`, `StepProposals`, `Info`, `Prompt`, `Error`

### Key Files (33 files)

| File | Purpose |
|------|---------|
| **State Machine & Session** | |
| `rust/src/repl/orchestrator_v2.rs` | 7-state machine dispatcher (174K) |
| `rust/src/repl/session_v2.rs` | `ReplSessionV2` with runbook (19K) |
| `rust/src/repl/types_v2.rs` | `ReplStateV2`, `UserInputV2` types (11K) |
| `rust/src/repl/response_v2.rs` | `ReplResponseV2` types (9K) |
| **Intent & Scoring** | |
| `rust/src/mcp/verb_search_intent_matcher.rs` | Bridge: `HybridVerbSearcher` → `IntentMatcher` trait |
| `rust/src/repl/intent_service.rs` | 5-phase verb matching pipeline (26K) |
| `rust/src/repl/intent_matcher.rs` | `IntentMatcher` trait + `search_with_context()` default |
| `rust/src/repl/scoring.rs` | Pack scoring + ambiguity policy (29K) |
| `rust/src/repl/preconditions.rs` | Precondition engine + "why not" (18K) |
| `rust/src/repl/decision_log.rs` | Per-turn audit trail (32K) |
| `rust/src/repl/verb_config_index.rs` | In-memory verb metadata (26K) |
| `rust/src/mcp/verb_search_factory.rs` | Factory for consistent `HybridVerbSearcher` creation |
| **Context & Runbook** | |
| `rust/src/repl/context_stack.rs` | 7-layer ContextStack fold (81K) |
| `rust/src/repl/runbook.rs` | Runbook entries + execution (66K) |
| `rust/src/repl/bootstrap.rs` | ScopeGate bootstrap logic (15K) |
| **Proposal & Execution** | |
| `rust/src/repl/proposal_engine.rs` | Deterministic step proposals (29K) |
| `rust/src/repl/sentence_gen.rs` | Deterministic sentence templating (17K) |
| `rust/src/repl/deterministic_extraction.rs` | Pattern-based arg extraction (30K) |
| `rust/src/repl/executor_bridge.rs` | Bridge to DSL executor (5K) |
| `rust/src/repl/entity_resolution.rs` | Entity resolution pipeline (17K) |
| **Journey / Packs** | |
| `rust/src/journey/pack.rs` | `PackManifest`, `PackTemplate` (19K) |
| `rust/src/journey/router.rs` | `PackRouter` — pack selection (19K) |
| `rust/src/journey/template.rs` | Template expansion + provenance (23K) |
| `rust/src/journey/playback.rs` | Pack summary + chapter gen (10K) |
| `rust/src/journey/handoff.rs` | Context forwarding between packs (2K) |
| **API & Infrastructure** | |
| `rust/src/api/repl_routes_v2.rs` | V2 HTTP endpoints |
| `rust/src/repl/events.rs` | Event system (15K) |
| `rust/src/repl/service.rs` | Service layer (32K) |
| `rust/src/repl/session_repository.rs` | DB persistence (9K) |
| **Config** | |
| `rust/config/packs/session-bootstrap.yaml` | Bootstrap pack |
| `rust/config/packs/book-setup.yaml` | Book setup pack |
| `rust/config/packs/onboarding-request.yaml` | Onboarding pack |
| `rust/config/packs/kyc-case.yaml` | KYC case pack |
| **Test** | |
| `rust/tests/golden_corpus/*.yaml` | 102 test entries (8 files) |
| `rust/tests/golden_corpus_test.rs` | Corpus runner + CI gate |
| `rust/xtask/src/replay_tuner.rs` | Replay tuner CLI |

---

## BPMN-Lite Durable Orchestration Service

> ✅ **IMPLEMENTED (2026-02-10)**: Standalone Rust service for durable workflow orchestration. BPMN XML → Verified IR → Bytecode → Fiber VM. 123 core tests + 6 integration tests + gRPC smoke test. Includes race semantics (Phase 2), non-interrupting boundary events + timer cycles (Phase 2A), cancel/ghost signal protection (Phase 3), terminate end events + error boundary routing + bounded loops (Phase 5), inclusive (OR) gateways (Phase 5A), and authoring pipeline with verb contracts, BPMN XML export, and template publish lifecycle (Phases B-D).

**Problem Solved:** ob-poc has a DSL + verb runtime for deterministic, short-running work and a runbook/REPL model for auditable execution. It lacks **durable orchestration** — the ability to park a workflow for days/weeks (waiting for documents, human approvals, timers) and resume deterministically. BPMN-Lite fills this gap as a standalone gRPC service.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    BPMN-LITE SERVICE                                          │
│                                                                              │
│  BPMN XML (.bpmn)                                                           │
│         │                                                                    │
│         ▼                                                                    │
│  Parser (quick-xml) → IRGraph (petgraph)                                    │
│         │                                                                    │
│         ▼                                                                    │
│  Verifier (structural checks: single start, reachable, paired gateways)     │
│         │                                                                    │
│         ▼                                                                    │
│  Lowering → Bytecode (Vec<Instr>, 23-opcode ISA)                           │
│         │                                                                    │
│         ▼                                                                    │
│  Fiber VM (tick-based executor)                                             │
│         │   - ExecNative parks fiber + enqueues job                         │
│         │   - CompleteJob resumes fiber with payload                        │
│         │   - Fork/Join for parallel paths                                  │
│         │   - WaitFor/WaitUntil/WaitMsg for timers/messages                │
│         │   - Race semantics (Msg vs Timer arms, boundary events)          │
│         │   - Non-interrupting fire (spawns child fiber, main stays)       │
│         │   - Timer cycles (R<n>/PT<dur>, exhaustion revert)               │
│         │   - Cancel/ghost signal protection (3 guards)                    │
│         │   - Terminate end events (kill all sibling fibers)               │
│         │   - Error boundary routing (BusinessRejection → catch path)      │
│         │   - Bounded retry loops (IncCounter/BrCounterLt)                 │
│         │   - Inclusive (OR) gateway (ForkInclusive/JoinDynamic)            │
│         │                                                                    │
│         ▼                                                                    │
│  BpmnLiteEngine (facade wrapping compiler + VM + store)                     │
│         │                                                                    │
│         ▼                                                                    │
│  gRPC Server (tonic 0.12) — 9 RPCs                                         │
│         │                                                                    │
│         ▼                                                                    │
│  ob-poc connects as job worker via gRPC (Phase B — complete)               │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Key Design Constraints

- **Standalone workspace** — `bpmn-lite/` at repo root, NOT inside `rust/` or as an ob-poc crate
- **gRPC is the only boundary** — no shared crates beyond protobuf-generated types
- **Hollow orchestration** — BPMN-Lite orchestrates control flow; all domain work happens in ob-poc verb handlers via the job worker protocol
- **Two-namespace payload** — `domain_payload` (opaque canonical JSON + SHA-256 hash) never parsed by VM; `orch_flags` (flat primitives) for branching only
- **Dual store** — `MemoryStore` (default, no deps) or `PostgresProcessStore` (feature-gated `postgres`, `--database-url` CLI arg / `DATABASE_URL` env var)

### 23-Opcode ISA

| Group | Instructions | Behavior |
|-------|-------------|----------|
| Control flow | `Jump`, `BrIf`, `BrIfNot` | Manipulate pc; BrIf/BrIfNot pop stack |
| Stack ops | `PushBool`, `PushI64`, `Pop` | Push/pop on fiber.stack |
| Flags | `LoadFlag`, `StoreFlag` | Read/write instance.flags; StoreFlag emits FlagSet event |
| Work | `ExecNative` | Park fiber + enqueue job (key v0.9 change) |
| Concurrency | `Fork`, `Join` | Fork spawns child fibers; Join increments barrier + parks |
| Waits | `WaitFor`, `WaitUntil`, `WaitMsg` | Park fiber in appropriate WaitState |
| Race | `WaitAny`, `CancelWait` | WaitAny races N arms (timer/msg/internal); CancelWait cleans up losers |
| Bounded loops | `IncCounter`, `BrCounterLt` | IncCounter increments loop counter; BrCounterLt branches if counter < limit |
| Inclusive gateway | `ForkInclusive`, `JoinDynamic` | ForkInclusive evaluates condition_flags, spawns fibers for truthy branches; JoinDynamic waits for dynamic count |
| Lifecycle | `End`, `EndTerminate`, `Fail` | End removes fiber; EndTerminate kills all sibling fibers + ends process; Fail creates incident |

### ExecNative (Job Worker Protocol)

1. Derive deterministic `job_key` from `(instance_id, service_task_id, pc)`
2. Check dedupe cache → if hit, apply cached completion, advance pc
3. If miss: emit `JobActivated` event, enqueue `JobActivation`, park fiber in `WaitState::Job`
4. Fiber does NOT advance pc — resumes when `CompleteJob` arrives
5. `CompleteJob` validates `domain_payload_hash`, merges `orch_flags`, advances pc

### gRPC API (9 RPCs)

| RPC | Purpose |
|-----|---------|
| `Compile` | BPMN XML → verified bytecode, returns `bytecode_version` hash |
| `StartProcess` | Create process instance from compiled program |
| `Signal` | Send named message to waiting process (correlation) |
| `Cancel` | Cancel all fibers, mark process Cancelled |
| `Inspect` | Snapshot of process state (fibers, waits, flags) |
| `ActivateJobs` | Server-streaming: dequeue jobs for worker (long-poll with timeout) |
| `CompleteJob` | Worker returns result (payload + hash + flags) |
| `FailJob` | Worker reports failure (creates incident) |
| `SubscribeEvents` | Server-streaming: tailing event log (polls until terminal event) |

### Workspace Structure

```
bpmn-lite/                          # Standalone workspace (repo root sibling to rust/)
├── Cargo.toml                      # Workspace manifest
├── rust-toolchain.toml             # Pinned to 1.91 (matches ob-poc)
├── Dockerfile                      # Multi-stage (rust:1.84-bookworm → debian:bookworm-slim)
├── .dockerignore
├── .gitignore
├── bpmn-lite-core/
│   ├── Cargo.toml
│   ├── migrations/                 # 12 SQL files (001-012), run by sqlx::migrate!()
│   ├── src/
│   │   ├── lib.rs                  # Module exports
│   │   ├── types.rs                # Value, Instr, Fiber, ProcessInstance, Job*, CompiledProgram
│   │   ├── events.rs               # RuntimeEvent enum (28 variants)
│   │   ├── store.rs                # ProcessStore trait (29 async methods)
│   │   ├── store_memory.rs         # MemoryStore (RwLock<HashMap> implementation)
│   │   ├── store_postgres.rs       # PostgresProcessStore (#[cfg(feature = "postgres")])
│   │   ├── vm.rs                   # tick_fiber() executor + CompleteJob/FailJob handlers
│   │   ├── engine.rs               # BpmnLiteEngine facade
│   │   └── compiler/
│   │       ├── mod.rs
│   │       ├── ir.rs               # IRGraph, IRNode, IREdge (petgraph)
│   │       ├── verifier.rs         # Structural verification (7 checks)
│   │       ├── lowering.rs         # IR → bytecode with debug_map
│   │       └── parser.rs           # BPMN XML → IR (quick-xml)
│   └── tests/
│       └── fixtures/
│           └── kyc-open-case.bpmn  # Test fixture: KYC workflow
├── bpmn-lite-server/
│   ├── Cargo.toml
│   ├── build.rs                    # tonic-build for proto compilation
│   ├── proto/
│   │   └── bpmn_lite/v1/
│   │       └── bpmn_lite.proto     # Full proto definition (9 RPCs)
│   ├── src/
│   │   ├── lib.rs                  # Re-exports grpc::proto for integration tests
│   │   ├── main.rs                 # gRPC server startup, conditional store (--database-url)
│   │   └── grpc.rs                 # Handler implementations delegating to Engine
│   └── tests/
│       └── integration.rs          # 6 integration tests + 1 gRPC smoke test (#[ignore])
```

### Core Types

| Type | Description |
|------|-------------|
| `Value` | Stack value: `Bool(bool)`, `I64(i64)`, `Str(u32)`, `Ref(u32)` |
| `Instr` | 23-opcode enum |
| `Fiber` | fiber_id, pc, stack, regs[8], wait state |
| `ProcessInstance` | instance_id, bytecode, domain_payload, hash, flags, state |
| `WaitState` | Running, Timer, Msg, Job{job_key}, Join, Race{race_id, timer, cycle}, Incident |
| `CycleSpec` | Timer cycle config: `interval_ms`, `max_fires` |
| `WaitArm` | Race arm: `Timer{deadline, resume_at, interrupting, cycle}` or `Msg{name, corr_key, resume_at}` |
| `RacePlanEntry` | Race plan arm with `boundary_element_id` for BPMN element tracing |
| `InclusiveBranch` | OR-gateway branch: `condition_flag` (Option<FlagKey>) + `target` (Addr) |
| `CompiledProgram` | bytecode_version (SHA-256), program, debug_map, join_plan, wait_plan, race_plan |
| `RuntimeEvent` | 28 variants: InstanceStarted, FiberSpawned, JobActivated, JobCompleted, RaceRegistered, RaceWon, BoundaryFired, TimerCycleIteration, TimerCycleExhausted, WaitCancelled, SignalIgnored, Terminated, ErrorRouted, CounterIncremented, InclusiveForkTaken, etc. |
| `ProcessStore` | Trait with 29 async methods (instances, fibers, joins, dedupe, jobs, programs, events, cancel) |

### Engine: `tick_instance` vs `run_instance`

The `BpmnLiteEngine` has two methods for advancing fibers:

| Method | Dequeues Jobs? | Used By |
|--------|---------------|---------|
| `tick_instance()` | No — leaves jobs in queue | gRPC handlers (`start_process`, `complete_job`, `signal`) |
| `run_instance()` | Yes — calls `tick_instance()` then dequeues | In-process tests and convenience callers |

gRPC handlers use `tick_instance` so that jobs remain in the store queue for the `ActivateJobs` RPC to deliver to external workers. The `complete_job` gRPC handler also calls `tick_instance` after resuming the fiber, so it can advance to the next instruction (End, or another ExecNative).

### Running the Service

```bash
# Native (via xtask, from rust/ directory)
cargo x bpmn-lite start            # Release build + start background (port 50051)
cargo x bpmn-lite start -p 50055   # Custom port
cargo x bpmn-lite status           # Show native + Docker status
cargo x bpmn-lite stop             # Stop native server

# Build and run directly (foreground, MemoryStore)
cd bpmn-lite && cargo run -p bpmn-lite-server
# Server starts on [::]:50051

# Build and run with PostgresProcessStore (migrations auto-applied)
cd bpmn-lite && cargo run -p bpmn-lite-server --features postgres -- --database-url postgresql:///data_designer

# Build/test only
cargo x bpmn-lite build            # Debug build
cargo x bpmn-lite build --release  # Release build
cargo x bpmn-lite test             # Run all 71 tests (+ 1 ignored gRPC smoke)
cargo x bpmn-lite clippy           # Lint

# Postgres integration tests (15 tests, require running Postgres)
cd bpmn-lite && DATABASE_URL="postgresql:///data_designer" \
  cargo test --features postgres -p bpmn-lite-core -- --ignored

# Docker
cargo x bpmn-lite docker-build     # Build image
cargo x bpmn-lite deploy           # Docker build + compose up (port 50053)

# Docker directly
docker build -t bpmn-lite ./bpmn-lite
docker run -p 50051:50051 bpmn-lite

# Docker Compose (port 50053 on host → 50051 in container)
docker compose up bpmn-lite
```

### Test Coverage (71 core + 6 integration + 15 postgres + 1 ignored smoke test)

| Phase | Tests | Coverage |
|-------|-------|----------|
| A2: MemoryStore | 7 | Instance/fiber/join/dedupe/job queue/event log/payload history |
| A3: VM (core) | 7 | Linear flow, flag round-trip, dedupe, hash validation, events, FlagSet |
| A3: VM (race) | 4 | Race msg wins, timer wins, replay after race, duplicate signal noop |
| A3: VM (boundary) | 3 | Job completes before timer, timer fires before job, verifier rejects invalid |
| A4: Compiler | 7 | IR lowering, XOR/parallel gateways, verifier rejects, end-to-end |
| A5: Parser | 6 | Minimal BPMN, task_type extraction, unsupported elements, full pipeline, boundary timer parse+lower, ISO cycle parse |
| A5: Full pipeline | 2 | kyc-open-case.bpmn end-to-end, fixture parsing |
| A6: Engine | 1 | Engine full lifecycle |
| Phase 2A: Non-interrupting | 5 | Spawns child fiber, cycle fires multiple, cycle exhaustion revert, job completes before timer, verifier rejects cycle+interrupting |
| Phase 3: Cancel | 5 | Complete-after-cancel, signal-after-complete, signal-no-match, duplicate-complete, job-purge-on-cancel |
| Phase 5.1: Terminate | 4 | EndTerminate kills siblings, terminate after parallel fork, terminate in sequential flow, Terminated event emitted |
| Phase 5.2: Error routing | 5 | BusinessRejection routes to error boundary, unmatched error creates incident, error routing with orch_flags, error after parallel fork, nested error boundaries |
| Phase 5.3: Bounded loops | 5 | Counter increment + branch, loop exits at limit, counter reset across epochs, loop with service task, counter events emitted |
| Phase 5A: Inclusive gateway | 6 | All branches taken, subset branches (condition_flag), single branch, default-only, dynamic join count, InclusiveForkTaken event |
| Integration | 6 | Full lifecycle, two-task, cancel, fail, compile error, hash integrity |
| Phase 4: PostgresProcessStore | 15 (`#[ignore]`) | Instance/fiber/join/dedupe/job/event/payload/program/dead-letter/incident round-trips, instance updates, teardown, concurrent dequeue, engine smoke, cancel_jobs_for_instance |
| gRPC smoke | 1 (`#[ignore]`) | Over-the-wire: Compile → Start → Inspect → ActivateJobs → CompleteJob → Inspect(COMPLETED) → SubscribeEvents |

The gRPC smoke test requires a running server. Run with:
```bash
# Against native server (port 50051)
cargo x bpmn-lite start
cd bpmn-lite && BPMN_LITE_URL=http://127.0.0.1:50051 cargo test --test integration test_grpc_smoke -- --ignored

# Against Docker container (port 50053)
cargo x bpmn-lite deploy
cd bpmn-lite && BPMN_LITE_URL=http://127.0.0.1:50053 cargo test --test integration test_grpc_smoke -- --ignored
```

### Dependencies

| Crate | Version | Purpose |
|-------|---------|---------|
| `tonic` | 0.12 | gRPC server |
| `prost` | 0.13 | Protobuf codegen |
| `petgraph` | 0.6 | IR graph representation |
| `quick-xml` | 0.36 | BPMN XML parser |
| `tokio` | 1 | Async runtime |
| `uuid` | 1 (v7) | Instance/fiber IDs |
| `sha2` | 0.10 | Payload hash, bytecode version |
| `serde`/`serde_json` | 1 | Serialization |
| `tracing` | 0.1 | Structured logging |
| `sqlx` | 0.8 | PostgreSQL async driver (optional, `postgres` feature) |
| `chrono` | 0.4 | Timestamp conversion (optional, `postgres` feature) |

### Docker Compose

```yaml
# In docker-compose.yml at repo root
bpmn-lite:
  build:
    context: ./bpmn-lite
    dockerfile: Dockerfile    # Builds with --features postgres
  container_name: bpmn-lite
  ports:
    - "50053:50051"  # gRPC (50051 inside container, 50053 on host)
  environment:
    RUST_LOG: info
    DATABASE_URL: postgresql://localhost@host.docker.internal:5432/data_designer
  extra_hosts:
    - "host.docker.internal:host-gateway"
```

### Race Semantics (Phase 2)

Race semantics model BPMN constructs where multiple events compete (e.g., service task completion vs boundary timer). The first arm to fire wins.

**WaitState::Race fields:**

| Field | Type | Purpose |
|-------|------|---------|
| `race_id` | `RaceId` | Links to `race_plan` in CompiledProgram |
| `timer_deadline_ms` | `Option<u64>` | Absolute deadline for timer arm |
| `job_key` | `Option<String>` | Preserved from Job state during boundary promotion |
| `interrupting` | `bool` | If true, timer resolves race; if false, spawns child fiber |
| `timer_arm_index` | `Option<usize>` | Computed index into race_plan arms (not hardcoded) |
| `cycle_remaining` | `Option<u32>` | Remaining cycle fires (None = no cycle) |
| `cycle_fired_count` | `u32` | How many times timer has fired (for event numbering) |

**Engine promotion:** When a fiber is in `WaitState::Job` and the compiled program has a `race_plan` entry for that pc, the engine promotes it to `WaitState::Race` — preserving the job_key and adding the timer deadline.

### Non-Interrupting Boundary Events + Timer Cycles (Phase 2A)

**Non-interrupting fire** (5 non-negotiable constraints):
1. Does NOT resolve the race — spawns a child fiber at the escalation path, main fiber stays in Race
2. `timer_arm_index` computed from arms vec, never hardcoded
3. `cycle_fired_count` used for iteration numbering in events
4. Real BPMN element IDs emitted from `RacePlanEntry.boundary_element_id`
5. No `spawned_fibers` stored in `WaitState::Race`

**Timer cycles** use ISO 8601 `R<n>/PT<duration>` format:
- `R3/PT1H` = fire 3 times, 1 hour apart
- After each fire: spawn child fiber, decrement `cycle_remaining`, increment `cycle_fired_count`
- On exhaustion: emit `TimerCycleExhausted`, revert fiber from Race back to plain `WaitState::Job`

**New events:** `BoundaryFired`, `TimerCycleIteration`, `TimerCycleExhausted`

**Verifier rule:** Cycle timers MUST be non-interrupting (`cancelActivity="false"`). Cycle + interrupting = compile error.

### Cancel & Ghost Signal Protection (Phase 3)

Three guards in `engine.complete_job()` prevent ghost signals:

| Guard | Condition | Response |
|-------|-----------|----------|
| Instance not Running | `state != Running` | Emit `SignalIgnored`, return Ok |
| Fiber not found | No fiber for job_key | Emit `SignalIgnored`, return Ok |
| Fiber not waiting | `wait_state` mismatch | Emit `SignalIgnored`, return Ok |

**Cancel improvements:**
- `cancel()` now emits `WaitCancelled` for each active fiber before termination
- `cancel_jobs_for_instance()` purges pending jobs from the queue
- `signal()` checks instance state before matching, emits `SignalIgnored` on no-match

**New events:** `WaitCancelled`, `SignalIgnored`

### Terminate End Events (Phase 5.1)

`EndTerminate` immediately kills all sibling fibers in the same process instance. Unlike `End` (which removes only the executing fiber and lets others continue), `EndTerminate` is a hard stop.

**VM behavior:**
1. Fiber executes `EndTerminate` → returns `TickOutcome::Terminated` (does NOT delete fibers itself)
2. Engine receives `Terminated` outcome → deletes ALL fibers, sets instance state to `Completed`
3. Emits `RuntimeEvent::Terminated { at, fiber_id }` identifying which fiber triggered termination

**Use case:** BPMN terminate end events (e.g., "critical failure — abort entire process regardless of parallel branches").

### Error Boundary Routing (Phase 5.2)

Error boundary events catch `BusinessRejection` failures from service tasks and route to escalation/recovery paths instead of creating incidents.

**ErrorClass taxonomy:**

| Class | Behavior |
|-------|----------|
| `Transient` | Always creates incident (infra/network errors) |
| `ContractViolation` | Always creates incident (programmer error) |
| `BusinessRejection { rejection_code }` | Checks `error_route_map` for matching catch boundary |

**Routing logic in `engine.fail_job()`:**
1. Only `BusinessRejection` errors check routes — `Transient` and `ContractViolation` always create incidents
2. `error_route_map` maps `service_task_pc → Vec<ErrorRoute>` (compiled from BPMN `boundaryEvent` with `errorEventDefinition`)
3. Routes match by `error_code`: specific code match first, then catch-all (`error_code: None`)
4. On match: fiber jumps to `resume_at`, emits `ErrorRouted { job_key, error_code, boundary_id, resume_at }`
5. On no match: falls through to incident creation (existing behavior)

**Key types:**
```rust
pub struct ErrorRoute {
    pub error_code: Option<String>,    // None = catch-all
    pub resume_at: Addr,               // Escalation path entry point
    pub boundary_element_id: String,   // BPMN element ID for tracing
}
```

### Bounded Retry Loops (Phase 5.3)

Two new opcodes enable bounded loops without risk of infinite cycling:

| Opcode | Behavior |
|--------|----------|
| `IncCounter { counter_id }` | Increments `instance.counters[counter_id]`, emits `CounterIncremented` |
| `BrCounterLt { counter_id, limit, target }` | If `counter < limit`, jump to `target`; else fall through |

**Use case:** Retry patterns — "retry up to 3 times, then escalate":
```
IncCounter(0)          ; bump retry count
BrCounterLt(0, 3, L1) ; if retries < 3, go to L1 (retry)
Jump(L2)               ; else go to L2 (escalation)
```

**Counters:**
- Stored in `ProcessInstance.counters: BTreeMap<u32, u32>`
- Epoch-tracked via `loop_epoch` for counter reset across loop iterations
- `CounterIncremented { counter_id, new_value, loop_epoch }` event emitted on each increment

### Inclusive (OR) Gateway (Phase 5A)

Inclusive gateways evaluate condition flags at fork time and spawn fibers only for branches whose conditions are truthy. The join count is dynamic — set at fork time based on how many branches were actually taken.

**Two opcodes:**

| Opcode | Behavior |
|--------|----------|
| `ForkInclusive { branches, join_id, default_target }` | Evaluates each `InclusiveBranch.condition_flag` against `instance.flags`. Spawns fibers for truthy branches. Sets `instance.join_expected[join_id]` to actual count. If no conditions match and `default_target` is set, spawns single fiber there. |
| `JoinDynamic { id, next }` | Same barrier semantics as `Join`, but reads expected count from `instance.join_expected[id]` instead of compile-time constant |

**InclusiveBranch:**
```rust
pub struct InclusiveBranch {
    pub condition_flag: Option<FlagKey>,  // None = unconditional (always taken)
    pub target: Addr,                     // Fiber spawn target
}
```

**Semantics:**
- `condition_flag: None` → always taken (unconditional branch)
- `condition_flag: Some(key)` → taken if `instance.flags[key]` is truthy (`Bool(true)` or `I64(n)` where n != 0)
- At least one branch must be taken (enforced at runtime — if zero match and no default, returns error)
- `InclusiveForkTaken { gateway_id, branches_taken, join_id, expected }` event emitted

**New events:** `Terminated`, `ErrorRouted`, `CounterIncremented`, `InclusiveForkTaken`

### PostgresProcessStore (Phase 4)

> ✅ **IMPLEMENTED (2026-02-10)**: Feature-gated PostgreSQL-backed ProcessStore so workflows survive restarts.

**Feature gate:** All Postgres code behind `#[cfg(feature = "postgres")]`. Never import sqlx in non-gated code.

**Non-negotiable constraints:**
- **Runtime queries only** — `sqlx::query()` / `sqlx::query_as()`, NOT `sqlx::query!()` macro
- **Single SQL round-trip per trait method** — no method issues more than one query
- **BYTEA for `[u8; 32]`** — bind as `&hash[..]`, load as `Vec<u8>` → `.try_into::<[u8; 32]>()?`
- **JSONB for compound fields** — flags, counters, join_expected, state, wait_state, stack, regs, orch_flags, error_class, completion, event
- **`FOR UPDATE SKIP LOCKED`** for `dequeue_jobs` — CTE pattern for concurrent safety
- **Fiber regs padding** — deserialize JSONB as `Vec<Value>`, pad to 8 with `Value::Bool(false)` if short

**12 migrations** (`bpmn-lite-core/migrations/001-012`):
`process_instances`, `fibers`, `join_barriers`, `dedupe_cache`, `job_queue`, `compiled_programs`, `dead_letter_queue`, `event_sequences`, `event_log`, `payload_history`, `incidents`, `updated_at_trigger`

**29 trait methods by group:**

| Group | Methods | SQL Pattern |
|-------|---------|-------------|
| Instance (5) | save/load/update_state/update_flags/update_payload | Upsert, SELECT, UPDATE |
| Fibers (5) | save/load/load_all/delete/delete_all | Upsert, SELECT, DELETE |
| Joins (3) | arrive/reset/delete_all | Upsert+increment, reset, DELETE |
| Dedupe (2) | get/put | SELECT, Upsert |
| Jobs (4) | enqueue/dequeue/ack/cancel_for_instance | INSERT, CTE+SKIP LOCKED, DELETE, DELETE RETURNING |
| Programs (2) | store/load | INSERT ON CONFLICT DO NOTHING, SELECT |
| Dead-letter (2) | put/take | Upsert with computed expires_at, DELETE WHERE expires_at > now() |
| Events (2) | append/read | Atomic CTE (seq alloc + insert), SELECT WHERE seq >= |
| Payload history (2) | save/load | INSERT ON CONFLICT DO NOTHING, SELECT |
| Incidents (2) | save/load | INSERT, SELECT ORDER BY created_at |

**Server wiring:** `--database-url <url>` CLI arg or `DATABASE_URL` env var. Without either, falls back to MemoryStore. Migrations auto-applied on startup via `sqlx::migrate!()`.

**15 integration tests** (all `#[ignore]`, require running Postgres):
T-PG-1 through T-PG-15 covering instance/fiber/join/dedupe/job/event/payload/program/dead-letter/incident round-trips, instance updates, teardown, concurrent dequeue, full engine smoke, and cancel_jobs_for_instance.

### Authoring Pipeline (Phases B-D)

> ✅ **IMPLEMENTED (2026-02-10)**: Verb contracts + static lint rules, BPMN 2.0 XML export with round-trip verification, template registry with atomic publish lifecycle. 30 authoring tests (10 per phase).

The authoring pipeline extends the core compiler with workflow design-time tooling: static analysis against verb contracts, BPMN XML round-trip export/import, and a publish lifecycle with versioned templates.

**Pipeline:**

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  AUTHORING PIPELINE                                                          │
│                                                                              │
│  YAML Workflow Definition                                                    │
│         │                                                                    │
│         ▼                                                                    │
│  parse_workflow_yaml() → WorkflowGraphDto (12 NodeDto variants)             │
│         │                                                                    │
│         ▼                                                                    │
│  validate_dto() → reject if structural errors (15 validation rules)         │
│         │                                                                    │
│         ▼                                                                    │
│  lint_contracts() → 5 lint rules (L1-L5) against VerbContract registry      │
│         │   L1: Flag provenance (backward BFS)                              │
│         │   L2: Error code validity                                         │
│         │   L3: Correlation provenance                                      │
│         │   L4: Missing contract warning                                    │
│         │   L5: Unused writes warning                                       │
│         │                                                                    │
│         ▼                                                                    │
│  dto_to_ir() → IRGraph (petgraph)                                           │
│         │                                                                    │
│         ▼                                                                    │
│  verify() + lower() → CompiledProgram (bytecode)                            │
│         │                                                                    │
│         ▼                                                                    │
│  compute_bytecode_hash() → SHA-256 of instruction stream                    │
│         │                                                                    │
│         ▼                                                                    │
│  Optional: dto_to_bpmn_xml() → BPMN 2.0 XML (Zeebe-compatible)             │
│         │                                                                    │
│         ▼                                                                    │
│  Build WorkflowTemplate (state=Published, all artifacts)                    │
│         │                                                                    │
│         ▼                                                                    │
│  compile_and_publish() → ProcessStore + TemplateStore persistence           │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Verb Contracts (`contracts.rs`):**

| Type | Purpose |
|------|---------|
| `VerbContract` | Declares what a verb reads, writes, may raise, and produces |
| `CorrelationContract` | Declares a correlation key a verb produces |
| `ContractRegistry` | Registry of contracts + known workflow inputs (YAML-parseable) |

**Lint Rules (`lints.rs`):**

| Rule | Level | Description |
|------|-------|-------------|
| L1 | Error/Warning | Flag provenance — every flag condition must be written upstream (backward BFS); Warning if in `known_workflow_inputs` |
| L2 | Error | Error code validity — `on_error.error_code` must be in task's `may_raise_errors` (`"*"` catch-all satisfies) |
| L3 | Warning | Correlation provenance — MessageWait/HumanWait `corr_key_source` should match upstream `produces_correlation` |
| L4 | Warning | Missing contract — ServiceTask without registered contract |
| L5 | Warning | Unused writes — verb declares `writes_flags` but no edge condition references it |

**BPMN 2.0 XML Export (`export_bpmn.rs`):**

- Maps all 12 NodeDto variants to BPMN elements (startEvent, endEvent, serviceTask, exclusiveGateway, parallelGateway, inclusiveGateway, intermediateCatchEvent, eventBasedGateway, boundaryEvent)
- Deterministic `bpmn_id` generation: `sanitize_ncname(node_id) + "_" + sha256(node_id)[..4].hex()`
- Conditions exported as FEEL expressions: `= {flag} {op} {value}`
- Timer ms → ISO 8601 duration conversion
- DI layout: topological left-to-right (X = topo_rank * 200, Y = rank_index * 100)
- XOR default: set from `is_default=true` edge only (never from edge ordering)

**IR-to-DTO Reverse Mapping (`ir_to_dto.rs`):**

- Enables round-trip verification: DTO → IR → DTO → compare structure
- Maps all IRNode variants back to NodeDto
- Detects XOR default edges (unconditional from XOR with other conditional edges → `is_default=true`)

**Template Registry (`registry.rs`):**

| Type | Purpose |
|------|---------|
| `TemplateState` | `Draft`, `Published`, `Retired` — valid transitions: Draft→Published, Published→Retired |
| `SourceFormat` | `Yaml`, `BpmnImport`, `Agent` |
| `WorkflowTemplate` | Versioned publish artifact (dto_snapshot, task_manifest, bytecode_version, bpmn_xml, etc.) |
| `TemplateStore` | Async trait: save, load, list, set_state, load_latest_published |
| `MemoryTemplateStore` | In-memory implementation with immutability guards |

**Atomic Publish (`publish.rs`):**

- `publish_workflow(yaml_str, options) → PublishResult` — 10-step sync pipeline, no intermediate Draft artifact
- Rejects on validation errors, lint Error-level diagnostics, or verification failures
- `PublishResult` contains: `WorkflowTemplate` + `CompiledProgram` + `Vec<LintDiagnostic>`
- `compute_bytecode_hash()`: SHA-256 of debug-formatted instruction stream (excludes debug_map for stability)

**Engine Integration:**

- `BpmnLiteEngine::compile_and_publish()` — orchestrates publish pipeline + ProcessStore + TemplateStore persistence
- Program writes are idempotent (keyed by bytecode hash) — retry-safe

**PostgresTemplateStore (`store_postgres_templates.rs`):**

- Feature-gated behind `#[cfg(feature = "postgres")]`
- Migration `013_create_workflow_templates.sql`: table + published lookup index + immutability trigger
- Immutability trigger: published content cannot change (only state→retired); retired cannot revert

**Test Coverage (30 authoring tests):**

| Phase | Tests | Coverage |
|-------|-------|----------|
| B: Contracts + Lints | 10 (T-LINT-1..10) | Flag provenance, error codes, correlation, missing contracts, unused writes, race arm BFS, clean workflow |
| C: Export + IR-to-DTO | 10 (T-EXP-1..10) | Basic export, XOR default, timer ISO, FEEL conditions, deterministic IDs, boundary export, round-trip, linear IR, XOR conditions, boundary error |
| D: Registry + Publish | 10 (T-PUB-1..10) | Save/load round-trip, state transitions, published immutability, list filters, latest published, minimal publish, lint blocks, deterministic bytecode, artifact set, Postgres (ignored) |

### Key Files

| File | Purpose |
|------|---------|
| `bpmn-lite/bpmn-lite-core/src/types.rs` | All core types (Value, Instr, Fiber, CycleSpec, WaitArm, RacePlanEntry, InclusiveBranch, ErrorRoute, ErrorClass) |
| `bpmn-lite/bpmn-lite-core/src/events.rs` | RuntimeEvent enum (28 variants) |
| `bpmn-lite/bpmn-lite-core/src/store.rs` | ProcessStore trait (29 methods) |
| `bpmn-lite/bpmn-lite-core/src/store_memory.rs` | MemoryStore implementation |
| `bpmn-lite/bpmn-lite-core/src/store_postgres.rs` | PostgresProcessStore (`#[cfg(feature = "postgres")]`, 29 methods, 15 tests) |
| `bpmn-lite/bpmn-lite-core/migrations/` | 13 SQL migrations (tables, indexes, triggers, workflow_templates) |
| `bpmn-lite/bpmn-lite-core/src/vm.rs` | VM tick executor + race/boundary/terminate/inclusive tests |
| `bpmn-lite/bpmn-lite-core/src/engine.rs` | BpmnLiteEngine facade + compile_and_publish() |
| `bpmn-lite/bpmn-lite-core/src/compiler/parser.rs` | BPMN XML → IR (timeCycle, cancelActivity, errorEventDefinition, inclusiveGateway) |
| `bpmn-lite/bpmn-lite-core/src/compiler/ir.rs` | IRGraph, TimerSpec (Duration/Date/Cycle) |
| `bpmn-lite/bpmn-lite-core/src/compiler/verifier.rs` | Structural verification (cycle+interrupting rule) |
| `bpmn-lite/bpmn-lite-core/src/compiler/lowering.rs` | IR → bytecode (race_plan, error_route_map, inclusive branches) |
| `bpmn-lite/bpmn-lite-core/src/authoring/contracts.rs` | VerbContract, ContractRegistry, YAML parsing |
| `bpmn-lite/bpmn-lite-core/src/authoring/lints.rs` | 5 lint rules (L1-L5), lint_contracts() entry point |
| `bpmn-lite/bpmn-lite-core/src/authoring/export_bpmn.rs` | DTO → BPMN 2.0 XML (Zeebe-compatible) |
| `bpmn-lite/bpmn-lite-core/src/authoring/ir_to_dto.rs` | IR → DTO reverse mapping for round-trip |
| `bpmn-lite/bpmn-lite-core/src/authoring/registry.rs` | WorkflowTemplate, TemplateStore trait, MemoryTemplateStore |
| `bpmn-lite/bpmn-lite-core/src/authoring/publish.rs` | Atomic 10-step publish pipeline |
| `bpmn-lite/bpmn-lite-core/src/authoring/store_postgres_templates.rs` | PostgresTemplateStore (feature-gated) |
| `bpmn-lite/bpmn-lite-server/src/lib.rs` | Library re-export of proto module |
| `bpmn-lite/bpmn-lite-server/src/grpc.rs` | gRPC handler implementations |
| `bpmn-lite/bpmn-lite-server/src/main.rs` | Server startup |
| `bpmn-lite/bpmn-lite-server/proto/bpmn_lite/v1/bpmn_lite.proto` | Proto definition |
| `bpmn-lite/bpmn-lite-server/tests/integration.rs` | 6 integration tests + 1 gRPC smoke test |
| `rust/xtask/src/bpmn_lite.rs` | xtask build/test/deploy commands |

### Fiber-Based Execution Model — Design Rationale

**Problem:** We need a workflow runtime that supports long-running orchestration (minutes to weeks), pause/resume on timers/messages/human gates, deterministic replay, exactly-once domain effects over at-least-once delivery, and strict separation of orchestration from business logic.

**Why not interpreter-style BPMN execution?** A "DI/Spring" instinct is to load BPMN XML into a runtime interpreter and execute it. That fails because: interpreter state is opaque and hard to persist/replay deterministically; "magic" pushes failures to runtime and makes incident resolution non-reproducible; data mapping engines (FEEL/JUEL) encourage domain logic in the workflow engine; exactly-once semantics become hard to guarantee.

**Chosen approach:** BPMN-Lite **compiles** BPMN into compact bytecode, then executes it using **fibers**.

**What is a Fiber:** A fiber is the smallest unit of execution — a user-space "token + instruction pointer":
- **Serializable** — can be persisted to storage and resumed later
- **Explicit** — not hidden in a framework runtime
- **Controlled** — our scheduler decides step budgets, no hidden preemption
- **Deterministic** — same inputs produce same execution trace

```rust
struct Fiber {
    fiber_id: Uuid,
    pc: Addr,                    // Program counter into bytecode
    stack: Vec<Value>,           // Small values for branching
    regs: [Option<Value>; 8],    // Fixed locals
    wait_state: WaitState,       // Running | Job | Timer | Msg | Join | Race | Incident
}
```

**Yield points are explicit and finite.** A fiber may only stop at:
- `EXEC_NATIVE` → parks as `WaitState::Job` (waiting for ob-poc verb worker)
- `WAIT_*` (timer/message/human) → parks in appropriate wait state
- `JOIN` → parks at parallel join barrier
- `END` / `FAIL` → terminates fiber

**Why fibers instead of goroutines/threads:**
- **Massive concurrency** — thousands of tokens without OS threads
- **Deterministic scheduling** — no hidden preemption
- **Durable persistence** — serialize fiber state, restart safely
- **Exact invariants** — "no fiber → no mutation" guardrails
- **Replayability** — event log + fiber snapshots restore exact state

Goroutines/threads are great for in-memory concurrency but cannot reliably persist a goroutine's stack/PC and replay it deterministically.

**Two-stack separation (process vs data):**

| Stack | Owned By | Contents |
|-------|----------|----------|
| **Process / control-flow** | BPMN-Lite | Bytecode, fibers, joins, waits, races, event log |
| **Domain / business data** | ob-poc | `domain_payload` (opaque canonical JSON + SHA-256 hash) |

The engine **never interprets** `domain_payload`. Only ob-poc verbs mutate it. The engine branches only on `orch_flags` (flat primitives). This prevents "engine creep" into business logic.

**How work happens (EXEC_NATIVE → Job):**
1. Service task compiles to `EXEC_NATIVE` → creates `JobActivation` (job_key, task_type, domain_payload + hash, orch_flags)
2. ob-poc worker processes the job by running a verb
3. Worker returns `JobCompletion` (same job_key, updated payload + hash, updated orch_flags)
4. Idempotency: completion deduped by `job_key` — retries and duplicates are safe

**Durability invariants (non-negotiable):**
- A completion/signal must never mutate state unless there is a live fiber waiting for it
- Every irreversible decision is recorded in the event log (gateway branches, wait registrations, race winners, join releases, flag writes)
- PITR/replay must not re-execute verbs — it replays decisions and consults dedupe history

**Alternatives considered and rejected:**

| Alternative | Why Rejected |
|-------------|-------------|
| Interpreter-style BPMN | Opaque runtime state, hard PITR, encourages domain logic in engine |
| Full Camunda-like engine | Heavy platform surface area, data semantics not solved, "engine becomes system" |
| Thread-per-instance | Too heavy, not scalable, hard to persist |

**Where to look in the code:**

| File | What to Read |
|------|-------------|
| `bpmn-lite-core/src/types.rs` | `Fiber`, `WaitState`, `Instr`, `Value` — the core data model |
| `bpmn-lite-core/src/vm.rs` | `tick_fiber()` — the bytecode interpreter loop |
| `bpmn-lite-core/src/engine.rs` | `BpmnLiteEngine` — facade orchestrating compiler + VM + store |
| `bpmn-lite-core/src/store.rs` | `ProcessStore` trait — the persistence contract |
| `bpmn-lite-core/src/events.rs` | `RuntimeEvent` — the audit event log |
| `rust/src/bpmn_integration/dispatcher.rs` | `WorkflowDispatcher` — ob-poc side, routes verbs to BPMN-Lite |
| `rust/src/bpmn_integration/worker.rs` | `JobWorker` — ob-poc side, processes jobs from BPMN-Lite |

---

## Code Patterns

### Config Struct Pattern

For types with many optional parameters, use a builder-style config struct:

```rust
// Instead of many constructors:
// fn new(pool: PgPool) -> Self
// fn with_sessions(pool: PgPool, sessions: SessionStore) -> Self
// fn with_all_sessions(...) -> Self

// Use config struct with builder:
pub struct ToolHandlersConfig {
    pub pool: PgPool,
    pub sessions: Option<SessionStore>,
    pub cbu_sessions: Option<CbuSessionStore>,
    pub learned_data: Option<SharedLearnedData>,
    pub embedder: Option<SharedEmbedder>,
}

// Usage:
let handlers = ToolHandlersConfig::new(pool)
    .with_sessions(sessions)
    .with_embedder(embedder)
    .build();
```

See `rust/src/mcp/handlers/core.rs` for the `ToolHandlersConfig` pattern.

### Centralized DB Access

All database access should go through service modules in `rust/src/database/`:
- `VerbService` for verb discovery and semantic search
- `VisualizationRepository` for graph/viewport queries
- `SessionRepository` for session persistence
- `GenerationLogRepository` for training data

No direct `sqlx::query` calls outside of service modules.

---

## ESPER Navigation Crates (065)

> **DEPRECATED (2026-01-31):** The esper_* crates (`esper_snapshot`, `esper_core`, `esper_input`,
> `esper_policy`, `esper_egui`) are retained in the repository for reference but are no longer
> used by any active code path. All visualization is now handled by the React frontend
> (`ob-poc-ui-react/`) with data served via REST API endpoints.

**Crates retained for reference:** `esper_snapshot`, `esper_core`, `esper_input`, `esper_policy`, `esper_egui`, `esper_compiler`

For historical implementation details, see git history or `ai-thoughts/065-esper-navigation.md`.

---

## Graph Configuration (Policy-Driven)

> ❌ **REMOVED (2026-02-13)**: `ob-poc-graph` crate, `viewport` crate, and `config/graph_settings.yaml` deleted.
> Built for esper_* visualization crates (deprecated). React frontend uses REST API directly.

---

## Inspector-First Visualization (076)

> ✅ **IMPLEMENTED (2026-02-04)**: Deterministic tree/table-based Inspector UI replacing 3D visualization, with projection schema and `$ref` linking.

The Inspector-First Visualization provides a deterministic, compliance-focused alternative to the ESPER 3D visualization. It uses a flat node map with `$ref` linking for node-to-node relationships, enabling explainable and auditable visualizations.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    INSPECTOR PROJECTION PIPELINE                             │
│                                                                              │
│  CBU Graph Data (entities, matrix, registers)                               │
│         │                                                                    │
│         ▼                                                                    │
│  CbuGenerator / MatrixGenerator                                             │
│         │   - Converts domain types to projection nodes                     │
│         │   - Creates flat node map with $ref links                         │
│         │   - Applies RenderPolicy (LOD, depth, filters)                    │
│         │                                                                    │
│         ▼                                                                    │
│  InspectorProjection                                                        │
│         │   - snapshot: schema_version, source_hash, policy_hash            │
│         │   - render_policy: lod, max_depth, filters                        │
│         │   - root: BTreeMap<chamber, RefValue>                             │
│         │   - nodes: BTreeMap<NodeId, Node>                                 │
│         │                                                                    │
│         ▼                                                                    │
│  Inspector Panel (egui)                                                     │
│         │   - Three-panel layout (nav tree, main view, detail pane)         │
│         │   - Table rendering for matrix/holdings/control                   │
│         │   - LOD controls, chamber toggles, filters                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Key Principles

| Principle | Implementation |
|-----------|----------------|
| **Correctness over polish** | Every visualization is explainable and traceable |
| **Determinism** | Same input + policy = same output, always |
| **Separation of concerns** | Projection contract independent of renderer |
| **Compliance-first** | Provenance, confidence, audit trails are first-class |

### Core Types

**NodeId** - Stable path-based identifier:
```rust
// Format: {kind}:{qualifier}[:{subpath}]
// Examples: "cbu:allianz-ie", "matrix:focus:mic:XLON", "entity:uuid:..."
// Pattern: ^[a-z]+:[A-Za-z0-9_:-]+$
```

**RefValue** - `$ref` linking (flat node map, no recursive embedding):
```rust
// Serializes as: { "$ref": "node_id" }
pub struct RefValue {
    #[serde(rename = "$ref")]
    pub target: NodeId,
}
```

**NodeKind** - 20 node type variants:
- CBU, MemberList, Entity
- ProductTree, Product, Service, Resource, ProductBinding
- InstrumentMatrix, MatrixSlice, SparseCellPage
- InvestorRegister, HoldingEdgeList, HoldingEdge
- ControlRegister, ControlTree, ControlNode, ControlEdge

**RenderPolicy** - LOD levels 0-3:

| LOD | Display |
|-----|---------|
| 0 | Glyph + ID only |
| 1 | Glyph + label_short |
| 2 | + tags, summary, collapsed branches |
| 3 | + label_full, attributes, provenance, expanded branches |

### API Endpoint

```
GET /api/cbu/:cbu_id/inspector?lod=2&max_depth=5
```

Returns `InspectorProjection` with full node tree for the CBU.

### UI Panel Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│ [Search] [LOD: ▼] [Depth: ▼] [Chambers: ▼] [Filters: ▼] [Reset]    │
├─────────────────────────────────────────────────────────────────────┤
│ Breadcrumb: CBU > Members > Fund: Allianz IE ETF SICAV              │
├───────────────────┬─────────────────────────┬───────────────────────┤
│ Navigation Tree   │ Main View               │ Detail Pane           │
│ (30%)             │ (45%)                   │ (25%)                 │
│                   │                         │                       │
│ - CBU             │ [Tree or Table based    │ Kind: Entity          │
│   - Members       │  on focused node kind]  │ ID: entity:uuid:...   │
│     - Fund ←      │                         │ Label: Fund: ...      │
│     - IM          │                         │ Attributes: {...}     │
│   - Products      │                         │ Provenance: {...}     │
│   - Matrix        │                         │ Links: [...]          │
│   - Registers     │                         │                       │
└───────────────────┴─────────────────────────┴───────────────────────┘
```

### Table Rendering

For matrix slices, holdings, and control trees, the Inspector uses `egui_extras::TableBuilder`:

| View | Columns | Features |
|------|---------|----------|
| Matrix Slice | Instrument, Market, Currency, Status | Color-coded status, cell selection |
| Holdings | Holder, Amount, Percentage, Confidence | Sortable, provenance tooltips |
| Control Tree | Controller, Controlled, Voting %, Provenance | Hierarchical with expand/collapse |

### Validation

Pre-render validation ensures projection integrity:
1. **Dangling refs** - All `$ref` targets must exist in `nodes`
2. **Cycle detection** - DFS with visited set, report cycles as warnings
3. **Root validation** - All root refs must exist
4. **Provenance** - `HoldingEdge` and `ControlEdge` MUST have provenance
5. **Confidence range** - Must be 0.0-1.0 if present

### Crate Structure

```
rust/crates/inspector-projection/
├── src/
│   ├── lib.rs              # Public API exports
│   ├── model.rs            # InspectorProjection, Node, NodeKind
│   ├── node_id.rs          # NodeId newtype with regex validation
│   ├── ref_value.rs        # RefValue $ref linking
│   ├── validate.rs         # Referential integrity, cycle detection
│   ├── policy.rs           # RenderPolicy (LOD, filters)
│   ├── error.rs            # ValidationError enum
│   └── generator/
│       ├── mod.rs          # Generator traits
│       ├── cbu.rs          # CbuGenerator (graph → projection)
│       └── matrix.rs       # MatrixGenerator (trading matrix → projection)
```

### Key Files

| File | Purpose |
|------|---------|
| `rust/crates/inspector-projection/src/model.rs` | Core types: Node, NodeKind, InspectorProjection |
| `rust/crates/inspector-projection/src/node_id.rs` | NodeId with regex validation |
| `rust/crates/inspector-projection/src/validate.rs` | Projection validation |
| `rust/crates/inspector-projection/src/generator/cbu.rs` | CbuGenerator |
| `rust/src/api/graph_routes.rs` | `/api/cbu/:cbu_id/inspector` endpoint |
| `rust/tests/fixtures/inspector/sample.yaml` | Test fixture with all node kinds |

> **Note:** The egui Inspector panel (`ob-poc-ui`) has been removed. The projection crate (`inspector-projection`) remains active for API-driven inspection.

### Test Coverage

- 48 unit tests in `inspector-projection` crate
- 32 integration tests in `rust/tests/`
- 2 doc tests
- Sample YAML fixture with comprehensive node coverage

---

## Lexicon Service (072)

> ✅ **IMPLEMENTED (2026-02-02)**: In-memory verb/domain/concept lookup with bincode snapshots.

The Lexicon Service provides fast, in-memory lookup for DSL vocabulary without database queries at runtime.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    LEXICON PIPELINE                                          │
│                                                                              │
│  config/verbs/*.yaml + config/lexicon/*.yaml                                │
│         │                                                                    │
│         ▼                                                                    │
│  cargo x lexicon compile                                                    │
│         │   - Loads verb definitions from YAML                              │
│         │   - Loads domain/entity_type/verb_concept config                  │
│         │   - Builds indexed snapshot                                       │
│         │   - Serializes to bincode                                         │
│         │                                                                    │
│         ▼                                                                    │
│  assets/lexicon.snapshot.bin                                                │
│         │                                                                    │
│         ▼                                                                    │
│  LexiconService::load() at server startup                                   │
│         │   - Deserializes snapshot                                         │
│         │   - Provides O(1) lookups for verbs, domains, concepts            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Key Types

| Type | Purpose |
|------|---------|
| `LexiconSnapshot` | In-memory index with verb/domain/concept maps |
| `VerbEntry` | Verb metadata (domain, action, description, args) |
| `DomainEntry` | Domain with associated verbs |
| `VerbConceptEntry` | Semantic concept for intent matching |

### Commands

```bash
cd rust/

# Compile lexicon snapshot from YAML
cargo x lexicon compile [-v|--verbose]

# Lint lexicon config for issues  
cargo x lexicon lint [--errors-only]

# Show snapshot statistics
cargo x lexicon stats [--snapshot <path>]
```

### Key Files

| File | Purpose |
|------|---------|
| `rust/src/lexicon/mod.rs` | Module exports |
| `rust/src/lexicon/types.rs` | `LexiconSnapshot`, `VerbEntry`, `DomainEntry` |
| `rust/src/lexicon/compiler.rs` | YAML → snapshot compiler |
| `rust/src/lexicon/service.rs` | `LexiconService` trait and implementation |
| `rust/src/lexicon/snapshot.rs` | Bincode serialization |
| `rust/xtask/src/lexicon.rs` | CLI commands |
| `rust/config/lexicon/domains.yaml` | Domain definitions |
| `rust/config/lexicon/entity_types.yaml` | Entity type vocabulary |
| `rust/config/lexicon/verb_concepts.yaml` | Verb concept mappings |
| `rust/assets/lexicon.snapshot.bin` | Compiled snapshot artifact |

---

## Entity Linking Service (073)

> ✅ **IMPLEMENTED (2026-02-03)**: In-memory entity resolution with mention extraction and token overlap matching.

The Entity Linking Service resolves natural language entity references to database UUIDs without runtime DB queries for the lookup phase.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ENTITY LINKING PIPELINE                                   │
│                                                                              │
│  User utterance: "Set up ISDA with Goldman Sachs"                           │
│         │                                                                    │
│         ▼                                                                    │
│  MentionExtractor.extract()                                                 │
│         │   - N-gram scanning (1 to max_ngram_size tokens)                  │
│         │   - Alias index lookup                                            │
│         │   - Token overlap fallback for fuzzy matching                     │
│         │   - Non-overlapping span selection                                │
│         │                                                                    │
│         ▼                                                                    │
│  MentionSpan { text: "Goldman Sachs", candidate_ids: [uuid1, ...] }         │
│         │                                                                    │
│         ▼                                                                    │
│  EntityLinkingService.resolve_mentions()                                    │
│         │   - Score candidates by kind constraint + concept overlap         │
│         │   - Generate Evidence for disambiguation audit                    │
│         │                                                                    │
│         ▼                                                                    │
│  EntityResolution { entity_id, score, evidence: [...] }                     │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Snapshot Compilation

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  DATABASE TABLES                          SNAPSHOT INDEXES                   │
│                                                                              │
│  ob-poc.entities ──────────────────────► entities: Vec<EntityRow>           │
│  ob-poc.entity_names ──────────────────► name_index: HashMap<norm, id>      │
│  agent.entity_aliases ─────────────────► alias_index: HashMap<alias, ids>   │
│  ob-poc.entity_concept_link ───────────► concept_links: HashMap<id, concepts>│
│  ob-poc.entity_feature ────────────────► (future: feature vectors)          │
│                                                                              │
│  + Derived token_index for fuzzy matching                                   │
│  + Derived kind_index for type filtering                                    │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Key Types

| Type | Purpose |
|------|---------|
| `EntitySnapshot` | In-memory indexes (alias, name, token, concept, kind) |
| `EntityRow` | Entity record (id, kind, canonical_name, name_norm) |
| `MentionExtractor` | N-gram scanner for entity mentions |
| `MentionSpan` | Extracted mention with character positions and candidates |
| `EntityLinkingService` | Resolution trait with scoring and evidence |
| `EntityResolution` | Resolved entity with score and evidence trail |
| `Evidence` | Tagged enum for disambiguation audit (ExactAlias, TokenOverlap, etc.) |

### Commands

```bash
cd rust/

# Compile entity snapshot from database
DATABASE_URL="postgresql:///data_designer" cargo x entity compile [-v|--verbose]

# Lint entity data for quality issues
DATABASE_URL="postgresql:///data_designer" cargo x entity lint [--errors-only]

# Show snapshot statistics
cargo x entity stats [--snapshot <path>]
```

### Text Normalization

Entity matching uses Unicode NFKC normalization:

```rust
use ob_poc::entity_linking::normalize_entity_text;

// Basic normalization: lowercase, NFKC, strip punctuation
normalize_entity_text("Goldman Sachs & Co.", false)  // → "goldman sachs co"

// With legal suffix stripping
normalize_entity_text("Apple Inc.", true)  // → "apple"
normalize_entity_text("Ford Motor Company Ltd.", true)  // → "ford motor company"
```

### Key Files

| File | Purpose |
|------|---------|
| `rust/src/entity_linking/mod.rs` | Module exports |
| `rust/src/entity_linking/normalize.rs` | Unicode NFKC normalization, tokenization |
| `rust/src/entity_linking/snapshot.rs` | `EntitySnapshot` with indexes |
| `rust/src/entity_linking/mention.rs` | `MentionExtractor` for n-gram scanning |
| `rust/src/entity_linking/resolver.rs` | `EntityLinkingService` trait and impl |
| `rust/src/entity_linking/compiler.rs` | DB → snapshot compiler with SHA256 hash |
| `rust/xtask/src/entity.rs` | CLI commands |
| `rust/assets/entity.snapshot.bin` | Compiled snapshot artifact |
| `rust/migrations/073_entity_linking_support.sql` | Schema additions |

### Database Tables (073)

| Table | Purpose |
|-------|---------|
| `ob-poc.entity_concept_link` | Links entities to semantic concepts with weights |
| `ob-poc.entity_feature` | Entity feature flags (future: ML features) |
| `ob-poc.entities.name_norm` | Normalized name column with auto-update trigger |

### Views

| View | Purpose |
|------|---------|
| `ob-poc.v_entity_linking_data` | Flattened entity data for snapshot compilation |
| `ob-poc.v_entity_aliases` | Union of entity_names + agent.entity_aliases |
| `ob-poc.v_entity_linking_stats` | Statistics for monitoring |

### Agent Pipeline Integration

The EntityLinkingService is integrated into the agent chat pipeline for:
1. **Pre-resolution** - Entity mentions extracted BEFORE verb search
2. **Kind hints** - Resolved entity kinds inform verb argument expectations
3. **Dominant entity** - Highest confidence entity stored in session context
4. **Debug info** - Entity resolution details in `ChatDebugInfo.entity_resolution`

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  AGENT PIPELINE WITH ENTITY LINKING                                          │
│                                                                              │
│  User: "Set up ISDA with Goldman Sachs"                                     │
│         │                                                                    │
│         ▼                                                                    │
│  1. EntityLinkingService.resolve_mentions()                                 │
│         │   └─► "Goldman Sachs" → entity_id (score: 0.95)                   │
│         │   └─► dominant_entity_id stored in session.context                │
│         │                                                                    │
│         ▼                                                                    │
│  2. HybridVerbSearcher.search() (verb discovery)                            │
│         │   └─► "isda.create" (score: 0.88)                                 │
│         │                                                                    │
│         ▼                                                                    │
│  3. LLM extracts arguments (JSON)                                           │
│         │                                                                    │
│         ▼                                                                    │
│  4. DSL generation with entity resolution                                   │
│         │   └─► (isda.create :counterparty <Goldman Sachs>)                 │
│         │                                                                    │
│         ▼                                                                    │
│  5. Stage for execution or auto-run (navigation verbs)                      │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Key Integration Points:**

| Component | File | Integration |
|-----------|------|-------------|
| `AgentState` | `api/agent_routes.rs` | Loads snapshot at startup, field `entity_linker` |
| `AgentService` | `api/agent_service.rs` | `extract_entity_mentions()` in `process_chat()` |
| `SessionContext` | `api/session.rs` | `dominant_entity_id` field for implicit resolution |
| `ChatDebugInfo` | `ob-poc-types/src/lib.rs` | `entity_resolution` field for explainability |

**Debug Output (when OB_CHAT_DEBUG=1):**

```json
{
  "entity_resolution": {
    "snapshot_hash": "a1b2c3d4...",
    "entity_count": 1452,
    "mentions": [{
      "span": [15, 28],
      "text": "Goldman Sachs",
      "candidates": [{"entity_id": "...", "score": 0.95, "entity_kind": "company"}],
      "selected_id": "...",
      "confidence": 0.95
    }],
    "dominant_entity": {"entity_id": "...", "canonical_name": "Goldman Sachs Group Inc"},
    "expected_kinds": ["company"]
  }
}
```

**Graceful Degradation:**

If no entity snapshot is available, `StubEntityLinkingService` is used:
- Returns empty results for all lookups
- Pipeline continues without entity pre-resolution
- Full functionality restored when snapshot is compiled

### Entity-Kind Constrained Verb Selection

Verbs declare their applicable entity kinds via `subject_kinds` in VerbContractBody and verb YAML metadata. The pipeline filters verbs by entity kind when a dominant entity is known.

**Contract fields** (`rust/src/sem_reg/verb_contract.rs`):
- `subject_kinds: Vec<String>` — entity kinds this verb applies to (empty = all)
- `phase_tags: Vec<String>` — phase tags (stored, not yet filtered)
- `requires_subject: bool` — whether verb needs a subject entity (default true)
- `produces_focus: bool` — whether execution updates session focus entity

**Pipeline flow** (`rust/src/agent/orchestrator.rs`):
1. Entity linking resolves `dominant_entity_kind` from LookupResult
2. `entity_kind` passed to `ContextResolutionRequest` → `filter_and_rank_verbs()`
3. Verbs with non-empty `subject_kinds` not containing the entity kind are hard-filtered
4. Matching verbs get +0.15 rank boost
5. If kind-filtering removes ALL candidates, falls back to unfiltered (graceful degradation)

**ClarifyEntity** (`rust/crates/ob-poc-types/src/decision.rs`):
- `DecisionKind::ClarifyEntity` — emitted when entity linking is ambiguous (no clear winner)
- `EntityClarificationPayload` with `Vec<EntityChoice>` — candidate entities for user selection
- Rendering and choices generation wired in `rust/src/clarify/render.rs` and `packet.rs`

**Telemetry** (`migrations/088_intent_events_entity_kind.sql`):
- `dominant_entity_id`, `dominant_entity_kind`, `entity_kind_filtered` columns on `agent.intent_events`

**IntentTrace fields**: `dominant_entity_kind: Option<String>`, `entity_kind_filtered: bool`

**Scanner heuristic** (`rust/src/sem_reg/scanner.rs`): When `subject_kinds` is not declared in YAML metadata, the scanner derives it from `produces.entity_type` (e.g., verb producing "cbu" gets subject_kinds=["cbu"]).

**Annotated verb files**: fund.yaml, client.yaml, kyc/board.yaml, onboarding.yaml, gleif.yaml

**Harness scenarios**: `scenarios/suites/entity_kind_ops.yaml` (10 scenarios)

---

## Unified Lookup Service (074)

> ✅ **IMPLEMENTED (2026-02-04)**: Consolidated verb search + entity linking with verb-first ordering.

The LookupService unifies verb discovery and entity resolution into a single analysis pass, implementing **verb-first ordering**: verbs are searched first, then expected entity kinds are derived from verb schema, and finally entities are resolved with kind constraints.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  UNIFIED LOOKUP SERVICE - Verb-First Ordering                                │
│                                                                              │
│  User: "Load the Allianz book"                                              │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Step 1: VERB SEARCH (HybridVerbSearcher)                           │    │
│  │  "load the allianz book" → session.load-galaxy (score: 0.85)        │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Step 2: DERIVE EXPECTED KINDS (from verb schema)                   │    │
│  │  session.load-galaxy has :apex-entity-id arg with lookup config     │    │
│  │  → expected_kinds: ["company", "client_group"]                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Step 3: ENTITY RESOLUTION (EntityLinkingService)                   │    │
│  │  "allianz" + kind_constraint → Allianz SE (score: 0.92)            │    │
│  │  Kind constraint boosts company matches, penalizes person matches   │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│         │                                                                    │
│         ▼                                                                    │
│  LookupResult {                                                              │
│    verbs: [session.load-galaxy @ 0.85, ...],                                │
│    entities: [Allianz SE @ 0.92],                                           │
│    dominant_entity: Allianz SE,                                             │
│    expected_kinds: ["company", "client_group"],                             │
│    verb_matched: true,                                                       │
│    entities_resolved: true                                                   │
│  }                                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Key Insight: Verb-First vs Entity-First

| Approach | Flow | Problem |
|----------|------|---------|
| **Entity-first** | Entities → Verbs | "Goldman" matches 50 people AND the company |
| **Verb-first** | Verbs → Expected Kinds → Entities | "isda.create" expects company → "Goldman" = Goldman Sachs Group |

Verb-first ordering uses verb schema to **constrain** entity resolution, dramatically improving accuracy.

### Key Types

| Type | Module | Purpose |
|------|--------|---------|
| `LookupService` | `lookup::service` | Unified analysis combining verb search + entity linking |
| `LookupResult` | `lookup::service` | Combined result with verbs, entities, dominant entity |
| `DominantEntity` | `lookup::service` | Highest confidence resolved entity |

### LookupResult Fields

```rust
pub struct LookupResult {
    /// Verb candidates from search (sorted by score)
    pub verbs: Vec<VerbSearchResult>,
    
    /// Entity resolutions with kind-constrained scoring
    pub entities: Vec<EntityResolution>,
    
    /// Dominant entity (highest confidence, kind-matched)
    pub dominant_entity: Option<DominantEntity>,
    
    /// Expected entity kinds derived from top verb(s)
    pub expected_kinds: Vec<String>,
    
    /// Whether verb search found a clear winner (score >= 0.65)
    pub verb_matched: bool,
    
    /// Whether entity resolution found unambiguous matches
    pub entities_resolved: bool,
}
```

### Integration in AgentService

The `LookupService` is built on-demand in `AgentService.get_lookup_service()` using existing components:

```rust
// AgentService.process_chat() uses unified lookup when entity_linker is configured
let (entity_resolution_debug, dominant_entity_id, resolved_kinds) =
    if let Some(lookup_service) = self.get_lookup_service() {
        // Unified path: verb-first ordering
        let lookup_result = lookup_service.analyze(&request.message, 5).await;
        // ... build debug info from lookup_result
    } else {
        // Legacy path: separate entity linking
        self.extract_entity_mentions(&request.message, None)
    };
```

### Key Files

| File | Purpose |
|------|---------|
| `rust/src/lookup/mod.rs` | Module exports |
| `rust/src/lookup/service.rs` | `LookupService` implementation |
| `rust/src/api/agent_service.rs` | `get_lookup_service()` builder, integration in `process_chat()` |

### Graceful Degradation

If `entity_linker` is not configured (no snapshot), `get_lookup_service()` returns `None` and the legacy path is used. This ensures the pipeline always works, with enhanced accuracy when entity linking is available.

---

## Key Directories

```
ob-poc/
├── bpmn-lite/                  # Standalone BPMN orchestration service (NOT inside rust/)
│   ├── bpmn-lite-core/         # Core types, compiler, VM, store, authoring pipeline
│   │   ├── src/authoring/      # Contracts, lints, BPMN export, publish lifecycle
│   │   ├── src/compiler/       # Parser, IR, verifier, lowering
│   │   └── migrations/         # 13 SQL migrations (ProcessStore + templates)
│   └── bpmn-lite-server/       # gRPC server (tonic), proto definitions
├── ob-poc-ui-react/            # React/TypeScript frontend (PRIMARY UI)
│   ├── src/
│   │   ├── api/                # API client modules
│   │   ├── features/           # Chat, Inspector, Settings
│   │   ├── stores/             # Zustand state
│   │   └── types/              # TypeScript types
│   └── dist/                   # Production build (served by Rust)
├── rust/
│   ├── config/verbs/           # 103 YAML verb definitions
│   ├── crates/
│   │   ├── dsl-core/           # Parser, AST, compiler (no DB)
│   │   ├── dsl-lsp/            # LSP server + Zed extension + tree-sitter grammar
│   │   ├── ob-agentic/         # Onboarding pipeline (Intent→Plan→DSL)
│   │   ├── ob-poc-macros/      # Proc macros (#[register_custom_op], #[derive(IdType)])
│   │   ├── ob-poc-web/         # Axum web server (serves React + API)
│   │   ├── inspector-projection/ # Projection schema generation
│   │   └── esper_*/            # DEPRECATED — 6 crates retained for reference
│   ├── config/packs/           # 4 pack YAML manifests (V2 REPL journeys)
│   ├── tests/golden_corpus/    # 102 test entries across 8 YAML files
│   └── src/
│       ├── repl/               # V2 REPL (vnext-repl feature flag)
│       │   ├── orchestrator_v2.rs  # 7-state machine
│       │   ├── context_stack.rs    # ContextStack fold
│       │   ├── scoring.rs          # Pack scoring + ambiguity
│       │   ├── preconditions.rs    # Precondition engine
│       │   └── ...                 # 27 files total
│       ├── journey/            # Pack system (router, manifests, handoff)
│       ├── dsl_v2/             # DSL execution
│       │   ├── custom_ops/     # Plugin handlers
│       │   └── generic_executor.rs
│       ├── domain_ops/         # CustomOperation implementations (~300+ ops)
│       ├── lexicon/            # In-memory verb/domain/concept lookup (072)
│       ├── entity_linking/     # In-memory entity resolution (073)
│       ├── sem_reg/            # Semantic Registry (Phases 0-9, 32 files)
│       │   ├── agent/          # Agent control plane (plans, decisions, MCP tools)
│       │   └── projections/    # Lineage, embeddings, coverage metrics
│       ├── session/            # Session state
│       ├── graph/              # Graph builders
│       └── api/                # REST routes
├── migrations/                 # SQLx migrations
├── docs/                       # Architecture docs
└── ai-thoughts/                # ADRs and design docs
```

---

## Environment Variables

```bash
# Required
DATABASE_URL="postgresql:///data_designer"

# LLM (for agent chat, not embeddings)
AGENT_BACKEND=anthropic
ANTHROPIC_API_KEY="sk-ant-..."

# Optional
DSL_CONFIG_DIR="/path/to/config"
BRAVE_SEARCH_API_KEY="..."       # Research macros
```

---

## Database Practices

### SQLx Compile-Time Verification

```bash
# After schema changes
psql -d data_designer -f your_migration.sql
cd rust && cargo sqlx prepare --workspace
cargo build  # Catches type mismatches
```

### Type Mapping

| PostgreSQL | Rust |
|------------|------|
| UUID | `Uuid` |
| TIMESTAMPTZ | `DateTime<Utc>` |
| INTEGER | `i32` |
| BIGINT | `i64` |
| NUMERIC | `BigDecimal` |
| NULLABLE | `Option<T>` |

---

## Error Handling

**Never use `.unwrap()` in production paths.** Use:
- `?` operator
- `.ok_or_else(|| anyhow!(...))`
- `let Some(x) = ... else { continue }`
- `match` / `if let`

---

## Trigger Phrases

When you see these in a task, read the corresponding annex first:

| Phrase | Read |
|--------|------|
| "add verb", "create verb", "verb YAML" | `docs/verb-definition-spec.md` |
| "React", "frontend", "chat UI", "scope panel" | CLAUDE.md §React Frontend |
| "entity model", "CBU", "UBO", "holdings" | `docs/strategy-patterns.md` §1 |
| "schema overview", "table structure", "ER diagram", "mermaid", "ob-poc schema" | `migrations/OB_POC_SCHEMA_ENTITY_OVERVIEW.md` |
| "agent", "MCP", "verb_search" | `docs/agent-architecture.md` |
| "session", "scope", "navigation" | `docs/session-visualization-architecture.md` |
| "ESPER", "drill", "trace", "xray" | `docs/session-visualization-architecture.md` |
| "investor register", "look-through" | `ai-thoughts/018-investor-register-visualization.md` |
| "GROUP", "ownership graph" | `ai-thoughts/019-group-taxonomy-intra-company-ownership.md` |
| "sheet", "phased execution", "DAG" | `ai-thoughts/035-repl-session-implementation-plan.md` |
| "solar navigation", "ViewState", "orbit", "nav_history" | `ai-thoughts/038-solar-navigation-unified-design.md` |
| "intent pipeline", "ambiguity", "normalize_candidates", "ref_id" | CLAUDE.md §Intent Pipeline Fixes (042) |
| "intent tier", "tier disambiguation", "what are you trying to do" | CLAUDE.md §Intent Tier Disambiguation (065) |
| "macro", "operator vocabulary", "structure.setup", "constraint cascade" | CLAUDE.md §Operator Vocabulary & Macros (058) |
| "onboarding pipeline", "RequirementPlanner", "OnboardingPlan", "ob-agentic" | CLAUDE.md §Structured Onboarding Pipeline |
| "LSP", "language server", "completion", "diagnostics", "dsl-lsp" | CLAUDE.md §DSL Language Server |
| "lexicon", "verb lookup", "domain lookup", "LexiconService" | CLAUDE.md §Lexicon Service (072) |
| "entity linking", "mention extraction", "entity resolution", "EntityLinkingService" | CLAUDE.md §Entity Linking Service (073) |
| "lookup service", "verb-first", "dual search", "LookupService" | CLAUDE.md §Unified Lookup Service (074) |
| "REPL redesign", "state machine", "V2 REPL", "ReplOrchestrator", "/api/repl" | CLAUDE.md §V2 REPL Architecture |
| "context stack", "ContextStack", "runbook fold", "DerivedScope" | CLAUDE.md §V2 REPL Architecture |
| "pack router", "PackManifest", "pack.select", "journey" | CLAUDE.md §V2 REPL Architecture |
| "scoring", "pack scoring", "dual decode", "ambiguity policy" | CLAUDE.md §V2 REPL Architecture §3-Pronged Intent Pipeline |
| "VerbSearchIntentMatcher", "IntentMatcher", "intent wiring", "3-pronged" | CLAUDE.md §V2 REPL Architecture §VerbSearchIntentMatcher |
| "preconditions", "EligibilityMode", "requires_scope" | CLAUDE.md §V2 REPL Architecture |
| "decision log", "DecisionLog", "replay tuner", "golden corpus" | CLAUDE.md §V2 REPL Architecture |
| "focus mode", "FocusMode", "domain affinity" | CLAUDE.md §V2 REPL Architecture |
| "orchestrator v2", "ReplOrchestratorV2", "session v2" | CLAUDE.md §V2 REPL Architecture |
| "compile_invocation", "compile_verb", "CompiledRunbook", "compiled_runbook_id", "runbook compilation", "RunbookStore", "StepExecutor", "write_set", "execute_runbook_with_pool" | CLAUDE.md §Runbook Compilation Pipeline, `rust/src/runbook/` |
| "invariant", "P-1", "P-2", "P-3", "P-4", "P-5" | `docs/INVARIANT-VERIFICATION.md` |
| "BPMN", "bpmn-lite", "orchestration", "fiber VM", "durable workflow" | CLAUDE.md §BPMN-Lite Durable Orchestration Service |
| "race", "WaitState::Race", "boundary timer", "race_plan", "RacePlanEntry" | CLAUDE.md §BPMN-Lite §Race Semantics (Phase 2) |
| "non-interrupting", "timer cycle", "CycleSpec", "timeCycle", "BoundaryFired", "cycle exhaustion" | CLAUDE.md §BPMN-Lite §Non-Interrupting Boundary Events (Phase 2A) |
| "ghost signal", "SignalIgnored", "WaitCancelled", "cancel_jobs", "complete_job guard" | CLAUDE.md §BPMN-Lite §Cancel & Ghost Signal Protection (Phase 3) |
| "fiber", "fiber-based execution", "two-stack separation", "EXEC_NATIVE", "durable fiber" | CLAUDE.md §Fiber-Based Execution Model |
| "WorkflowDispatcher", "JobWorker", "EventBridge", "correlation", "parked token", "bpmn_integration" | CLAUDE.md §BPMN-Lite Integration (Phase B) |
| "PendingDispatch", "pending dispatch", "queue resilience", "dispatch worker", "retry worker" | CLAUDE.md §BPMN-Lite Integration (Phase B) §Queue-Based Resilience |
| "EndTerminate", "terminate end", "error boundary", "ErrorRoute", "error_route_map", "BusinessRejection" | CLAUDE.md §BPMN-Lite §Terminate End Events / Error Boundary Routing (Phase 5) |
| "IncCounter", "BrCounterLt", "bounded loop", "retry loop", "counter" | CLAUDE.md §BPMN-Lite §Bounded Retry Loops (Phase 5.3) |
| "ForkInclusive", "JoinDynamic", "inclusive gateway", "OR gateway", "InclusiveBranch", "condition_flag" | CLAUDE.md §BPMN-Lite §Inclusive (OR) Gateway (Phase 5A) |
| "PostgresProcessStore", "store_postgres", "postgres feature", "database-url", "bpmn migrations" | CLAUDE.md §BPMN-Lite Phase 4 (PostgresProcessStore) |
| "authoring", "VerbContract", "ContractRegistry", "lint_contracts", "LintDiagnostic" | CLAUDE.md §BPMN-Lite §Authoring Pipeline (Phases B-D) |
| "export_bpmn", "dto_to_bpmn_xml", "BPMN XML export", "ir_to_dto", "round-trip" | CLAUDE.md §BPMN-Lite §Authoring Pipeline (Phases B-D) |
| "TemplateStore", "WorkflowTemplate", "publish_workflow", "compile_and_publish", "TemplateState" | CLAUDE.md §BPMN-Lite §Authoring Pipeline (Phases B-D) |
| "skeleton build", "skeleton_build_ops", "run_graph_validate", "run_ubo_compute", "run_coverage_compute", "run_outreach_plan", "run_tollgate_evaluate" | `rust/src/domain_ops/skeleton_build_ops.rs`, `KYC_SKELETON_FIXES.md` |
| "case transition", "CASE_TRANSITIONS", "KycCaseUpdateStatusOp", "update-status plugin", "is_valid_transition" | `rust/src/domain_ops/kyc_case_ops.rs`, `KYC_SKELETON_FIXES_S2.md` |
| "import run", "ImportRunBeginOp", "as_of", "idempotency", "case_import_runs" | `rust/src/domain_ops/import_run_ops.rs`, `rust/config/verbs/research/import-run.yaml` |
| "semantic registry", "sem_reg", "semantic os", "immutable snapshot", "registry service" | CLAUDE.md §Semantic OS (078-086) |
| "GovernanceTier", "TrustClass", "Proof", "Governed", "Operational" | CLAUDE.md §Semantic OS §Core Types |
| "SnapshotMeta", "SnapshotStore", "snapshot_sets", "publish gates", "gate framework" | CLAUDE.md §Semantic OS §Publish Gates |
| "AttributeDefBody", "EntityTypeDefBody", "VerbContractBody", "object type" | CLAUDE.md §Semantic OS §13 Object Types |
| "TaxonomyDef", "MembershipRule", "ViewDef", "PolicyRule", "EvidenceRequirement" | CLAUDE.md §Semantic OS §13 Object Types |
| "ABAC", "AccessDecision", "ActorContext", "AccessPurpose", "evaluate_abac" | CLAUDE.md §Semantic OS §Core Types |
| "SecurityLabel", "compute_inherited_label", "PII propagation", "classification" | CLAUDE.md §Semantic OS §Core Types |
| "DerivationSpec", "DerivationFunctionRegistry", "derived attribute" | CLAUDE.md §Semantic OS §Phase Summary |
| "resolve_context", "context resolution", "ContextResolutionRequest", "EvidenceMode" | CLAUDE.md §Semantic OS §Context Resolution API |
| "AgentPlan", "PlanStep", "DecisionRecord", "EscalationRecord", "snapshot_manifest" | CLAUDE.md §Semantic OS §Agent Control Plane |
| "sem_reg_describe", "sem_reg_search", "sem_reg_resolve_context", "sem_reg_create_plan" | CLAUDE.md §Semantic OS §MCP Tools |
| "CoverageReport", "derivation_edges", "embedding_records", "lineage", "run_records" | CLAUDE.md §Semantic OS §Projections |
| "cargo x sem-reg", "sem-reg stats", "sem-reg validate", "sem-reg ctx-resolve", "sem-reg coverage" | CLAUDE.md §Semantic OS §CLI Commands |
| "AuthoringStore", "GovernanceVerbService", "governance verb", "propose_change_set", "validate_change_set", "dry_run_change_set", "publish_snapshot_set" | CLAUDE.md §Governed Registry Authoring (v0.4) |
| "AgentMode", "Research mode", "Governed mode", "agent.set-mode", "mode gating" | CLAUDE.md §Governed Registry Authoring §AgentMode |
| "content_hash", "content-addressed", "idempotent propose", "hash_version", "canonical_hash" | CLAUDE.md §Governed Registry Authoring §Idempotency |
| "sem_reg_authoring", "validation_reports", "governance_audit_log", "publish_batches" | CLAUDE.md §Governed Registry Authoring §Database |
| "ScratchSchemaRunner", "validate_stage1", "validate_stage2", "dry_run", "V:HASH:", "D:SCHEMA:" | CLAUDE.md §Governed Registry Authoring §Validation |
| "change_sets_archive", "cleanup", "retention", "archive orphan" | CLAUDE.md §Governed Registry Authoring §Observability |
| "sem-reg propose", "sem-reg authoring-list", "sem-reg authoring-status" | CLAUDE.md §Governed Registry Authoring §CLI |
| "ContextEnvelope", "context_envelope", "CCIR", "PruneReason", "AllowedVerbSetFingerprint", "TOCTOU recheck" | CLAUDE.md §Agent Intent Pipeline Hardening §CCIR |
| "SessionVerbSurface", "verb surface", "VerbSurfaceFailPolicy", "FailClosed", "safe-harbor", "SurfaceFingerprint", "PruneLayer", "compute_session_verb_surface" | CLAUDE.md §SessionVerbSurface |
| "ECIR", "NounIndex", "noun_index", "VerbContractIndex", "noun taxonomy", "entity-centric intent" | CLAUDE.md §Navigation §Verb Search Thresholds, `rust/src/mcp/noun_index.rs`, `rust/config/noun_index.yaml` |
| "ScenarioIndex", "scenario_index", "Tier -2A", "compound intent", "scenario-based", "journey-level intent" | CLAUDE.md §Scenario-Based Intent Resolution (Phases 0.5-5), `rust/src/mcp/scenario_index.rs`, `rust/src/mcp/compound_intent.rs`, `rust/config/scenario_index.yaml` |
| "MacroIndex", "macro_index", "Tier -2B", "macro search parity" | CLAUDE.md §Scenario-Based Intent Resolution (Phases 0.5-5), `rust/src/mcp/macro_index.rs`, `rust/config/macro_search_overrides.yaml` |
| "CompoundSignals", "compound_intent", "compound signals", "compound action", "jurisdiction extraction" | CLAUDE.md §Scenario-Based Intent Resolution §ScenarioIndex Scoring Ledger, `rust/src/mcp/compound_intent.rs` |
| "SequenceValidator", "sequence_validator", "macro sequence", "prereq validation", "macro_sequence" | CLAUDE.md §Scenario-Based Intent Resolution §Scenario Route Types, `rust/src/mcp/sequence_validator.rs` |
| "provenance labels", "origin_scenario_id", "origin_macro_fqn", "progress narration" | CLAUDE.md §Scenario-Based Intent Resolution §Provenance Labels |
| "ownership.refresh", "OwnershipRefreshOp", "bridge ManCo", "derive CBU groups" | `rust/src/domain_ops/manco_ops.rs` |
| "AffinityGraph", "affinity_graph", "verb↔data index", "verbs_for_table", "data_for_verb", "adjacent_verbs", "data_footprint", "orphan_tables", "orphan_verbs", "governance_gaps", "write_only_attributes" | CLAUDE.md §AffinityGraph & Schema-Driven Diagram Generation, `rust/crates/sem_os_core/src/affinity/` |
| "DiagramModel", "MermaidRenderer", "render_erd", "render_verb_flow", "render_domain_map", "build_diagram_model", "GovernanceLevel", "TableInput", "RenderOptions", "DiagramEntity" | CLAUDE.md §AffinityGraph §DiagramModel + MermaidRenderer, `rust/crates/sem_os_core/src/diagram/` |
| "DomainMetadata", "VerbFootprint", "domain_metadata.yaml", "verb_data_footprint", "sem_os_obpoc_adapter metadata", "load_domain_metadata" | CLAUDE.md §AffinityGraph §DomainMetadata YAML Overlay, `rust/crates/sem_os_obpoc_adapter/src/metadata.rs` |
| "affinity_ops", "AffinityVerbsForTableOp", "AffinityDataForVerbOp", "AffinityGovernanceGapsOp", "registry.verbs-for-table", "registry.data-for-verb", "schema.generate-erd", "schema.generate-verb-flow" | CLAUDE.md §AffinityGraph §9 New Verbs, `rust/src/domain_ops/affinity_ops.rs` |

---

## Operator Vocabulary & Macros (058)

> ✅ **IMPLEMENTED (2026-01-28)**: Operator vocabulary layer, macro expansion, constraint cascade, DAG navigation.

**Problem Solved:** Implementation jargon (CBU, entity_ref, trading-profile) leaked to operators. Intent matching at 80%. Now operators see business terms (structure, party, mandate) and matching is 95%+.

### Architecture

```
Operator: "Set up a PE structure for Allianz"
    │
    ├─► Macro: structure.setup :type pe :name "..."
    │       │
    │       └─► Expands to: (cbu.create :kind private-equity :name "...")
    │
    └─► Constraint Cascade:
            client: Allianz → structure_type: PE → scope entity search
```

### Operator Domains (Macro Namespaces)

| Operator Domain | Wraps | Purpose |
|-----------------|-------|---------|
| `structure.*` | `cbu.*` | Fund structure operations |
| `party.*` | `entity.*` + `cbu-role.*` | People/orgs in roles |
| `case.*` | `kyc-case.*` | KYC case management |
| `mandate.*` | `trading-profile.*` | Investment mandates |

### Display Nouns (UI Never Shows Internal IDs)

| Internal | UI Shows |
|----------|----------|
| `cbu` | Structure / Client Unit |
| `entity` | Party |
| `trading-profile` | Mandate |
| `kyc-case` | Case |

### Macro Schema Example

> **IMPORTANT:** All macro YAML uses **kebab-case** for field names (`target-label`, `mode-tags`, `expands-to`).

```yaml
structure.setup:
  kind: macro
  id: structure.setup                    # Explicit ID (optional, defaults to YAML key)
  tier: composite                        # primitive | composite | template
  aliases: [setup-structure, new-fund]   # Alternative names
  taxonomy:
    domain: structure
    category: fund-setup
  docs-bundle: docs.bundle.ucits-baseline
  required-roles:
    - role: depositary
      cardinality: one
      entity-kinds: [bank, custodian]
  optional-roles:
    - role: prime-broker
      cardinality: zero-or-more
  ui:
    label: "Set up Structure"
    description: "Create a structure in the current client scope"
    target-label: "Structure"
  target:
    operates-on: client-ref
    produces: structure-ref
  args:
    required:
      structure-type:
        type: enum
        ui-label: "Type"
        values:
          - key: pe
            label: "Private Equity"
            internal: private-equity   # CRITICAL: UI key ≠ internal token
          - key: sicav
            label: "SICAV"
            internal: sicav
        default-key: pe
      depositary:
        type: party-ref
        ui-label: "Depositary"
        required-if: "structure-type = sicav"  # Conditional requirement
        placeholder-if-missing: true           # Auto-create placeholder entity
  expands-to:
    - verb: cbu.create
      args:
        kind: "${arg.structure-type.internal}"  # Uses internal token
        name: "${arg.name}"
```

### Advanced Macro Features (064)

**Conditional Expansion (`when:`):**
```yaml
expands-to:
  - when: "jurisdiction = LU"
    then:
      - verb: cbu.create
        args: { kind: "sicav", jurisdiction: "LU" }
    else:
      - verb: cbu.create
        args: { kind: "ucits" }
```

**Iteration (`foreach:`):**
```yaml
expands-to:
  - foreach: role
    in: "${required-roles}"
    do:
      - verb: party.assign
        args:
          structure-id: "${@structure}"
          role: "${role.role}"
          party-ref: "${role.party}"
```

**Condition Operators:**
- `var = value` - equality
- `var != value` - inequality
- `var in [a, b, c]` - membership
- `not: <condition>` - negation
- `any-of: [<cond1>, <cond2>]` - OR
- `all-of: [<cond1>, <cond2>]` - AND

**Conditional Requirements (`required-if:`):**
```yaml
depositary:
  type: party-ref
  required-if: "structure-type = sicav"  # Required only for SICAV
  
prime-broker:
  type: party-ref
  required-if:
    any-of:
      - "structure-type = hedge"
      - "has-prime-broker = true"
```

**Placeholder Entities (`placeholder-if-missing: true`):**
When arg is missing but `placeholder-if-missing: true`, expander generates:
```lisp
(entity.ensure-or-placeholder :kind "depositary" :ref "depositary-placeholder")
```

**Key Files:**
| File | Purpose |
|------|---------|
| `rust/src/dsl_v2/macros/schema.rs` | Schema types (`MacroSchema`, `WhenStep`, `ForEachStep`) |
| `rust/src/dsl_v2/macros/conditions.rs` | Condition evaluation for `when:` |
| `rust/src/dsl_v2/macros/expander.rs` | Macro expansion with When/ForEach/placeholder |
| `config/verb_schemas/macros/*.yaml` | Macro definitions (kebab-case) |

### Macro Lint (`cargo x verbs lint-macros`)

| Rule | Severity | What |
|------|----------|------|
| `MACRO011` | Error | UI fields required (label, description, target_label) |
| `MACRO012` | Error | Forbidden tokens in UI (cbu, entity_ref, etc.) |
| `MACRO042` | Error | No raw `entity_ref` - use `structure_ref`, `party_ref` |
| `MACRO043` | Error | `kinds:` only under `internal:` block |
| `MACRO044` | Error | Enums must use `${arg.X.internal}` in expansion |

### Constraint Cascade

```
1. CLIENT → Entities: 10,000 → 500
2. STRUCTURE TYPE → Structures: 500 → 50
3. VERB SCHEMA → Entity kinds for args
4. ENTITY → Search ONLY within scope
```

Session fields: `client`, `structure_type`, `current_structure`, `current_case`

### DAG Navigation

```
● structure.setup           ← START (ready)
  ├─► ○ structure.assign-role :role gp    (needs: setup)
  ├─► ○ structure.assign-role :role im    (needs: setup)
  └─► ○ case.open                         (needs: setup)
        └─► ○ case.approve                (needs: submit)

● = ready   ○ = blocked   ✓ = done
```

Prereq conditions: `VerbCompleted`, `AnyOf`, `StateExists`, `FactExists`

### Role Validation (Server-Side)

```yaml
role:
  type: enum
  values:
    - key: gp
      internal: general-partner
      valid-for: [pe, hedge]  # GP fails on SICAV
    - key: manco
      internal: manco
      valid-for: [sicav]      # ManCo fails on PE
```

### Key Files

| File | Purpose |
|------|---------|
| `rust/src/lint/macro_lint.rs` | MACRO000-MACRO080 lint rules |
| `rust/src/dsl_v2/macros/` | Macro registry, expander, schemas |
| `rust/src/session/unified.rs` | `UnifiedSession` with cascade context |
| `rust/src/mcp/macro_integration.rs` | DAG readiness, prereq checking |
| `config/verb_schemas/macros/` | Macro YAML definitions |

---

## Semantic OS — Immutable Registry & Context Resolution (078-091)

> ✅ **IMPLEMENTED (2026-02-16)**: 10 phases (0-9) + S1-S19 gap remediation + D1-D7/S14 peer review remediation, 39 Rust source files (~15,200 LOC), 10 SQL migrations (~1,100 LOC), ~32 MCP tools (integrated into MCP server), 12 CLI subcommands, 10 integration test scenarios + 15 invariant tests. Gap remediation: stub gate fixes, tier_allowed fix, evidence instance layer (4 tables + immutability trigger), evidence MCP realignment, unified gate framework (5 new governance gates), RelationshipTypeDef, grounding context + embedding ranking. MCP hardening patch applied (ABAC enforcement, atomic publish, deterministic IDs, drift detection, pagination fix). Peer review remediation: entity-centric attribute_observations table (D2), 4-state freshness contract (D4), edge_class + directionality on RelationshipTypeDef (D5), 4 KYC-canonical taxonomy seeds (D7), conditional membership rule evaluation in resolve_context (S14), sink disclosure severity fix (D1), document_instances lifecycle guard (D3).

**Problem Solved:** The system had no formal model for what attributes, verbs, entity types, policies, and evidence requirements exist, how they relate, or who can access them. The Semantic Registry provides an immutable, auditable, governance-aware knowledge base that the agent, runtime, and governance teams can query programmatically.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SEMANTIC REGISTRY (sem_reg)                                │
│                                                                              │
│  All 13 object types share ONE table: sem_reg.snapshots                     │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  snapshot_id (UUID) │ object_type │ object_id │ fqn │ version      │    │
│  │  governance_tier    │ trust_class │ status    │ security_label     │    │
│  │  definition (JSONB) │ created_at  │ created_by│ supersedes         │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│         │                                                                    │
│         ├─► Typed Rust structs (AttributeDefBody, VerbContractBody, ...)   │
│         ├─► Publish gates (proof rule, security, approval, version)        │
│         ├─► ABAC access control (purpose, jurisdiction, clearance)         │
│         ├─► Security label inheritance (PII propagation, classification)   │
│         └─► Point-in-time resolution (resolve_active / resolve_at)         │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Context Resolution (Phase 7)                                        │    │
│  │  12-step pipeline: subject → entity type → views → verbs →           │    │
│  │  attributes → preconditions → policies → access decisions →          │    │
│  │  governance signals → confidence score                               │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Agent Control Plane (Phase 8)                                       │    │
│  │  Plans → Steps → Decisions → Escalations                            │    │
│  │  ~32 MCP tools across 6 categories                                  │    │
│  │  Snapshot manifest provenance on every decision                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  Projections (Phase 9)                                               │    │
│  │  Lineage (derivation edges, run records, forward/reverse traversal) │    │
│  │  Embeddings (semantic text, staleness tracking)                     │    │
│  │  Metrics (coverage report, tier distribution)                       │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Non-Negotiable Invariants

1. **No in-place updates** — every change produces a new immutable snapshot
2. **Proof Rule** — only `Governed` tier objects may have `TrustClass::Proof`
3. **Security labels on both tiers** — classification, PII, jurisdictions apply regardless of governance tier
4. **Operational auto-approved** — no governed approval gates on operational-tier iteration
5. **Point-in-time resolution** — `resolve_active(type, id)` and `resolve_at(type, id, as_of)`
6. **Snapshot manifest** — every decision record pins the exact snapshot IDs it relied on

### 13 Object Types

| Object Type | Body Struct | Domain |
|-------------|-------------|--------|
| `attribute_def` | `AttributeDefBody` | Data attributes with data types, constraints, sensitivity |
| `entity_type_def` | `EntityTypeDefBody` | Entity kinds with required/optional attributes |
| `relationship_type_def` | (JSONB) | Relationship types between entity types |
| `verb_contract` | `VerbContractBody` | Verb preconditions, postconditions, required attributes |
| `taxonomy_def` | `TaxonomyDefBody` | Taxonomy trees (hierarchical classification) |
| `taxonomy_node` | `TaxonomyNodeBody` | Individual nodes within a taxonomy |
| `membership_rule` | `MembershipRuleBody` | Rules governing taxonomy membership |
| `view_def` | `ViewDefBody` | View definitions (verb surface + attribute prominence) |
| `policy_rule` | `PolicyRuleBody` | Policy rules with conditions and verdicts |
| `evidence_requirement` | `EvidenceRequirementBody` | Evidence freshness and source requirements |
| `document_type_def` | `DocumentTypeDefBody` | Document type classification |
| `observation_def` | `ObservationDefBody` | Observation recording templates |
| `derivation_spec` | `DerivationSpecBody` | Derived/composite attribute computation specs |

### Core Types

```rust
// Governance tier — determines workflow rigour, NOT security posture
enum GovernanceTier { Governed, Operational }

// Trust class — Proof only valid when governance_tier = Governed
enum TrustClass { Proof, DecisionSupport, Convenience }

// Snapshot lifecycle
enum SnapshotStatus { Draft, Active, Deprecated, Retired }

// Change type for transitions
enum ChangeType { Created, NonBreaking, Breaking, Promotion, Deprecation, Retirement }

// Security label (on every snapshot)
struct SecurityLabel {
    classification: Classification,  // Public, Internal, Confidential, Restricted
    pii: bool,
    jurisdictions: Vec<String>,
    handling_controls: Vec<HandlingControl>,
}

// ABAC access control
struct ActorContext {
    actor_type: ActorType,  // Agent, Analyst, Governance, System
    roles: Vec<String>,
    clearance: Classification,
    purpose: AccessPurpose,
    jurisdiction: Option<String>,
}
enum AccessDecision { Allow, Deny { reason }, AllowWithConstraints { constraints } }
```

### Phase Summary

| Phase | Migration | Module | Key Deliverable |
|-------|-----------|--------|-----------------|
| **0** | 078 | `types`, `store`, `gates` | Schema, `snapshots` + `snapshot_sets` tables, core enums, publish gate functions |
| **1** | 079 | `attribute_def`, `entity_type_def`, `verb_contract`, `registry`, `scanner` | Body types, `RegistryService`, verb-first YAML scanner, convenience views |
| **2** | 081 | `taxonomy_def`, `membership`, `view_def` | Taxonomy trees/nodes, membership rules, view definitions |
| **3** | 082 | `policy_rule`, `evidence`, `observation_def`, `document_type_def`, `abac` | Policy engine, evidence requirements, ABAC access control |
| **4** | 083 | `security` | Security label inheritance (PII propagation), label compatibility checks |
| **5** | 083 | `derivation`, `derivation_spec` | Derived/composite attributes, `DerivationFunctionRegistry` |
| **6** | — | `gates_governance`, `gates_technical` | Extended publish gate framework (severity, gate modes, gate chain), 5 new governance gates (S6) |
| **7** | 084 | `context_resolution` | 12-step `resolve_context()` pipeline, evidence modes, governance signals, taxonomy-based verb/attribute filtering (S15) |
| **8** | 085 | `agent/` (5 files) | Agent plans/steps/decisions/escalations, ~32 MCP tools, snapshot manifest |
| **9** | 086 | `projections/` (4 files) | Lineage (derivation edges, run records), embeddings (with grounding context + similarity ranking, S18), coverage metrics |
| **Evidence** | 090 | `evidence_instances` | Observations, document instances, provenance edges, retention policies, immutability trigger on snapshots (S4-S5) |
| **Peer Review** | 091 | `evidence_instances`, `context_resolution`, `gates_technical`, `relationship_type_def`, `seeds/taxonomy_seeds` | Entity-centric `attribute_observations` table (D2), 4-state freshness contract (D4), edge_class + directionality (D5), 4 KYC taxonomy seeds (D7), conditional membership eval (S14), sink disclosure severity (D1), document_instances lifecycle guard (D3) |

### Context Resolution API (Phase 7)

The `resolve_context()` function returns ranked verbs, attributes, views, policy verdicts, and governance signals for a given subject + actor + goal.

```rust
// Request
struct ContextResolutionRequest {
    subject: SubjectRef,              // CaseId | EntityId | DocumentId | TaskId | ViewId
    intent: Option<String>,
    actor: ActorContext,
    goals: Vec<String>,
    constraints: ResolutionConstraints,
    evidence_mode: EvidenceMode,      // Strict | Normal | Exploratory | Governance
    point_in_time: Option<DateTime<Utc>>,
}

// Response
struct ContextResolutionResponse {
    as_of_time: DateTime<Utc>,
    applicable_views: Vec<ViewCandidate>,
    candidate_verbs: Vec<VerbCandidate>,
    candidate_attributes: Vec<AttributeCandidate>,
    required_preconditions: Vec<PreconditionStatus>,
    disambiguation_questions: Vec<String>,
    evidence: Vec<EvidenceItem>,
    policy_verdicts: Vec<PolicyVerdict>,
    security_handling: SecurityHandling,
    governance_signals: Vec<GovernanceSignal>,
    confidence: f64,
}
```

**12-Step Pipeline:**
1. Determine snapshot epoch (point_in_time or now)
2. Resolve subject → entity type + jurisdiction + state
3. Select applicable ViewDefs by taxonomy overlap
4. Extract verb surface + attribute prominence from top view
5. Filter verbs by taxonomy membership + ABAC
6. Filter attributes similarly
7. Rank by ViewDef prominence weights
8. Evaluate preconditions for top-N candidate verbs
9. Evaluate PolicyRules → PolicyVerdicts with snapshot refs
10. Compute composite AccessDecision
11. Generate governance signals (unowned objects, stale evidence)
12. Compute confidence score (deterministic heuristic)

**Evidence Modes:**
- `Strict`/`Normal`: Only Governed + Proof/DecisionSupport primary. Operational only if view allows, tagged `usable_for_proof = false`
- `Exploratory`: All tiers, annotated with governance tier
- `Governance`: Coverage metrics focus

### Agent Control Plane (Phase 8)

Plans, decisions, and escalations — all pinning snapshot IDs for full provenance.

**Key Types:**

| Type | Purpose |
|------|---------|
| `AgentPlan` | Plan with goal, steps, assumptions, risk flags, security clearance |
| `PlanStep` | Step pinning `verb_id` + `verb_snapshot_id`, with params, postconditions, fallbacks |
| `DecisionRecord` | Decision with `snapshot_manifest` (HashMap<Uuid, Uuid> — complete provenance chain) |
| `EscalationRecord` | Human escalation with reason, context snapshot, required action |
| `DisambiguationPrompt` | Disambiguation prompt with options and selected choice |

**Status State Machines:**
- Plan: `Draft → Active → Completed | Failed | Cancelled`
- Step: `Pending → Running → Completed | Failed | Skipped`

**~32 MCP Tools (6 categories):**

| Category | Tools | Purpose |
|----------|-------|---------|
| Registry query | `sem_reg_describe_attribute`, `_verb`, `_entity_type`, `_policy`, `_search`, `_list_verbs`, `_list_attributes` | Read-only registry lookup |
| Taxonomy | `sem_reg_taxonomy_tree`, `_members`, `_classify` | Taxonomy navigation |
| Impact/lineage | `sem_reg_verb_surface`, `_attribute_producers`, `_impact_analysis`, `_lineage`, `_regulation_trace` | Dependency and provenance queries |
| Context resolution | `sem_reg_resolve_context`, `_describe_view`, `_apply_view` | Context resolution pipeline |
| Planning/decisions | `sem_reg_create_plan`, `_add_plan_step`, `_validate_plan`, `_execute_plan_step`, `_record_decision`, `_record_escalation`, `_record_disambiguation` | Agent planning and recording |
| Evidence | `sem_reg_record_observation`, `_check_evidence_freshness`, `_identify_evidence_gaps` | Evidence management |

### Projections (Phase 9)

**Lineage:** Derivation edges + run records for forward impact analysis ("if this changes, what is affected?") and reverse provenance ("where did this value come from?").

**Embeddings:** Semantic text generation from FQN + description + aliases + taxonomy paths. Staleness tracking compares `version_hash` against current snapshot.

**Coverage Metrics:**

```rust
struct CoverageReport {
    classification_coverage_pct: f64,
    stewardship_coverage_pct: f64,
    policy_attachment_pct: f64,
    evidence_freshness_pct: f64,
    retention_compliance: f64,
    security_label_completeness_pct: f64,
    proof_rule_compliance: f64,
    tier_distribution: TierDistribution,
    snapshot_volume: i64,
}
```

### CLI Commands

```bash
cd rust/

# Registry overview
cargo x sem-reg stats                     # Counts by object type
cargo x sem-reg validate [--enforce]      # Run publish gates on all active snapshots

# Object inspection
cargo x sem-reg attr-describe <fqn>       # e.g., "cbu.jurisdiction_code"
cargo x sem-reg attr-list [-n 100]        # List active attribute definitions
cargo x sem-reg entity-type-describe <fqn>
cargo x sem-reg verb-describe <fqn>       # e.g., "cbu.create"
cargo x sem-reg verb-list [-n 100]
cargo x sem-reg derivation-describe <fqn>
cargo x sem-reg history <type> <fqn>      # Snapshot history for an object

# Bootstrap & maintenance
cargo x sem-reg scan [--dry-run] [-v]     # Scan verb YAML → bootstrap registry snapshots
cargo x sem-reg backfill-labels [--dry-run] # Backfill security labels on existing snapshots

# Phase 7: Context resolution
cargo x sem-reg ctx-resolve --subject <uuid> --subject-type <case|entity|view> \
    --actor <agent|analyst|governance> --mode <strict|normal|exploratory|governance> \
    [--as-of <ISO8601>] [--json]

# Phase 8: MCP tool listing
cargo x sem-reg agent-tools               # List all ~32 MCP tools with descriptions

# Phase 9: Coverage metrics
cargo x sem-reg coverage [--tier governed|operational|all] [--json]
```

### Database Schema (sem_reg)

**Core Tables (Phase 0):**

| Table | Purpose |
|-------|---------|
| `sem_reg.snapshots` | Universal immutable snapshot table (all 13 object types) |
| `sem_reg.snapshot_sets` | Named grouping of snapshots for atomic publish |

**Agent Tables (Phase 8):**

| Table | Purpose |
|-------|---------|
| `sem_reg.agent_plans` | Immutable INSERT-only plans with goal + context_resolution_ref |
| `sem_reg.plan_steps` | Steps with verb_id/verb_snapshot_id pinning, status mutable |
| `sem_reg.decision_records` | Immutable decisions with snapshot_manifest JSONB |
| `sem_reg.disambiguation_prompts` | Immutable disambiguation prompts |
| `sem_reg.escalation_records` | Human escalation records (INSERT + UPDATE on resolution) |

**Projection Tables (Phase 9):**

| Table | Purpose |
|-------|---------|
| `sem_reg.derivation_edges` | Immutable append-only lineage edges |
| `sem_reg.run_records` | Immutable derivation run records |
| `sem_reg.embedding_records` | Versioned embeddings with staleness tracking |

**Key Views (Phases 1-9):**

| View | Purpose |
|------|---------|
| `sem_reg.v_active_attribute_defs` | Active attribute definitions (flattened from JSONB) |
| `sem_reg.v_active_entity_type_defs` | Active entity type definitions |
| `sem_reg.v_active_verb_contracts` | Active verb contracts |
| `sem_reg.v_active_taxonomy_defs` | Active taxonomy definitions |
| `sem_reg.v_active_taxonomy_nodes` | Active taxonomy nodes |
| `sem_reg.v_active_membership_rules` | Active membership rules |
| `sem_reg.v_active_view_defs` | Active view definitions |
| `sem_reg.v_active_policy_rules` | Active policy rules |
| `sem_reg.v_active_evidence_reqs` | Active evidence requirements |
| `sem_reg.v_active_document_type_defs` | Active document type definitions |
| `sem_reg.v_active_observation_defs` | Active observation definitions |
| `sem_reg.v_active_derivation_specs` | Active derivation specs |
| `sem_reg.v_registry_stats` | Object counts by type and status |
| `sem_reg.v_active_memberships_by_subject` | Fast taxonomy overlap lookup (Phase 7) |
| `sem_reg.v_verb_precondition_status` | Precondition evaluability check (Phase 7) |
| `sem_reg.v_view_attribute_columns` | View attribute columns (Phase 7) |
| `sem_reg.v_stale_embeddings` | Stale embeddings needing refresh (Phase 9) |
| `sem_reg.v_lineage_summary` | Lineage summary (Phase 9) |
| `sem_reg.v_run_performance` | Run performance metrics (Phase 9) |

### Publish Gates

Every snapshot must pass publish gates before transitioning to `Active`:

| Gate | Phase | Description |
|------|-------|-------------|
| Proof Rule | 0 | `TrustClass::Proof` requires `GovernanceTier::Governed` |
| Security Label | 0 | Label must be present and valid |
| Governed Approval | 0 | Governed-tier objects require approval workflow |
| Version Monotonicity | 0 | Version must increase on supersede |
| Extended Framework | 6 | Pluggable gate chain with `GateMode` (Strict/Lenient/ReportOnly) and `GateSeverity` (Error/Warning/Info) |

### Integration Tests (Phase 10)

10 test scenarios in `rust/tests/sem_reg_integration.rs` + 15 invariant tests in `rust/tests/sem_reg_invariants.rs` (all `#[cfg(feature = "database")]` + `#[ignore]`):

**Integration Scenarios:**

1. **UBO Discovery E2E** — resolve_context → create_plan → identify_evidence_gaps → add_plan_steps → validate_plan → execute → record_decision → verify snapshot_manifest
2. **Sanctions Screening ABAC** — ABAC restricts sanctions-labelled attributes to SANCTIONS purpose actors
3. **Proof Collection Lineage** — Evidence freshness checks, observation supersession chains
4. **Governance Review** — Governance mode → coverage_report → drill-down → regulation_trace
5. **Point-in-Time Audit** — Publish → advance time → supersede → resolve_context(as_of=earlier) → verify pinned snapshots
6. **Proof Rule Enforcement** — Governed PolicyRule + Operational attribute → must fail. Operational evidence for Proof claim → must fail
7. **Security/ABAC E2E** — Purpose mismatch → Deny. Jurisdiction mismatch → Deny. PII+Financial inputs → inherited Confidential label
8. **Onboarding Pipeline Round-Trip** — Full 6-step onboarding: entity_type → attributes → verb_contracts → taxonomy placement → view assignment → evidence requirements
9. **Gate Unification** — Proof rule blocks publish; taxonomy warning does NOT block; ReportOnly mode allows all
10. **Taxonomy Filtering in Context Resolution** — Verbs filtered by taxonomy membership overlap; unconstrained verbs pass through

**Invariant Tests (15):** INV-1 (no in-place updates), INV-2 (snapshot pinning), INV-3 (proof rule), INV-4 (ABAC both tiers), INV-5 (operational auto-approve), INV-6 (derivation spec required), plus gate, evidence, and context resolution invariants.

```bash
# Integration tests
DATABASE_URL="postgresql:///data_designer" \
  cargo test --features database --test sem_reg_integration -- --ignored --nocapture

# Invariant tests
DATABASE_URL="postgresql:///data_designer" \
  cargo test --features database --test sem_reg_invariants -- --ignored --nocapture
```

### Module Structure

```
rust/src/sem_reg/
├── mod.rs                      # Module root, re-exports
├── types.rs                    # Core enums, SecurityLabel, SnapshotMeta
├── store.rs                    # SnapshotStore DB operations
├── ids.rs                      # Deterministic UUID v5 object IDs
├── enforce.rs                  # ABAC enforcement helpers (enforce_read)
├── gates.rs                    # Publish gate pure functions (unified framework)
├── attribute_def.rs            # AttributeDefBody
├── entity_type_def.rs          # EntityTypeDefBody
├── verb_contract.rs            # VerbContractBody
├── registry.rs                 # RegistryService typed publish/resolve
├── scanner.rs                  # Verb YAML → registry bootstrap + drift detection
├── evidence_instances.rs       # Evidence instance layer (S4): Observation, AttributeObservation (D2), DocumentInstance, ProvenanceEdge, RetentionPolicy
├── taxonomy_def.rs             # TaxonomyDefBody, TaxonomyNodeBody
├── membership.rs               # MembershipRuleBody
├── view_def.rs                 # ViewDefBody (+ includes_operational field, S3)
├── policy_rule.rs              # PolicyRuleBody
├── evidence.rs                 # EvidenceRequirementBody
├── observation_def.rs          # ObservationDefBody
├── document_type_def.rs        # DocumentTypeDefBody
├── derivation_spec.rs          # DerivationSpecBody
├── abac.rs                     # ABAC evaluate, AccessDecision
├── security.rs                 # Security label inheritance
├── derivation.rs               # DerivationFunctionRegistry, evaluation
├── gates_governance.rs         # 8 governance gates (3 original + 5 added in S6)
├── gates_technical.rs          # Technical gates: type_correctness, verb_surface_disclosure (fixed S2), sink disclosure severity (D1)
├── context_resolution.rs       # 12-step resolve_context() with taxonomy filtering (S15), tier_allowed fix (S3), relationship-aware ranking (D5), conditional membership eval (S14)
├── agent/
│   ├── mod.rs                  # Agent module root
│   ├── plans.rs                # AgentPlan, PlanStep, PlanStore
│   ├── decisions.rs            # DecisionRecord, DecisionStore
│   ├── escalation.rs           # EscalationRecord, DisambiguationPrompt
│   └── mcp_tools.rs            # ~32 MCP tool specs + dispatch + grounding context (S18)
└── projections/
    ├── mod.rs                  # Projections module root
    ├── lineage.rs              # DerivationEdge, RunRecord, graph traversal
    ├── embeddings.rs           # SemanticText, EmbeddingRecord, staleness + similarity ranking (S18)
    └── metrics.rs              # CoverageReport, TierDistribution
```

### Key Files

| File | Purpose |
|------|---------|
| `rust/src/sem_reg/mod.rs` | Module root with re-exports |
| `rust/src/sem_reg/types.rs` | Re-exports canonical enums from `sem_os_core::types` + `PgSnapshotRow` sqlx adapter with `TryFrom` conversion |
| `rust/src/sem_reg/store.rs` | `SnapshotStore` — INSERT-only + supersede DB ops |
| `rust/src/sem_reg/gates.rs` | `evaluate_publish_gates()` — pure functions |
| `rust/src/sem_reg/registry.rs` | `RegistryService` — typed publish/resolve for all 13 types |
| `rust/src/sem_reg/context_resolution.rs` | `resolve_context()` — 12-step pipeline |
| `rust/src/sem_reg/agent/mcp_tools.rs` | `all_tool_specs()` + `dispatch_tool()` — ~32 MCP tools |
| `rust/src/sem_reg/agent/plans.rs` | `AgentPlan`, `PlanStep`, `PlanStore` |
| `rust/src/sem_reg/agent/decisions.rs` | `DecisionRecord`, `DecisionStore` |
| `rust/src/sem_reg/projections/lineage.rs` | Forward/reverse lineage traversal |
| `rust/src/sem_reg/projections/metrics.rs` | `CoverageReport` computation |
| `rust/src/sem_reg/scanner.rs` | Verb YAML bootstrap → registry snapshots |
| `rust/src/sem_reg/abac.rs` | `evaluate_abac()` — ABAC access control |
| `rust/src/sem_reg/security.rs` | `compute_inherited_label()` — PII propagation |
| `rust/xtask/src/sem_reg.rs` | CLI subcommands (stats, validate, ctx-resolve, etc.) |
| `rust/src/sem_reg/ids.rs` | Deterministic UUID v5 object IDs |
| `rust/src/sem_reg/enforce.rs` | ABAC enforcement helpers (`enforce_read()`) |
| `rust/src/sem_reg/evidence_instances.rs` | Evidence instance types + store methods (S4), AttributeObservation entity-centric model (D2) |
| `rust/src/sem_reg/seeds/taxonomy_seeds.rs` | 9 taxonomy seeds (5 domain + 4 KYC-canonical: subject-category, risk-tier, document-class, jurisdiction-regime) |
| `rust/tests/sem_reg_integration.rs` | 10 integration test scenarios |
| `rust/tests/sem_reg_invariants.rs` | 15 invariant tests (INV-1 through INV-6 + extensions) |
| `migrations/078_sem_reg_phase0.sql` | Core schema, `snapshots` table, enums |
| `migrations/085_sem_reg_phase8.sql` | Agent tables (plans, steps, decisions) |
| `migrations/086_sem_reg_phase9.sql` | Projection tables (lineage, embeddings) |
| `migrations/090_sem_reg_evidence_instances.sql` | Evidence tables + snapshots immutability trigger (S4) |
| `migrations/091_sem_reg_evidence_fixes.sql` | Entity-centric `attribute_observations` table (D2), `document_instances` lifecycle guard trigger (D3) |

---

### Peer Review Remediation (D1-D7/S14, 2026-02-16)

Fixes validated against external peer review of S1-S19 implementation:

| Fix | Priority | Files | Description |
|-----|----------|-------|-------------|
| **D1** | P1 | `gates_technical.rs` | Sink disclosure severity: undisclosed sinks `warning()` → `error()`. Sources remain `warning()`. |
| **D2** | P0 | migration 091, `evidence_instances.rs`, `mcp_tools.rs` | Entity-centric `attribute_observations` table alongside snapshot-centric `observations`. New `AttributeObservation` struct + 3 store methods. MCP handlers dual-path: `subject_ref` present → attribute_observations, absent → observations. |
| **D3** | P2 | migration 091 | `document_instances` lifecycle guard trigger (immutable field protection on UPDATE, no DELETE). |
| **D4** | P0 | `mcp_tools.rs` | 4-state freshness contract replacing binary true/false: `unknown_no_policy`, `unknown_no_observation`, `stale`, `fresh`. `stale_count` only counts actual stale items. |
| **D5** | P0 | `relationship_type_def.rs`, `context_resolution.rs` | `edge_class: Option<String>` + `directionality: Option<Directionality>` on `RelationshipTypeDefBody`. Step 2c in resolve_context() loads subject relationships. Verb ranking boosted by domain (+0.08) and edge_class (+0.07) overlap. |
| **D7** | P0 | `seeds/taxonomy_seeds.rs` | 4 KYC-canonical taxonomy seeds: subject-category (6 nodes), risk-tier (5 nodes), document-class (6 nodes), jurisdiction-regime (6 nodes). Added alongside existing 5 domain seeds. |
| **S14** | P0 | `context_resolution.rs` | Conditional membership rule evaluation in `load_subject_memberships()`. Loads `MembershipRuleBody` conditions, evaluates at resolution time. Runtime-dependent conditions (attribute_equals, entity_has_role) conservatively excluded from overlap scoring. |

**Not fixed (validated as non-defects):** D6 (gates exist + wired + tested), D8 (serde tags correct, seeds use Rust structs not YAML), D9 (always-on audit deferred).

---

### MCP Integration & Hardening (2026-02-14)

Correctness and safety improvements applied across the Semantic OS:

| Fix | Files | Description |
|-----|-------|-------------|
| **MCP tool surface** | `mcp/tools_sem_reg.rs`, `mcp/tools.rs`, `mcp/handlers/core.rs` | 29 sem_reg tools now appear in MCP `tools/list` and dispatch via `tools/call`. Single tool surface. |
| **ABAC enforcement** | `sem_reg/enforce.rs`, `sem_reg/agent/mcp_tools.rs` | All tool reads check ABAC via `enforce_read()`. Denied snapshots return redacted stubs. |
| **Atomic publish** | `sem_reg/store.rs` | `publish_snapshot()` wraps supersede + insert in a single transaction. Failed insert rolls back supersede. |
| **Deterministic IDs** | `sem_reg/ids.rs`, `sem_reg/scanner.rs` | Object IDs use UUID v5 (deterministic from `object_type:fqn`). Same YAML on any machine produces same IDs. |
| **Drift detection** | `sem_reg/scanner.rs` | Scanner compares definition hashes on re-scan. Changed definitions publish successor snapshots instead of being silently skipped. |
| **Pagination fix** | `sem_reg/context_resolution.rs` | `load_typed_snapshots()` paginates instead of truncating at LIMIT 1000. |
| **Stable serialization** | `sem_reg/scanner.rs` | Replaced 7 `format!("{:?}").to_lowercase()` calls with `to_wire_str()` using serde rename attributes. |
| **Immutable backfill** | `xtask/src/sem_reg.rs` | `backfill_labels()` publishes successor snapshots instead of in-place UPDATEs. |

**New files:** `sem_reg/ids.rs`, `sem_reg/enforce.rs`, `mcp/tools_sem_reg.rs`
**New tests:** 16 unit tests (6 ids + 6 enforce + 4 tools_sem_reg bridge)

---

## Semantic OS v1.1 — Standalone Service Architecture

> **Status:** ✅ Complete (2026-02-18) — Stages 1-4 implemented. Harness green in inprocess mode.
> **Type Unification:** ✅ Complete (2026-02-27) — Canonical enums in `sem_os_core`, monolith re-exports + `PgSnapshotRow` sqlx adapter, `BootstrapAuditStore` port trait, stewardship module refactor, server `PgPool` removal.
> **Stewardship:** ✅ Complete (2026-02-25) — Phase 0 (Changeset Layer) + Phase 1 (Show Loop). 23 MCP tools, 15 guardrails, REST+SSE.
> **Schema Visibility:** ✅ Complete (2026-02-25) — `db_introspect` MCP tool + `AttributeSource` real (schema, table, column) triples.

**Problem Solved:** The original Semantic OS (v1.0, `rust/src/sem_reg/`) was deeply embedded in the ob-poc monolith. v1.1 extracts it into a standalone service with its own crate workspace, REST API, outbox-driven projections, changeset workflow, and client SDK. The Stewardship Agent adds a changeset-based authoring layer for governed registry changes.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  ob-poc (main application)                                                   │
│       │                                                                       │
│       └─► SemOsClient trait (rust/crates/sem_os_client/)                     │
│               │                                                               │
│               ├─► InProcessClient (default: SEM_OS_MODE=inprocess)           │
│               │       └─► CoreService (sem_os_core) ─► PgSnapshotStore       │
│               │                                                               │
│               └─► HttpClient (SEM_OS_MODE=remote)                            │
│                       └─► REST API (sem_os_server) + JWT bearer              │
│                                                                               │
│  Stewardship Layer (rust/src/sem_reg/stewardship/)                           │
│       │                                                                       │
│       ├─► Changeset Workflow: Draft → UnderReview → Approved → Published     │
│       ├─► 15 Guardrails (G01-G15): role, proof chain, classification, etc.  │
│       ├─► Show Loop: Focus → Read → Propose → Show → Refine → (loop)       │
│       └─► 4 Viewports: Focus Summary, Object Inspector, Diff, Gates         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Crate Structure

| Crate | Purpose | Key Export |
|-------|---------|-----------|
| `sem_os_core` | Core domain: canonical types (enums, `SnapshotMeta`, `SnapshotRow`), ports (8 traits), service logic, gates, stewardship guardrails, ABAC, security labels | `CoreService` trait, `Principal`, `SnapshotMeta` |
| `sem_os_postgres` | PostgreSQL store implementations (8 adapters implementing port traits) | `PgStores` convenience constructor |
| `sem_os_server` | Axum REST server with JWT auth, CORS, outbox dispatcher, 12 routes (no raw `PgPool` dependency) | `build_router()` |
| `sem_os_client` | `SemOsClient` trait + `InProcessClient` + `HttpClient` | `SemOsClient` trait (sole API boundary) |
| `sem_os_harness` | Integration test harness (isolated DB per run, 3 suites) | `run_core_scenario_suite()` |
| `sem_os_obpoc_adapter` | Verb YAML → seed bundles, scanner with CRUD/entity-type resolution | `build_seed_bundle()` |

### Key Design Patterns

- **Port-trait isolation**: Core depends on traits only (`SnapshotStore`, `ChangesetStore`, `OutboxStore`, `AuditStore`, `EvidenceInstanceStore`, `ProjectionWriter`, `ObjectStore`, `BootstrapAuditStore`). Never imports sqlx directly.
- **Type unification**: Canonical enum types (`GovernanceTier`, `TrustClass`, `SnapshotStatus`, `ChangeType`, `ObjectType`, `SecurityLabel`, `SnapshotMeta`, `SnapshotRow`) defined once in `sem_os_core::types`. Monolith re-exports from core + provides `PgSnapshotRow` sqlx adapter with `TryFrom` conversion. `ChangesetStatus` unified: 9-state `ChangeSetStatus` from authoring module re-exported as the single canonical type.
- **Explicit Principal**: Every method takes `&Principal` — no implicit identity, no thread-local context. ABAC, role checks, and audit all use the explicit principal.
- **Immutable snapshots + outbox**: Every publish = snapshot INSERT + outbox enqueue in single tx. Outbox dispatcher claims → projects → advances watermark.
- **Atomic publish gates**: All gates evaluated BEFORE any persistence. Gate failure = zero DB changes.
- **Deterministic seed bundles**: `bundle_hash = SHA-256(canonical_json(all seeds))`. Same YAML → same hash → idempotent re-bootstrap.
- **Changeset workflow**: Draft → UnderReview → Approved → Published. Gate preview before publish. Stewardship guardrails enforce role constraints, proof chain compatibility, and stale draft detection.
- **Strum-based enums**: All core enums (`GovernanceTier`, `TrustClass`, `SnapshotStatus`, `ChangeType`, `ObjectType`, `Classification`, `ChangeSetStatus`, `ArtifactType`, `AgentMode`) use `strum` derives (`Display`, `EnumString`, `AsRefStr`) with `#[strum(serialize_all = "snake_case")]` — eliminates manual `as_str()`/`from_str()`/`Display` impls.
- **`#[must_use]` on result types**: `GateResult`, `ValidationReport`, `DryRunReport` — decision types that must not be silently discarded.

### CoreService Trait

```rust
pub trait CoreService: Send + Sync {
    // Core operations
    async fn resolve_context(&self, principal: &Principal, req: ContextResolutionRequest) -> Result<ContextResolutionResponse>;
    async fn get_manifest(&self, snapshot_set_id: &str) -> Result<GetManifestResponse>;
    async fn export_snapshot_set(&self, snapshot_set_id: &str) -> Result<ExportSnapshotSetResponse>;
    async fn bootstrap_seed_bundle(&self, principal: &Principal, bundle: SeedBundle) -> Result<BootstrapSeedBundleResponse>;
    async fn dispatch_tool(&self, principal: &Principal, req: ToolCallRequest) -> Result<ToolCallResponse>;
    async fn list_tool_specs(&self) -> Result<ListToolSpecsResponse>;
    // Changeset workflow
    async fn promote_changeset(&self, principal: &Principal, changeset_id: &str) -> Result<u32>;
    async fn list_changesets(&self, query: ListChangesetsQuery) -> Result<ListChangesetsResponse>;
    async fn changeset_diff(&self, changeset_id: &str) -> Result<ChangesetDiffResponse>;
    async fn changeset_impact(&self, changeset_id: &str) -> Result<ChangesetImpactResponse>;
    async fn changeset_gate_preview(&self, changeset_id: &str) -> Result<GatePreviewResponse>;
    // Authoring pipeline (governance verbs)
    async fn authoring_propose(&self, principal: &Principal, bundle: &BundleContents) -> Result<ChangeSetFull>;
    async fn authoring_validate(&self, change_set_id: Uuid) -> Result<ValidationReport>;
    async fn authoring_dry_run(&self, change_set_id: Uuid) -> Result<DryRunReport>;
    async fn authoring_plan_publish(&self, change_set_id: Uuid) -> Result<PublishPlan>;
    async fn authoring_publish(&self, change_set_id: Uuid, publisher: &str) -> Result<PublishBatch>;
    async fn authoring_publish_batch(&self, change_set_ids: &[Uuid], publisher: &str) -> Result<PublishBatch>;
    async fn authoring_diff(&self, base_id: Uuid, target_id: Uuid) -> Result<DiffSummary>;
    async fn authoring_list(&self, status: Option<ChangeSetStatus>, limit: i64) -> Result<Vec<ChangeSetFull>>;
    async fn authoring_get(&self, change_set_id: Uuid) -> Result<ChangeSetFull>;
    // Authoring health
    async fn authoring_health_pending(&self) -> Result<PendingChangeSetsHealth>;
    async fn authoring_health_stale_dryruns(&self) -> Result<StaleDryRunsHealth>;
    async fn authoring_run_cleanup(&self, policy: &CleanupPolicy) -> Result<CleanupReport>;
    // Bootstrap audit (idempotent seed bundle tracking)
    async fn bootstrap_check(&self, bundle_hash: &str) -> Result<Option<(String, Option<Uuid>)>>;
    async fn bootstrap_start(&self, bundle_hash: &str, actor_id: &str, bundle_counts: serde_json::Value) -> Result<()>;
    async fn bootstrap_mark_published(&self, bundle_hash: &str) -> Result<()>;
    async fn bootstrap_mark_failed(&self, bundle_hash: &str, error: &str) -> Result<()>;
}
```

### REST API (sem_os_server)

**Protected routes (JWT required):**

| Method | Route | Purpose |
|--------|-------|---------|
| POST | `/resolve_context` | 12-step context resolution pipeline |
| GET | `/snapshot_sets/{id}/manifest` | Snapshot set manifest |
| POST | `/publish` | Admin publish (gates enforcement) |
| GET | `/exports/snapshot_set/{id}` | Export snapshot set |
| POST | `/bootstrap/seed_bundle` | Idempotent seed bootstrap |
| GET | `/authoring` | List ChangeSets (with status filter) |
| POST | `/authoring/propose` | Propose new ChangeSet from bundle |
| POST | `/authoring/publish-batch` | Batch publish (topological sort) |
| POST | `/authoring/diff` | Diff two ChangeSets |
| GET | `/authoring/{id}` | Get ChangeSet detail |
| POST | `/authoring/{id}/validate` | Run Stage 1 validation |
| POST | `/authoring/{id}/dry-run` | Run Stage 2 dry-run |
| GET | `/authoring/{id}/plan` | Plan publish (diff preview) |
| POST | `/authoring/{id}/publish` | Publish to active snapshot set (requires Governed + admin) |
| GET | `/changesets` | List changesets |
| GET | `/changesets/{id}/diff` | Changeset diff |
| GET | `/changesets/{id}/impact` | Impact analysis |
| POST | `/changesets/{id}/gate_preview` | Gate pre-check |
| POST | `/changesets/{id}/publish` | Promote changeset |

**Public routes (no auth):**

| Method | Route | Purpose |
|--------|-------|---------|
| GET | `/health` | Health check |
| GET | `/health/semreg/pending-changesets` | Pending ChangeSet counts by status |
| GET | `/health/semreg/stale-dryruns` | Stale dry-run detection |

> **Deferred:** `/tools/call` and `/tools/list` routes removed pending finalized tool schemas.

### Stewardship Agent (Phase 0-1)

> ✅ **IMPLEMENTED (2026-02-25)**: Changeset layer + Show Loop. 23 MCP tools, 15 guardrails, REST+SSE.

**Phase 0: Changeset Layer (17 MCP tools)**

| Category | Tools |
|----------|-------|
| Compose | `stew_compose_changeset`, `stew_add_item`, `stew_remove_item`, `stew_refine_item` |
| Evidence | `stew_attach_basis`, `stew_resolve_conflict` |
| Workflow | `stew_submit_for_review`, `stew_record_review_decision`, `stew_approve_changeset`, `stew_publish_changeset` |
| Query | `stew_list_changesets`, `stew_describe_changeset`, `stew_compute_impact`, `stew_list_conflicts`, `stew_check_idempotency` |
| Suggest | `stew_suggest` |

**Phase 1: Show Loop (6 MCP tools)**

| Tool | Purpose |
|------|---------|
| `stew_get_focus` | Get current FocusState |
| `stew_set_focus` | Set FocusState (emits FocusChanged event) |
| `stew_show` | Trigger ShowPacket computation |
| `stew_get_viewport` | Compute single viewport by kind |
| `stew_get_diff` | Structured diff (predecessor vs draft) |
| `stew_capture_manifest` | Compute + persist ViewportManifest |

**Guardrails (G01-G15):**

| Severity | Rules |
|----------|-------|
| Block | G01 (role permission), G03 (type constraint), G04 (proof chain), G05 (classification), G06 (security label), G07 (silent meaning change), G08 (deprecation), G15 (draft uniqueness) |
| Warning | G02 (naming), G10 (conflict), G11 (stale template), G12 (observation impact), G13 (resolution metadata) |
| Advisory | G09 (AI knowledge boundary), G14 (composition hint) |

**4 Viewports:** Focus Summary (A), Object Inspector (C), Diff (D), Gates (G)

**REST + SSE Endpoints:**

| Method | Route | Purpose |
|--------|-------|---------|
| GET | `/api/stewardship/session/:id/focus` | Get FocusState |
| PUT | `/api/stewardship/session/:id/focus` | Set FocusState |
| DELETE | `/api/stewardship/session/:id/focus` | Clear FocusState |
| GET | `/api/stewardship/session/:id/show` | Snapshot of ShowPacket |
| GET | `/api/stewardship/session/:id/workbench-events` | SSE stream (WorkbenchPackets) |
| POST | `/api/stewardship/session/:id/manifest` | Capture ViewportManifest |

### Schema Visibility (db_introspect + AttributeSource)

> ✅ **IMPLEMENTED (2026-02-25)**: Agent can now discover raw relational schema and attribute→table mappings are correct.

**`db_introspect` MCP tool** queries PostgreSQL `information_schema`:
- Parameters: `schema_name` (required), `table_name` (optional), `include_fks` (default true)
- Returns: `{ schema, table_count, tables: [{ name, columns: [{name, type, nullable, default, is_pk}], foreign_keys: [{column, references_schema, references_table, references_column}] }] }`

**`AttributeSource` fix**: Scanner now resolves real (schema, table, column) triples via resolution chain:
1. **CRUD config** (most precise): `verb_config.crud.schema` / `crud.table`
2. **Entity type db_table**: `entity_type_defs[domain].db_table.schema` / `db_table.table`
3. **Fallback**: `(None, None)` — better than a wrong guess

### Database Schemas

| Schema | Owner | Purpose |
|--------|-------|---------|
| `sem_reg` | sem_os | Core registry: snapshots, snapshot_sets, outbox_events, agent plans/decisions, changesets |
| `sem_reg_pub` | sem_os | Read-optimized projections: active_snapshot_set, projection_watermark |
| `stewardship` | sem_os | Stewardship layer: events, basis_records, basis_claims, conflict_records, focus_states, viewport_manifests |

### Environment Variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `SEM_OS_MODE` | `inprocess` | `inprocess` = direct CoreService, `remote` = REST client |
| `SEM_OS_URL` | — | Base URL for remote mode (e.g., `http://localhost:4100`) |
| `SEM_OS_DATABASE_URL` | — | Postgres connection string (required for standalone server) |
| `SEM_OS_JWT_SECRET` | — | Shared secret for JWT signing/verification (required) |
| `SEM_OS_BIND_ADDR` | `0.0.0.0:4100` | Listen address for standalone server |
| `SEM_OS_DISPATCHER_INTERVAL_MS` | `500` | Outbox dispatcher poll interval |
| `SEM_OS_DISPATCHER_MAX_FAILS` | `5` | Max consecutive outbox dispatch failures before pause |

### Running

```bash
# Start Semantic OS server (standalone, port 4100)
SEM_OS_DATABASE_URL="postgresql:///data_designer" \
  SEM_OS_JWT_SECRET=dev-secret \
  cargo run -p sem_os_server

# Run harness tests (isolated DB per test)
DATABASE_URL="postgresql:///data_designer" \
  cargo test -p sem_os_harness -- --ignored --nocapture

# HTTP integration tests (standalone server)
DATABASE_URL="postgresql:///data_designer" \
  cargo test -p sem_os_server --test authoring_http_integration -- --ignored --nocapture

# Stewardship integration tests
DATABASE_URL="postgresql:///data_designer" \
  cargo test --features database --test stewardship_b2_validation -- --ignored --nocapture
DATABASE_URL="postgresql:///data_designer" \
  cargo test --features database --test stewardship_b3_changesets -- --ignored --nocapture --test-threads=1
```

### Migrations (092-098)

| Migration | Purpose |
|-----------|---------|
| 092 | `sem_reg.outbox_events` table |
| 093 | `sem_reg.bootstrap_audit` table |
| 094 | `sem_reg_pub` schema: `active_snapshot_set`, `projection_watermark`, seed row |
| 095 | `sem_reg.changesets`, `changeset_entries`, `changeset_reviews` + indexes |
| 096 | `v_active_taxonomy_defs` JSONB extraction hotfix |
| 097 | Stewardship Phase 0: `stewardship` schema (events, basis_records, basis_claims, conflict_records), changeset_entries columns (action, predecessor_id, revision, reasoning, guardrail_log), draft uniqueness index |
| 098 | Stewardship Phase 1: `stewardship.focus_states`, `stewardship.viewport_manifests` |

### Stewardship Module Structure

```
rust/src/sem_reg/stewardship/
├── mod.rs                    # Module root (11 re-exports)
├── types.rs                  # Re-exports from sem_os_core::stewardship::types (Phase 0 + Phase 1)
├── store.rs                  # StewardshipStore — append-only DB ops
├── guardrails.rs             # G01–G15 validation engine
├── idempotency.rs            # Idempotency checking + recording
├── impact.rs                 # Impact analysis (affected snapshots, consumers)
├── templates.rs              # Template instantiation + validation
├── focus.rs                  # FocusStore for focus_states table
├── show_loop.rs              # ShowLoop engine (4 viewports)
├── tools_phase0.rs           # 17 Phase 0 MCP tool handlers
└── tools_phase1.rs           # 6 Phase 1 MCP tool handlers
```

### Key Files

| File | Purpose |
|------|---------|
| `rust/crates/sem_os_core/src/service.rs` | CoreServiceImpl: bootstrap, resolve, publish, changeset promote |
| `rust/crates/sem_os_core/src/ports.rs` | 8 storage port traits (SnapshotStore, ChangesetStore, OutboxStore, AuditStore, EvidenceInstanceStore, ObjectStore, ProjectionWriter, BootstrapAuditStore) |
| `rust/crates/sem_os_core/src/stewardship/mod.rs` | Role constraints, proof chain checks, stale draft detection |
| `rust/crates/sem_os_core/src/stewardship/types.rs` | All stewardship type definitions (Phase 0 + Phase 1) |
| `rust/crates/sem_os_core/src/principal.rs` | `Principal` — explicit actor identity (no implicit context) |
| `rust/crates/sem_os_core/src/gates/mod.rs` | Publish gate evaluation (proof rule, security, approval, version) |
| `rust/crates/sem_os_core/src/gates/governance.rs` | 3 governance gates (taxonomy, stewardship, evidence grade) |
| `rust/crates/sem_os_core/src/gates/technical.rs` | Technical gates (type correctness, verb surface, sink disclosure) |
| `rust/crates/sem_os_postgres/src/store.rs` | 8 Postgres adapters (~2600 LOC): PgSnapshotStore, PgObjectStore, PgChangesetStore, PgAuditStore, PgOutboxStore, PgEvidenceStore, PgProjectionWriter, PgBootstrapAuditStore |
| `rust/crates/sem_os_server/src/router.rs` | Axum router: 12 protected routes + health |
| `rust/crates/sem_os_server/src/dispatcher.rs` | Outbox dispatcher: poll → claim → project → watermark |
| `rust/crates/sem_os_client/src/lib.rs` | SemOsClient trait: the sole API boundary |
| `rust/crates/sem_os_client/src/inprocess.rs` | InProcessClient: delegates to Arc\<dyn CoreService\> |
| `rust/crates/sem_os_client/src/http.rs` | HttpClient: REST + JWT bearer |
| `rust/crates/sem_os_harness/src/lib.rs` | 3 test suites: core, projections, permissions |
| `rust/crates/sem_os_obpoc_adapter/src/lib.rs` | Adapter: `build_seed_bundle()` from verb YAML |
| `rust/crates/sem_os_obpoc_adapter/src/scanner.rs` | Verb YAML → typed seeds (CRUD config + entity type resolution chain) |
| `rust/src/sem_reg/stewardship/guardrails.rs` | G01-G15 validation engine (pure functions) |
| `rust/src/sem_reg/stewardship/show_loop.rs` | ShowLoop engine (4 viewports) |
| `rust/src/sem_reg/stewardship/tools_phase0.rs` | 17 Phase 0 MCP tool handlers |
| `rust/src/sem_reg/stewardship/tools_phase1.rs` | 6 Phase 1 MCP tool handlers |
| `rust/src/api/stewardship_routes.rs` | REST + SSE endpoints for stewardship |
| `rust/src/mcp/tools.rs` | `db_introspect` tool definition |
| `rust/src/mcp/handlers/core.rs` | `db_introspect` handler (information_schema queries) |
| `rust/tests/stewardship_b2_validation.rs` | 6 integration tests (4,916 bootstrapped snapshots) |
| `rust/tests/stewardship_b3_changesets.rs` | 5 integration tests (full changeset lifecycle) |

### Startup Sequence (ob-poc-web)

```
1. Load verb YAML config
2. Build adapter → build_seed_bundle(verbs_config) → SeedBundle
3. Create Postgres stores (PgStores::new(pool))
4. Create CoreServiceImpl with port traits
5. Create InProcessClient wrapping CoreService
6. Bootstrap seed bundle (idempotent)
7. Spawn OutboxDispatcher background task
8. Build Axum router, start HTTP server
```

### Post-Cutover Housekeeping (TODO)

- [ ] Delete `rust/src/sem_reg/*.rs` (old monolithic code) once stable — forces discovery of remaining direct calls
- [ ] Drop in-process ABAC fallback code once remote mode is validated
- [ ] Monitor outbox lag: `SELECT MAX(attempt_count) FROM sem_reg.outbox_events WHERE processed_at IS NULL`

---

## Governed Registry Authoring — Research→Governed Change Boundary (v0.4, Migrations 099-102)

> ✅ **IMPLEMENTED (2026-02-25)**: 7-phase implementation complete. Standalone server verified (2026-02-26). 60 unit tests + 26 integration tests + 10 HTTP integration tests. Clippy clean. 8 CLI subcommands. 10 REST routes.

**Problem Solved:** Research output (schema migrations, verb definitions, attributes, taxonomies) was committed ad-hoc without validation, drift detection, or governance gating. The v0.4 spec defines a two-plane model: the **Research plane** produces immutable ChangeSets (bundles of artifacts), and the **Governed plane** publishes validated ChangeSets atomically into the active snapshot set.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  RESEARCH → GOVERNED CHANGE BOUNDARY                                         │
│                                                                              │
│  Research Plane                         Governed Plane                       │
│  ─────────────────                     ────────────────                      │
│  propose_change_set()                  publish_snapshot_set()                │
│       │                                     │                                │
│       ▼                                     ▼                                │
│  ChangeSet (Draft)                    Advisory lock                          │
│       │                                     │                                │
│       ▼                                     ▼                                │
│  validate_change_set()               Drift detection                        │
│       │  Stage 1: artifact integrity        │                                │
│       │  (hash, SQL parse, YAML, refs)      ▼                                │
│       ▼                              Apply DDL migrations                   │
│  ChangeSet (Validated)                      │                                │
│       │                                     ▼                                │
│       ▼                              publish_batch_into_set()               │
│  dry_run_change_set()                       │                                │
│       │  Stage 2: scratch schema            ▼                                │
│       │  (DDL apply, compat check)   ChangeSet (Published)                  │
│       ▼                                     │                                │
│  ChangeSet (DryRunPassed)                   ▼                                │
│       │                              Governance audit entry                 │
│       └──────────────────────────────►                                      │
│                                                                              │
│  AgentMode gating:                                                          │
│    Research: propose/validate/dry-run/plan/diff (blocks publish)            │
│    Governed: publish/rollback + business verbs (blocks authoring)           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### ChangeSet Status State Machine (9-state)

```
Draft → UnderReview → Approved → Validated → DryRunPassed → Published
  │                                  │            │              │
  └→ Rejected                        └→ Rejected  └→ DryRunFailed └→ Superseded
```

> **Note:** `UnderReview` and `Approved` states added from stewardship changeset workflow. Migration 101 fixes the CHECK constraint to include all 9 states.

### 7 Governance Verbs

| Verb | Method | Status Transition | Key Logic |
|------|--------|-------------------|-----------|
| `propose_change_set` | `propose()` | → `Draft` | Parse bundle, compute content_hash, idempotent by `(hash_version, content_hash)` |
| `validate_change_set` | `validate()` | `Draft` → `Validated`/`Rejected` | Stage 1: hash verification, SQL/YAML parsing, reference resolution |
| `dry_run_change_set` | `dry_run()` | `Validated` → `DryRunPassed`/`DryRunFailed` | Stage 2: scratch schema, DDL safety, compatibility diff |
| `plan_publish` | `plan_publish()` | (read-only) | Diff against active, compute downstream impact |
| `publish_snapshot_set` | `publish()` | `DryRunPassed` → `Published` | Advisory lock → drift detect → apply → publish_batch_into_set → audit |
| `rollback_snapshot_set` | `rollback()` | (pointer revert) | Revert active_snapshot_set pointer |
| `diff_change_sets` | `diff()` | (read-only) | Structural diff between two ChangeSets |

### Validation Pipeline

**Stage 1 (Pure, no DB):** Artifact integrity (hash verification), SQL parsing (`sqlparser`), YAML parsing (`serde_yaml`), reference resolution (entity type/domain/attribute refs), semantic consistency (attribute types, verb contract completeness, dependency cycle detection via toposort).

**Stage 2 (Needs DB):** Schema safety (scratch schema apply + rollback, `CONCURRENTLY`/`DROP TABLE` detection), compatibility diff against active snapshot set, breaking change detection.

**Error codes:** `V:HASH:MISMATCH`, `V:PARSE:SQL_SYNTAX`, `V:REF:MISSING_*`, `V:REF:CIRCULAR_DEPENDENCY`, `D:SCHEMA:APPLY_FAILED`, `D:SCHEMA:FORBIDDEN_DDL`, `D:COMPAT:BREAKING_UNDECLARED`

### AgentMode Gating

| Mode | Allowed | Blocked |
|------|---------|---------|
| `Research` | ChangeSet authoring verbs (propose, validate, dry-run, plan, diff), full `db_introspect`, SemReg read tools | Governed business verbs, publish/rollback |
| `Governed` | Business verbs (per SemReg), publish/rollback, limited `db_introspect` (single-table only) | Authoring exploration verbs |

Default: `Governed`. Mode switch via `agent.set-mode` verb. AgentMode filtering wired in `orchestrator.rs` (Stage A.3).

### Content-Addressed Idempotency

ChangeSets are identified by `(hash_version, content_hash)` where `content_hash = SHA-256(canonical_json(sorted_artifacts))`. Proposing the same bundle twice returns the existing ChangeSet instead of creating a duplicate. The UNIQUE index excludes rejected/superseded ChangeSets.

### REST Routes (sem_os_server)

| Method | Route | Purpose |
|--------|-------|---------|
| GET | `/authoring` | List ChangeSets (with status filter) |
| POST | `/authoring/propose` | Propose new ChangeSet from bundle |
| GET | `/authoring/{id}` | Get ChangeSet detail |
| POST | `/authoring/{id}/validate` | Run Stage 1 validation |
| POST | `/authoring/{id}/dry-run` | Run Stage 2 dry-run |
| GET | `/authoring/{id}/plan` | Plan publish (diff preview) |
| POST | `/authoring/{id}/publish` | Publish to active snapshot set |
| POST | `/authoring/publish-batch` | Batch publish (topological sort) |
| POST | `/authoring/diff` | Diff two ChangeSets |

### CLI Commands

```bash
cd rust/

# List ChangeSets
cargo x sem-reg authoring-list [--status draft|validated|published|...]

# Propose from bundle directory
cargo x sem-reg authoring-propose /path/to/bundle/

# Validate / dry-run / plan / publish
cargo x sem-reg authoring-validate <changeset-id>
cargo x sem-reg authoring-dry-run <changeset-id>
cargo x sem-reg authoring-plan <changeset-id>
cargo x sem-reg authoring-publish <changeset-id> --publisher <name>

# Batch publish
cargo x sem-reg authoring-publish-batch <id1> <id2> --publisher <name>

# Diff two ChangeSets
cargo x sem-reg authoring-diff <base-id> <target-id>

# Health (pending counts, stale dry-runs)
cargo x sem-reg authoring-health
```

### Database Schema

**Extended tables (migration 099):**
- `sem_reg.changesets` — added `content_hash`, `hash_version`, `title`, `rationale`, `supersedes_change_set_id`, `superseded_by`, `superseded_at`, `depends_on`, `evaluated_against_snapshot_set_id`
- `sem_reg.changeset_entries` — added `content_hash`, `path`, `artifact_type`, `ordinal`, `entry_metadata`

**New tables (migration 099 — `sem_reg_authoring` schema):**

| Table | Purpose |
|-------|---------|
| `validation_reports` | Append-only validation/dry-run reports (report_id, change_set_id, stage, ok, report JSONB) |
| `governance_audit_log` | Permanent audit log for all governance verbs (verb, agent_mode, change_set_id, result, duration_ms) |
| `publish_batches` | Records of batch publish operations (batch_id, change_set_ids[], snapshot_set_id, publisher) |
| `change_set_artifacts` | Individual artifacts within a ChangeSet (artifact_type, ordinal, path, content, content_hash) |

**Archive tables (migration 100):**

| Table | Purpose |
|-------|---------|
| `change_sets_archive` | Archived ChangeSets (rejected/failed > 90 days, orphan drafts > 30 days) |
| `change_set_artifacts_archive` | Archived artifacts (cascade from changeset archive) |

**Standalone remediation (migrations 101-102):**

| Migration | Purpose |
|-----------|---------|
| 101 | Fix `sem_reg.changesets` CHECK constraint to include all 9 ChangeSetStatus values (added `under_review`, `approved` from stewardship) |
| 102 | Fix `change_sets_archive` and `change_set_artifacts_archive` ownership to `sem_reg_authoring` schema |

**CCIR telemetry (migration 103):**

| Migration | Purpose |
|-----------|---------|
| 103 | Add 5 columns to `agent.intent_events` for CCIR: `allowed_verbs_fingerprint` (SHA-256), `pruned_verbs_count`, `toctou_recheck_performed`, `toctou_result`, `toctou_new_fingerprint` |

### Module Structure

```
rust/crates/sem_os_core/src/authoring/
├── mod.rs                  # Re-exports
├── types.rs                # ChangeSetStatus (9-state), ArtifactType, ChangeSetFull, ValidationReport, DryRunReport, etc.
├── errors.rs               # Error code constants (V:*, D:*, PUBLISH:*)
├── canonical_hash.rs       # compute_content_hash(), compute_artifact_hash()
├── ports.rs                # AuthoringStore trait (20 methods), ScratchSchemaRunner trait
├── validate_stage1.rs      # Stage 1: artifact integrity, SQL/YAML parse, ref resolution (14 unit tests)
├── validate_stage2.rs      # Stage 2: DDL safety checks (CONCURRENTLY, DROP TABLE)
├── diff.rs                 # Structural diff + breaking change detection (7 unit tests)
├── governance_verbs.rs     # GovernanceVerbService (7 verbs)
├── bundle.rs               # Bundle parsing (manifest YAML + artifact content, 7 unit tests)
├── agent_mode.rs           # AgentMode enum (Research/Governed) with verb/introspect gating (9 unit tests)
├── metrics.rs              # Structured tracing events for governance verbs
└── cleanup.rs              # CleanupPolicy for retention/archival
```

**Postgres implementation:** `rust/crates/sem_os_postgres/src/authoring.rs` — `PgAuthoringStore` + `PgScratchSchemaRunner`

**Server handlers:** `rust/crates/sem_os_server/src/handlers/authoring.rs` — 10 route handlers

### Test Coverage

| Category | Count | Scope |
|----------|-------|-------|
| Unit tests (`sem_os_core`) | 321 | Types, hashing, validation, diff, bundle, agent mode, metrics, cleanup, serde round-trip, error mapping, principal, stewardship guardrails, body types, seeds, derivation |
| Integration tests | 26 | E2E (4), Negative (8), Regression (6), Mode (3), Observability (2), Cleanup (1), Additional (2) |
| HTTP integration tests (`sem_os_server`) | 10 | Health, auth required, valid JWT, admin enforcement, AgentMode gating, both-modes read, tools 404, parametric routing, batch publish |

```bash
# Unit tests
cargo test -p sem_os_core -- authoring

# Integration tests (requires database)
DATABASE_URL="postgresql:///data_designer" \
  cargo test --features database --test sem_reg_authoring_integration -- --ignored --nocapture

# HTTP integration tests (requires database)
DATABASE_URL="postgresql:///data_designer" \
  cargo test -p sem_os_server --test authoring_http_integration -- --ignored --nocapture
```

### Key Files

| File | Purpose |
|------|---------|
| `rust/crates/sem_os_core/src/authoring/` | 13 files: core types, validation, governance verbs |
| `rust/crates/sem_os_postgres/src/authoring.rs` | `PgAuthoringStore` + `PgScratchSchemaRunner` |
| `rust/crates/sem_os_server/src/handlers/authoring.rs` | 10 REST route handlers |
| `rust/crates/sem_os_server/src/router.rs` | Route registration |
| `rust/crates/sem_os_core/src/service.rs` | 8 new CoreService methods (authoring_propose, etc.) |
| `rust/src/agent/orchestrator.rs` | AgentMode verb filtering (Stage A.3) |
| `rust/src/mcp/handlers/core.rs` | Mode-gated `db_introspect` |
| `rust/xtask/src/sem_reg.rs` | 8 CLI subcommands |
| `rust/xtask/src/main.rs` | CLI wiring |
| `rust/tests/sem_reg_authoring_integration.rs` | 26 integration tests |
| `rust/crates/sem_os_server/tests/authoring_http_integration.rs` | 10 HTTP integration tests |
| `rust/crates/sem_os_postgres/src/cleanup.rs` | `PgCleanupStore` — retention/archival Postgres implementation |
| `migrations/099_sem_reg_authoring.sql` | Schema extensions + new tables |
| `migrations/100_sem_reg_authoring_archive.sql` | Archive tables for retention |
| `migrations/101_changesets_status_check_fix.sql` | Fix CHECK constraint to include all 9 ChangeSetStatus values |
| `migrations/102_authoring_archive_owner_fix.sql` | Fix archive table schema ownership |

---

## Deprecated / Removed

| Removed | Replaced By |
|---------|-------------|
| `ViewMode` enum (5 modes) | Unit struct (always TRADING) |
| `OpenAIEmbedder` | `CandleEmbedder` (local) |
| `all-MiniLM-L6-v2` model | `bge-small-en-v1.5` (retrieval-optimized) |
| `embed()` / `embed_batch()` | `embed_query()` / `embed_target()` (asymmetric) |
| `IntentExtractor` (old MCP path) | MCP `verb_search` + `dsl_generate` |
| `AgentOrchestrator` | MCP pipeline |
| `verb_rag_metadata.rs` | YAML `invocation_phrases` + pgvector |
| `FeedbackLoop.generate_valid_dsl()` | MCP `dsl_generate` |
| `VerbPhraseIndex` (YAML phrase matcher) | `VerbService` + pgvector semantic search |
| Direct sqlx in `HybridVerbSearcher` | `VerbService` centralized DB access |
| `ob-poc-ui` (egui crate) | React frontend (`ob-poc-ui-react/`) |
| `esper_*` (6 navigation crates) | React frontend + REST API |
| `orchestrator.rs` (V1 REPL) | `orchestrator_v2.rs` (7-state machine, vnext-repl) |
| `session.rs` (V1 REPL) | `session_v2.rs` (runbook fold, vnext-repl) |
| `ReplState` (V1 5-state) | `ReplStateV2` in orchestrator_v2.rs |
| `ClientContext` / `JourneyContext` (mutable) | `ContextStack` (pure fold from runbook) |
| `HybridVerbSearcher` (V1 agent chat) | `IntentService` + `search_with_context()` (V2 REPL) |
| `IntentPipeline` (V1 agent chat) | `ReplOrchestratorV2.process()` (V2 REPL) |
| V1 Staged Runbook (054) — 6 modules, MCP tools, verb YAML, CustomOps | V2 REPL pack-guided runbook |
| `ob-poc-graph` crate | React frontend + REST API |
| `viewport` crate | React frontend + REST API |
| `config/graph_settings.yaml` | Deleted (esper_* visualization config) |
| `SemRegVerbPolicy` enum | `ContextEnvelope` (structured prune reasons, fingerprint, TOCTOU) |
| `session/agent_context.rs` (V1) | Deleted — V1 `AgentGraphContext` for egui/ESPER, no active callers |
| `session/enhanced_context.rs` (V1) | Deleted — V1 `EnhancedContext`, no active callers |
| `session/verb_discovery.rs` (V1) | Deleted — `VerbDiscoveryService` superseded by `HybridVerbSearcher` + `IntentService` |
| `api/verb_discovery_routes.rs` | Deleted — REST endpoints for V1 verb discovery, no active callers |
| `lint/agent_context_lint.rs` | Deleted — `AGENT001` lint rule, no longer applicable |
| `allow_direct_dsl` / `dsl:` prefix bypass | Removed — all DSL flows through SemReg-filtered pipeline |
| `ClientContext` / `JourneyContext` (session_v2) | Replaced with opaque `serde_json::Value` for legacy compat |
| `manco` domain name | Renamed to `ownership` domain |

---

## Domain Quick Reference

| Domain | Verbs | Purpose |
|--------|-------|---------|
| `cbu` | 25 | Client Business Unit lifecycle |
| `entity` | 30 | Natural/legal person management |
| `session` | 16 | Scope, navigation, history |
| `view` | 15 | Navigation verbs (legacy ESPER, now via React) |
| `trading-profile` | 30 | Trading matrix, CA policy |
| `kyc` | 20 | KYC case management |
| `investor` | 15 | Investor register, holdings |
| `custody` | 40 | Settlement, safekeeping |
| `gleif` | 15 | LEI lookup, hierarchy import |
| `research.*` | 30+ | External source workflows |
| `contract` | 14 | Legal contracts, rate cards, CBU subscriptions |
| `document` | 7 | Document solicitation, verification, rejection |
| `requirement` | 5 | Document requirements, waiver, status |
| `deal` | 30 | Deal record lifecycle, rate card negotiation, onboarding handoff |
| `billing` | 14 | Fee billing profiles, account targets, billing periods |
| `legal-entity` | 3 | Legal entity CRUD (booking principal layer) |
| `booking-location` | 3 | Booking location CRUD |
| `booking-principal` | 6 | Principal lifecycle, evaluation, selection |
| `service-availability` | 3 | Three-lane service availability |
| `client-principal-relationship` | 3 | Client ↔ principal relationships |
| `ruleset` | 3 | Eligibility ruleset lifecycle (draft → publish → retire) |
| `rule` | 3 | Individual eligibility rules within rulesets |
| `rule-field` | 2 | Closed-world field dictionary for rule validation |
| `contract-pack` | 3 | Contract template packs |
| `ownership` | 4 | Ownership graph pipeline (bridge ManCo roles, GLEIF fund managers, BODS, control links, CBU groups) |
| `registry` | 20 | SemReg object CRUD: snapshots, attributes, entity types, verb contracts, taxonomies, views, policies |
| `changeset` | 14 | Changeset authoring: propose, validate, dry-run, publish, diff, review workflow |
| `governance` | 9 | Governance verbs: publish gates, impact analysis, rollback, audit log |
| `audit` | 8 | Governance audit trail: decision records, intent events, bootstrap audit |
| `maintenance` | 7 | Registry maintenance: cleanup, retention, archival, health checks |
| `focus` | 6 | Stewardship focus/show loop: viewport management, manifest capture |
| `schema` | 5 | Schema introspection and attribute source mapping |
| `agent` | 4+ | Agent mode/policy introspection, tool listing, telemetry summary |
| `sem_reg.*` | ~32 MCP | Semantic Registry MCP tools: context resolution, agent plans/decisions, lineage, coverage |

### Agent Intent Pipeline Hardening

> **Implemented:** 2026-02-14, updated 2026-02-26 (CCIR)
> **Tests:** 1220+ unit tests passing (16 CCIR tests added)

**Summary:** Unified intent orchestrator, side-door prevention, SemReg on critical path, Context-Constrained Intent Resolution (CCIR).

**Changes by Phase:**

| Phase | What | Files |
|-------|------|-------|
| 0.1 | Fix corrupted SQL `$1..$15` placeholders in `_tx` functions | `sem_reg/store.rs` |
| 0.3 | Map internal param types to valid JSON Schema (`uuid`→`string+format`, `json`→`object`) | `mcp/tools_sem_reg.rs` |
| 0.4 | Config-based `ActorContext` for MCP (env vars, default least-privilege `viewer`) | `mcp/handlers/core.rs` |
| 0.5 | ABAC-filter `handle_search()` results (was leaking existence of restricted objects) | `sem_reg/agent/mcp_tools.rs`, `sem_reg/enforce.rs` |
| 1.1 | Unified `handle_utterance()` orchestrator: entity linking → SemReg → pipeline → post-filter → trace | `agent/orchestrator.rs` |
| 1.2 | Route Chat API through orchestrator | `api/agent_service.rs` |
| 1.3 | Route MCP `dsl_generate` through orchestrator | `mcp/handlers/core.rs` |
| 1.4 | Route REPL through orchestrator (pool + trace logging) | `repl/orchestrator_v2.rs` |
| 2.1 | ~~Direct DSL bypass~~ **Removed** — `dsl:` prefix path and `allow_direct_dsl` flag deleted | `mcp/intent_pipeline.rs` |
| 2.2 | Gate `/execute` raw DSL behind SemReg verb validation (AST-level check) | `mcp/handlers/core.rs` |
| 2.3 | Remove duplicate `IntentPipeline` creation — dead `get_intent_pipeline()` removed | `api/agent_service.rs` |
| 3 | **CCIR Phase 3:** SemReg allowed verbs threaded as **pre-constraint** into `HybridVerbSearcher.search()` (not just post-filter) | `agent/orchestrator.rs`, `mcp/intent_pipeline.rs`, `mcp/verb_search.rs` |
| 4 | `LookupService` results reused via orchestrator (no double verb/entity search) | `agent/orchestrator.rs` |
| 5 | `IntentTrace` structured audit with CCIR fields (fingerprint, pruned count, TOCTOU) | `agent/orchestrator.rs` |
| 2B-C | **CCIR:** `SemOsContextEnvelope` replaces `SemRegVerbPolicy`, structured `PruneReason`, fingerprint, TOCTOU recheck | `agent/sem_os_context_envelope.rs` (NEW), `agent/orchestrator.rs` |
| — | **Legacy cleanup:** Delete 4 V1 modules (~2,700 LOC) — `session/agent_context.rs`, `session/enhanced_context.rs`, `session/verb_discovery.rs`, `api/verb_discovery_routes.rs`, `lint/agent_context_lint.rs` | Session, API, lint |
| — | **dsl_execute Sem OS gate:** MCP `dsl_execute` validates every verb FQN in parsed AST against `SemOsContextEnvelope` before execution | `mcp/handlers/core.rs` |
| — | **Scanner improvement:** `subject_kinds` 3-level fallback chain + `domain_to_subject_kind()` heuristic | `sem_os_obpoc_adapter/scanner.rs` |
| — | **ownership.refresh:** New pipeline verb running all 5 ownership steps in sequence | `domain_ops/manco_ops.rs` |
| — | **Session V2 cleanup:** `ClientContext`/`JourneyContext` structs deleted, replaced with opaque JSON | `repl/session_v2.rs` |

**CCIR (Context-Constrained Intent Resolution):**

The `SemOsContextEnvelope` (replacing `SemRegVerbPolicy`) carries the full Sem OS resolution output:

```
Sem OS resolve_context()
    │
    ▼
SemOsContextEnvelope {
    allowed_verbs: HashSet<String>,          // Verbs passing ABAC + tier + preconditions
    pruned_verbs: Vec<PrunedVerb>,           // Verbs rejected with structured reasons
    fingerprint: AllowedVerbSetFingerprint,  // SHA-256 of sorted FQNs (format: v1:<hex>)
    evidence_gaps, governance_signals,       // Governance intelligence
    resolution_stage, discovery_surface,     // Discovery bootstrap for ungrounded sessions
    snapshot_set_id,                         // Provenance
}
    │
    ├─► Pre-constrained verb search: allowed_verbs → IntentPipeline → HybridVerbSearcher
    │       (disallowed verbs never returned from any tier)
    │
    ├─► dsl_execute gate: AST verb FQNs checked against envelope before execution
    │
    └─► TOCTOU recheck: toctou_recheck(original, fresh) → StillAllowed | AllowedButDrifted | Denied
```

**PruneReason variants:** `AbacDenied`, `EntityKindMismatch`, `TierExcluded`, `TaxonomyNoOverlap`, `PreconditionFailed`, `AgentModeBlocked`, `PolicyDenied`

**Key Architectural Decision:** Sem OS verb filtering is now **pre-constrained** (allowed verbs threaded into `HybridVerbSearcher.search()`) with a post-filter safety net retained. Direct DSL bypass removed, and utterance discovery is fail-closed when Sem OS is unavailable instead of widening to the full registry.

**Env Vars for MCP ActorContext:**
- `MCP_ACTOR_ID` — actor identifier (default: `mcp_anonymous`)
- `MCP_ROLES` — comma-separated roles (default: `viewer`)
- `MCP_DEPARTMENT` — department (optional)
- `MCP_CLEARANCE` — classification level: `public|internal|confidential|restricted` (optional)
- `MCP_JURISDICTIONS` — comma-separated jurisdiction codes (optional)

**Security Model:**
- MCP: least-privilege `viewer` by default — env vars required to escalate (no hardcoded operator)
- Chat: `operator` role (intentional — internal tool). TODO: derive from auth token when plumbed
- Direct DSL bypass (`dsl:` prefix) removed — all DSL flows through SemReg-filtered pipeline
- `dsl_execute` validates verb FQNs against `SemOsContextEnvelope` before execution
- Sem OS failure: structured `warn!` with fail-closed behavior for utterance discovery — never silent
- Trace levels: INFO = summary (verb, confidence, source), DEBUG = full detail (utterance, entities, candidates)

### DSL Execution Governance Matrix

Every DSL execution entry point must pass SemReg verb validation and PolicyGate checks. The following matrix documents all 9 entry points with their governance enforcement status, verified against the codebase as of 2026-03-01.

| Entry Point | File | SemReg Check | PolicyGate | Notes |
|-------------|------|:---:|:---:|-------|
| MCP `dsl_execute` | `core.rs:627` | ✅ AST-level per verb | ✅ Env-based | Parses program → extracts verb FQNs → checks each against `ContextEnvelope.allowed_verbs` |
| MCP `dsl_execute_submission` | `core.rs:1204` | ✅ AST-level per verb | ✅ Env-based | Same 3-branch pattern: `is_unavailable()` → `is_deny_all()` → `!is_allowed(fqn)` |
| MCP `dsl_generate` | `core.rs:1591` | ✅ Via orchestrator | ✅ Env-based | Delegates to `handle_utterance()` — full SessionVerbSurface pipeline |
| REST `POST /chat` | via orchestrator | ✅ Surface + pre-constraint | ✅ Headers | Full SessionVerbSurface at Stage 2.5 + pre-constrained `HybridVerbSearcher` |
| REST `execute_session_dsl` | `agent_routes.rs:2775` | ✅ AST-level per verb | ✅ Headers | `resolve_allowed_verbs()` → `ContextEnvelope` → per-verb `is_allowed()` |
| REST `GET /verb-surface` | `agent_routes.rs:4238` | ✅ FailOpen (read-only) | N/A (viewer) | Returns governed verb set for UI display |
| `execute_onboarding_dsl` | `agent_dsl_routes.rs:2155` | ✅ AST-level per verb | ✅ Env-based | Same 3-branch pattern as `dsl_execute` |
| `batch_add_products` | `agent_dsl_routes.rs:2292` | ✅ Template verb gate | ✅ Env-based | Validates `cbu.add-product` against `ContextEnvelope` before batch execution |
| `handle_utterance_with_forced_verb` | `orchestrator.rs:778` | ✅ TOCTOU recheck | ✅ Env-based | Full `ContextEnvelope` validation + TOCTOU fields populated in `IntentTrace` |

**Common SemReg Check Pattern (3-branch):**
```rust
if envelope.is_unavailable() {
    // SemReg unavailable — fail-closed or fail-open per VerbSurfaceFailPolicy
} else if envelope.is_deny_all() {
    // SemReg explicitly denied all verbs for this session context
    return Err("All verbs denied by SemReg policy");
} else if !envelope.is_allowed(&verb_fqn) {
    // Specific verb not in allowed set
    return Err(format!("Verb '{}' not allowed by SemReg policy", verb_fqn));
}
```

**Governance Bypass Prevention:** As of 2026-03-01, all DSL execution paths pass through SemReg validation. The direct DSL bypass (`dsl:` prefix) was removed. No entry point can execute a verb that is not in the session's `ContextEnvelope.allowed_verbs` set.

### SessionVerbSurface — Governance Layer Composition

> **Implemented:** 2026-02-28
> **Tests:** 13 unit tests + 1483 total passing

**Problem Solved:** Multiple governance layers (SemReg CCIR, AgentMode, workflow phase, lifecycle state, actor gating) were applied inline across 3+ code paths (`build_verb_profiles`, `generate_options_from_envelope`, orchestrator pre-filter chain) with inconsistent behavior — notably a SI-1 violation where `build_verb_profiles()` silently fell back to the full 642-verb `RuntimeVerbRegistry` when the `ContextEnvelope` was empty. `SessionVerbSurface` consolidates all layers into a single, queryable, fingerprinted Rust type computed once per turn.

**Architecture:**

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  8-STEP COMPUTE PIPELINE (compute_session_verb_surface)                      │
│                                                                              │
│  1. Base set — RuntimeVerbRegistry (~642 verbs)                             │
│  2. AgentMode filter — Research vs Governed                                 │
│  3. Workflow phase filter — stage_focus → domain allowlists                 │
│  4. SemReg CCIR — ContextEnvelope.allowed_verbs (pre-constraint)            │
│  5. Lifecycle state filter — VerbLifecycle.requires_states vs entity state  │
│  6. Actor gating — Extension point (passthrough)                            │
│  7. FailPolicy — If SemReg unavailable + FailClosed → safe-harbor set      │
│  8. Rank & Fingerprint — Sort by domain, compute SurfaceFingerprint        │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Core Types (`rust/src/agent/verb_surface.rs`):**

| Type | Purpose |
|------|---------|
| `SessionVerbSurface` | Final computed verb set with metadata, fingerprints, filter summary |
| `SurfaceVerb` | Visible verb with FQN, domain, action, description, governance tier, lifecycle eligibility |
| `ExcludedVerb` | Excluded verb with multi-reason `Vec<SurfacePrune>` (SI-3: additive) |
| `SurfacePrune` | Single exclusion reason: `PruneLayer` + reason string |
| `PruneLayer` | Enum: `AgentMode`, `WorkflowPhase`, `SemRegCcir`, `LifecycleState`, `ActorGating`, `FailPolicy` |
| `VerbSurfaceFailPolicy` | `FailClosed` (default: ~30 safe-harbor verbs) or `FailOpen` (dev-only) |
| `SurfaceFingerprint` | Format `vs1:<sha256-hex>` — includes filter context, distinct from SemReg `v1:<hex>` |
| `FilterSummary` | Counts at each pipeline stage (total_registry → final_count) |
| `VerbSurfaceContext` | Input: agent_mode, stage_focus, envelope, fail_policy, entity_state |

**Safety Invariants:**
- **SI-1**: No ungoverned expansion — when SemReg is unavailable, FailClosed reduces to ~30 safe-harbor verbs
- **SI-2**: Dual fingerprints — `surface_fingerprint` (`vs1:`) captures ALL filter context; `semreg_fingerprint` (`v1:`) captures CCIR-internal state; never conflated
- **SI-3**: Additive exclusion reasons — a verb excluded by multiple layers accumulates all reasons

**FailClosed Safe-Harbor Verbs (~30):**
- `session.*` (load, unload, clear, info, list, undo, redo)
- `view.*` (universe, book, cbu, drill, surface)
- `agent.*` (help, status, teach)

**Workflow Phase → Domain Mapping:**

| stage_focus | Allowed Domains |
|-------------|----------------|
| `semos-onboarding` | cbu, entity, session, view, agent, contract |
| `semos-kyc` | kyc, screening, document, requirement, session, view, agent |
| `semos-data` | registry, changeset, governance, session, view, agent |
| `semos-stewardship` | focus, changeset, governance, audit, session, view, agent |

**Orchestrator Integration (`rust/src/agent/orchestrator.rs`):**

Stage 2.5 in the orchestrator pipeline computes the surface once per turn:

```rust
// Stage 2.5: Compute SessionVerbSurface
let surface_ctx = VerbSurfaceContext::new(agent_mode)
    .with_envelope(envelope.clone())
    .with_stage_focus(stage_focus)
    .with_fail_policy(VerbSurfaceFailPolicy::FailClosed);
let verb_surface = compute_session_verb_surface(&verb_registry, &surface_ctx);

// Thread allowed verbs into IntentPipeline
let allowed: HashSet<String> = verb_surface.verbs.iter().map(|v| v.fqn.clone()).collect();
pipeline.with_allowed_verbs(allowed);

// Enrich IntentTrace with surface fingerprint
trace.surface_fingerprint = Some(verb_surface.surface_fingerprint.0.clone());
```

**MCP Tool: `session_verb_surface`**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `session_id` | string | yes | Session to query |
| `include_excluded` | boolean | no | Include excluded verbs with prune reasons |
| `domain_filter` | string | no | Filter to specific domain |

**REST Endpoint: `GET /api/session/:id/verb-surface`**

Query params: `?domain=kyc&include_excluded=true`

Returns `VerbSurfaceResponse` with verbs, filter_summary, surface_fingerprint, and optionally excluded verbs.

**ChatResponse Enrichment:**

Every chat response includes `surface_fingerprint: Option<String>` from the computed surface, enabling the UI to detect when the verb set has changed.

**React UI (VerbBrowser):**
- Governance tier badge on each verb card (Governed/Operational)
- Lifecycle eligibility indicator (greyed out if not eligible)
- Filter summary at top: "Showing 80 of 642 verbs (filtered by KYC workflow + Governed mode)"
- `VerbSurfaceMeta` state in Zustand store tracking fingerprint + filter counts

**Key Files:**

| File | Purpose |
|------|---------|
| `rust/src/agent/verb_surface.rs` | **NEW** — Core types + `compute_session_verb_surface()` + 13 unit tests |
| `rust/src/agent/mod.rs` | `pub mod verb_surface;` |
| `rust/src/agent/orchestrator.rs` | Stage 2.5 surface computation + pre-filter wiring |
| `rust/src/agent/context_envelope.rs` | `#[cfg(test)] test_with_verbs()` helper |
| `rust/src/api/agent_routes.rs` | REST endpoint + ChatResponse enrichment |
| `rust/src/mcp/tools.rs` | `session_verb_surface` tool definition |
| `rust/src/mcp/handlers/session_tools.rs` | MCP handler |
| `rust/crates/ob-poc-types/src/chat.rs` | `VerbSurfaceResponse`, `VerbProfileWithGovernance` |
| `ob-poc-ui-react/src/types/chat.ts` | `VerbProfile` with governance_tier, surface_fingerprint |
| `ob-poc-ui-react/src/stores/chat.ts` | `VerbSurfaceMeta` state |
| `ob-poc-ui-react/src/features/chat/components/VerbBrowser.tsx` | Governance badges, eligibility display |
| `ob-poc-ui-react/src/features/chat/ChatPage.tsx` | Surface metadata wiring |

**Consumed (read-only):**

| File | Purpose |
|------|---------|
| `rust/src/agent/context_envelope.rs` | `ContextEnvelope` consumed as Step 4 input |
| `rust/crates/dsl-core/src/config/types.rs` | `VerbLifecycle` consumed for lifecycle filtering |
| `rust/src/dsl_v2/runtime_registry.rs` | `RuntimeVerbRegistry` consumed as Step 1 base set |
| `rust/src/mcp/intent_pipeline.rs` | `with_allowed_verbs()` called with surface-derived set |
